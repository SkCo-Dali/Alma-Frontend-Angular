import * as i0 from '@angular/core';
import { input, booleanAttribute, Component, output, computed, signal, forwardRef, numberAttribute, effect, ViewChild, inject, DestroyRef, viewChild, makeEnvironmentProviders, ENVIRONMENT_INITIALIZER } from '@angular/core';
import { Accordion, AccordionPanel, AccordionHeader, AccordionContent } from 'primeng/accordion';
import { Message } from 'primeng/message';
import * as i1 from '@angular/forms';
import { FormsModule, NG_VALUE_ACCESSOR, FormControl, ReactiveFormsModule } from '@angular/forms';
import { AutoComplete } from 'primeng/autocomplete';
import { FloatLabel } from 'primeng/floatlabel';
import { Avatar } from 'primeng/avatar';
import { AvatarGroup } from 'primeng/avatargroup';
import { BlockUI } from 'primeng/blockui';
import { ProgressSpinner } from 'primeng/progressspinner';
import { Button } from 'primeng/button';
import { ButtonGroup } from 'primeng/buttongroup';
import { Carousel } from 'primeng/carousel';
import { CascadeSelect } from 'primeng/cascadeselect';
import * as i4 from 'primeng/checkbox';
import { Checkbox, CheckboxModule } from 'primeng/checkbox';
import { Chip } from 'primeng/chip';
import { ColorPicker } from 'primeng/colorpicker';
import { Dialog } from 'primeng/dialog';
import { ContextMenu } from 'primeng/contextmenu';
import * as i2$1 from 'primeng/table';
import { TableModule } from 'primeng/table';
export { CancelEditableRow, CellEditor, ColumnFilter, ColumnFilterFormElement, ContextMenuRow, EditableColumn, EditableRow, FrozenColumn, InitEditableRow, ReorderableColumn, ReorderableRow, ReorderableRowHandle, ResizableColumn, RowGroupHeader, RowToggler, SaveEditableRow, SelectableRow, SelectableRowDblClick, Table as SkDataTable, TableModule as SkDataTableModule, SortIcon, SortableColumn, TableBody, TableCheckbox, TableClasses, TableHeaderCheckbox, TableRadioButton, TableService, TableStyle } from 'primeng/table';
import { DataView } from 'primeng/dataview';
import { Tag } from 'primeng/tag';
import { DatePicker } from 'primeng/datepicker';
import { Divider } from 'primeng/divider';
import { Dock } from 'primeng/dock';
import { Drawer } from 'primeng/drawer';
import { Select } from 'primeng/select';
import { Fieldset } from 'primeng/fieldset';
import { FileUpload } from 'primeng/fileupload';
import * as i1$1 from 'primeng/galleria';
import { GalleriaModule } from 'primeng/galleria';
import { Image } from 'primeng/image';
import { ImageCompare } from 'primeng/imagecompare';
import { Inplace } from 'primeng/inplace';
import * as i7 from 'primeng/inputtext';
import { InputText, InputTextModule } from 'primeng/inputtext';
import * as i5 from 'primeng/iconfield';
import { IconField, IconFieldModule } from 'primeng/iconfield';
import * as i6 from 'primeng/inputicon';
import { InputIcon, InputIconModule } from 'primeng/inputicon';
import { InputMask } from 'primeng/inputmask';
import { InputNumber } from 'primeng/inputnumber';
import { InputOtp } from 'primeng/inputotp';
import { Knob } from 'primeng/knob';
import { Listbox } from 'primeng/listbox';
import * as i2 from 'primeng/api';
import { SharedModule, MessageService } from 'primeng/api';
import { MegaMenu } from 'primeng/megamenu';
import * as i8 from 'primeng/menu';
import { Menu, MenuModule } from 'primeng/menu';
import { Menubar } from 'primeng/menubar';
import { MeterGroup } from 'primeng/metergroup';
import { MultiSelect } from 'primeng/multiselect';
import { OrderList } from 'primeng/orderlist';
import { OrganizationChart } from 'primeng/organizationchart';
import { OverlayBadge } from 'primeng/overlaybadge';
import * as i9 from 'primeng/paginator';
import { Paginator, PaginatorModule } from 'primeng/paginator';
import { Panel } from 'primeng/panel';
import { PanelMenu } from 'primeng/panelmenu';
import { Password } from 'primeng/password';
import { PickList } from 'primeng/picklist';
import * as i3 from 'primeng/popover';
import { Popover, PopoverModule } from 'primeng/popover';
import { ProgressBar } from 'primeng/progressbar';
import { RadioButton } from 'primeng/radiobutton';
import { Rating } from 'primeng/rating';
import { ScrollPanel } from 'primeng/scrollpanel';
import { ScrollTop } from 'primeng/scrolltop';
import { SelectButton } from 'primeng/selectbutton';
import { Skeleton } from 'primeng/skeleton';
import { Slider } from 'primeng/slider';
import { SpeedDial } from 'primeng/speeddial';
import { SplitButton } from 'primeng/splitbutton';
import { Steps } from 'primeng/steps';
import { ToggleSwitch } from 'primeng/toggleswitch';
import { Tabs, TabList, Tab, TabPanels, TabPanel } from 'primeng/tabs';
import * as i1$2 from 'primeng/terminal';
import { Terminal, TerminalService } from 'primeng/terminal';
import { Textarea } from 'primeng/textarea';
import { TieredMenu } from 'primeng/tieredmenu';
import { Timeline } from 'primeng/timeline';
import { Toast } from 'primeng/toast';
import { ToggleButton } from 'primeng/togglebutton';
import { Toolbar } from 'primeng/toolbar';
import { Tooltip } from 'primeng/tooltip';
import { Tree } from 'primeng/tree';
import { TreeSelect } from 'primeng/treeselect';
import * as i1$3 from 'primeng/treetable';
import { TreeTableModule } from 'primeng/treetable';
import { definePreset } from '@primeuix/themes';
import Aura from '@primeuix/themes/aura';
import { DOCUMENT } from '@angular/common';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { providePrimeNG } from 'primeng/config';

class SkAccordionComponent {
    panels = input([
        { header: '¿Qué incluye el portafolio conservador?', content: 'Incluye renta fija, CDTs y activos de bajo riesgo. Ideal para horizontes de inversión cortos.', icon: 'shield' },
        { header: '¿Cómo se calcula la rentabilidad?', content: 'Se calcula sobre el valor de la cuota con base en el cierre del día anterior. Refleja el rendimiento acumulado.', icon: 'chart-line' },
        { header: '¿Cuándo puedo retirar mis fondos?', content: 'Los retiros se procesan en D+1 hábil. Algunos fondos pueden tener restricciones según el tipo de producto.', icon: 'calendar' },
    ], ...(ngDevMode ? [{ debugName: "panels" }] : /* istanbul ignore next */ []));
    multiple = input(false, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkAccordionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkAccordionComponent, isStandalone: true, selector: "sk-accordion", inputs: { panels: { classPropertyName: "panels", publicName: "panels", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-accordion [multiple]="multiple()" styleClass="sk-accordion">
      @for (panel of panels(); track panel.header) {
        <p-accordion-panel [value]="panel.header" [disabled]="panel.disabled ?? false">
          <p-accordion-header>
            @if (panel.icon) {
              <i class="pi pi-{{ panel.icon }} sk-accordion__icon"></i>
            }
            {{ panel.header }}
          </p-accordion-header>
          <p-accordion-content>
            <div class="sk-accordion__body">{{ panel.content }}</div>
          </p-accordion-content>
        </p-accordion-panel>
      }
    </p-accordion>
  `, isInline: true, styles: [":host{display:block}:host ::ng-deep .sk-accordion{display:flex;flex-direction:column;gap:6px}:host ::ng-deep .sk-accordion .p-accordionpanel{border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);overflow:hidden}:host ::ng-deep .sk-accordion .p-accordionheader{display:flex;align-items:center;gap:8px;width:100%;padding:13px 16px;background:var(--background-grey-light, #f7f7f7);color:var(--texts-dark, #404040);font-weight:600;font-size:14px;border:none;cursor:pointer;transition:background .15s,color .15s;text-align:left}:host ::ng-deep .sk-accordion .p-accordionheader:hover{background:color-mix(in srgb,var(--color-primary, #00c73d),white 90%);color:var(--color-primary, #00c73d)}:host ::ng-deep .sk-accordion .p-accordionpanel-active>.p-accordionheader{background:color-mix(in srgb,var(--color-primary, #00c73d),white 92%);color:var(--color-primary, #00c73d);border-left:3px solid var(--color-primary, #00c73d)}:host ::ng-deep .sk-accordion .p-accordionheader-toggle-icon{color:var(--color-primary, #00c73d);margin-left:auto}:host ::ng-deep .sk-accordion .p-accordioncontent-content{padding:14px 16px;border-top:1px solid var(--stroke-grey-light, #e5e7eb)}.sk-accordion__body{font-size:14px;color:var(--texts-medium, #666);line-height:1.6;margin:0}.sk-accordion__icon{font-size:14px;color:var(--texts-medium, #888);flex-shrink:0}\n"], dependencies: [{ kind: "component", type: Accordion, selector: "p-accordion", inputs: ["value", "multiple", "styleClass", "expandIcon", "collapseIcon", "selectOnFocus", "transitionOptions", "motionOptions"], outputs: ["valueChange", "onClose", "onOpen"] }, { kind: "component", type: AccordionPanel, selector: "p-accordion-panel, p-accordionpanel", inputs: ["value", "disabled"], outputs: ["valueChange"] }, { kind: "component", type: AccordionHeader, selector: "p-accordion-header, p-accordionheader" }, { kind: "component", type: AccordionContent, selector: "p-accordion-content, p-accordioncontent" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkAccordionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-accordion', standalone: true, imports: [Accordion, AccordionPanel, AccordionHeader, AccordionContent], template: `
    <p-accordion [multiple]="multiple()" styleClass="sk-accordion">
      @for (panel of panels(); track panel.header) {
        <p-accordion-panel [value]="panel.header" [disabled]="panel.disabled ?? false">
          <p-accordion-header>
            @if (panel.icon) {
              <i class="pi pi-{{ panel.icon }} sk-accordion__icon"></i>
            }
            {{ panel.header }}
          </p-accordion-header>
          <p-accordion-content>
            <div class="sk-accordion__body">{{ panel.content }}</div>
          </p-accordion-content>
        </p-accordion-panel>
      }
    </p-accordion>
  `, styles: [":host{display:block}:host ::ng-deep .sk-accordion{display:flex;flex-direction:column;gap:6px}:host ::ng-deep .sk-accordion .p-accordionpanel{border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);overflow:hidden}:host ::ng-deep .sk-accordion .p-accordionheader{display:flex;align-items:center;gap:8px;width:100%;padding:13px 16px;background:var(--background-grey-light, #f7f7f7);color:var(--texts-dark, #404040);font-weight:600;font-size:14px;border:none;cursor:pointer;transition:background .15s,color .15s;text-align:left}:host ::ng-deep .sk-accordion .p-accordionheader:hover{background:color-mix(in srgb,var(--color-primary, #00c73d),white 90%);color:var(--color-primary, #00c73d)}:host ::ng-deep .sk-accordion .p-accordionpanel-active>.p-accordionheader{background:color-mix(in srgb,var(--color-primary, #00c73d),white 92%);color:var(--color-primary, #00c73d);border-left:3px solid var(--color-primary, #00c73d)}:host ::ng-deep .sk-accordion .p-accordionheader-toggle-icon{color:var(--color-primary, #00c73d);margin-left:auto}:host ::ng-deep .sk-accordion .p-accordioncontent-content{padding:14px 16px;border-top:1px solid var(--stroke-grey-light, #e5e7eb)}.sk-accordion__body{font-size:14px;color:var(--texts-medium, #666);line-height:1.6;margin:0}.sk-accordion__icon{font-size:14px;color:var(--texts-medium, #888);flex-shrink:0}\n"] }]
        }], propDecorators: { panels: [{ type: i0.Input, args: [{ isSignal: true, alias: "panels", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }] } });

const SEVERITY = {
    success: 'success',
    info: 'info',
    warning: 'warn',
    error: 'error',
};
class SkAlertComponent {
    variant = input('info', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    closable = input(true, { ...(ngDevMode ? { debugName: "closable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closed = output();
    _severity = computed(() => SEVERITY[this.variant()], ...(ngDevMode ? [{ debugName: "_severity" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkAlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkAlertComponent, isStandalone: true, selector: "sk-alert", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, closable: { classPropertyName: "closable", publicName: "closable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closed: "closed" }, ngImport: i0, template: `
    <p-message
      [severity]="_severity()"
      [closable]="closable()"
      (onClose)="closed.emit()"
    >
      <ng-template #icon>
        <span class="sk-alert__icon" aria-hidden="true">
          @switch (variant()) {
            @case ('warning') {
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M26.7732 22.918C27.4607 24.1211 26.6014 25.625 25.1834 25.625H6.83573C5.41776 25.625 4.55838 24.1211 5.20291 22.918L14.3982 7.27734C14.7849 6.67578 15.3865 6.375 16.031 6.375C16.6326 6.375 17.2342 6.67578 17.6209 7.27734L26.7732 22.918ZM7.26541 23.5625H24.7537L15.9881 8.65234L7.26541 23.5625ZM16.031 19.5234C16.7615 19.5234 17.3631 20.125 17.3631 20.8555C17.3631 21.5859 16.7615 22.1875 16.031 22.1875C15.2576 22.1875 14.656 21.5859 14.656 20.8555C14.656 20.125 15.2576 19.5234 16.031 19.5234ZM14.9998 12.9062C14.9998 12.3477 15.4295 11.875 16.031 11.875C16.5896 11.875 17.0623 12.3477 17.0623 12.9062V17.0312C17.0623 17.6328 16.5896 18.0625 16.031 18.0625C15.4295 18.0625 14.9998 17.6328 14.9998 17.0312V12.9062Z" fill="currentColor"/>
              </svg>
            }
            @case ('error') {
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12.5195 12.5195C12.9062 12.1328 13.5508 12.1328 13.9375 12.5195L15.957 14.582L18.0195 12.5195C18.4062 12.1328 19.0508 12.1328 19.4375 12.5195C19.8672 12.9492 19.8672 13.5938 19.4375 13.9805L17.418 16L19.4375 18.0195C19.8672 18.4492 19.8672 19.0938 19.4375 19.4805C19.0508 19.9102 18.4062 19.9102 18.0195 19.4805L15.957 17.4609L13.9375 19.4805C13.5508 19.9102 12.9062 19.9102 12.5195 19.4805C12.0898 19.0938 12.0898 18.4492 12.5195 18.0195L14.5391 16L12.5195 13.9805C12.0898 13.5938 12.0898 12.9492 12.5195 12.5195ZM27 16C27 22.1016 22.0586 27 16 27C9.89844 27 5 22.1016 5 16C5 9.94141 9.89844 5 16 5C22.0586 5 27 9.94141 27 16ZM16 7.0625C11.0586 7.0625 7.0625 11.1016 7.0625 16C7.0625 20.9414 11.0586 24.9375 16 24.9375C20.8984 24.9375 24.9375 20.9414 24.9375 16C24.9375 11.1016 20.8984 7.0625 16 7.0625Z" fill="currentColor"/>
              </svg>
            }
            @case ('info') {
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 4C22.6094 4 28 9.39062 28 16C28 22.6562 22.6094 28 16 28C9.34375 28 4 22.6562 4 16C4 9.39062 9.34375 4 16 4ZM16 25.75C21.3438 25.75 25.75 21.3906 25.75 16C25.75 10.6562 21.3438 6.25 16 6.25C10.6094 6.25 6.25 10.6562 6.25 16C6.25 21.3906 10.6094 25.75 16 25.75ZM16 18.25C15.3438 18.25 14.875 17.7812 14.875 17.125V11.125C14.875 10.5156 15.3438 10 16 10C16.6094 10 17.125 10.5156 17.125 11.125V17.125C17.125 17.7812 16.6094 18.25 16 18.25ZM16 19.8438C16.7969 19.8438 17.4531 20.5 17.4531 21.2969C17.4531 22.0938 16.7969 22.75 16 22.75C15.1562 22.75 14.5 22.0938 14.5 21.2969C14.5 20.5 15.1562 19.8438 16 19.8438Z" fill="currentColor"/>
              </svg>
            }
            @case ('success') {
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15.4414 19.6094C14.9688 20.082 14.2383 20.082 13.7656 19.6094L11.0156 16.8594C10.543 16.3867 10.543 15.6562 11.0156 15.1836C11.4883 14.7109 12.2188 14.7109 12.6914 15.1836L14.625 17.0742L19.2656 12.4336C19.7383 11.9609 20.4688 11.9609 20.9414 12.4336C21.4141 12.9062 21.4141 13.6367 20.9414 14.1094L15.4414 19.6094ZM27 16C27 22.1016 22.0586 27 16 27C9.89844 27 5 22.1016 5 16C5 9.94141 9.89844 5 16 5C22.0586 5 27 9.94141 27 16ZM16 7.0625C11.0586 7.0625 7.0625 11.1016 7.0625 16C7.0625 20.9414 11.0586 24.9375 16 24.9375C20.8984 24.9375 24.9375 20.9414 24.9375 16C24.9375 11.1016 20.8984 7.0625 16 7.0625Z" fill="currentColor"/>
              </svg>
            }
          }
        </span>
      </ng-template>

      <ng-template #container>
        <div class="sk-alert__content">
          @if (title()) {
            <p class="sk-alert__title">{{ title() }}</p>
          }
          @if (description()) {
            <p class="sk-alert__desc">{{ description() }}</p>
          }
        </div>
      </ng-template>
    </p-message>
  `, isInline: true, styles: [":host{display:block;width:100%}:host ::ng-deep .p-message{border-radius:var(--size-xs, 8px)!important;border:none!important;outline:none!important;box-shadow:none!important;width:100%!important;box-sizing:border-box!important;padding:0!important;margin:0!important}:host ::ng-deep .p-message-content-wrapper{padding:8px!important;margin:0!important}:host ::ng-deep .p-message-content{display:flex!important;align-items:center!important;gap:8px!important;padding:0!important;margin:0!important}:host ::ng-deep .p-message-success{background:var(--background-success-light, #ecfdf3)!important;border:1px solid var(--stroke-success, #16d727)!important;box-shadow:none!important;color:var(--texts-dark, #404040)!important}:host ::ng-deep .p-message-info{background:var(--background-info-light, #ebf4ff)!important;border:1px solid var(--stroke-info, #0099de)!important;box-shadow:none!important;color:var(--texts-dark, #404040)!important}:host ::ng-deep .p-message-warn{background:var(--background-warning-light, #fff3e0)!important;border:1px solid var(--stroke-warning, #ffae08)!important;box-shadow:none!important;color:var(--texts-dark, #404040)!important}:host ::ng-deep .p-message-error{background:var(--background-error-light, #fff5f4)!important;border:1px solid var(--stroke-error-dark, #e03430)!important;box-shadow:none!important;color:var(--texts-dark, #404040)!important}.sk-alert__icon{flex-shrink:0;display:flex;align-items:center;justify-content:center;width:32px;height:32px}:host ::ng-deep .p-message-success .sk-alert__icon{color:var(--icon-brand, #00c73d)}:host ::ng-deep .p-message-info .sk-alert__icon{color:var(--icon-link, #0099de)}:host ::ng-deep .p-message-warn .sk-alert__icon{color:var(--icon-warning, #ffae08)}:host ::ng-deep .p-message-error .sk-alert__icon{color:var(--icon-error, #e03430)}.sk-alert__content{flex:1;min-width:0;display:flex;flex-direction:column}.sk-alert__title{margin:0;font-family:var(--body, \"Open Sans\", sans-serif);font-size:14px;font-weight:700;line-height:22px;color:var(--texts-dark, #404040)}.sk-alert__desc{margin:0;font-family:var(--body, \"Open Sans\", sans-serif);font-size:14px;font-weight:400;line-height:22px;color:var(--texts-dark, #404040)}:host ::ng-deep .p-message-close-button{flex-shrink:0!important;margin-left:auto!important;width:24px!important;height:24px!important;padding:0!important;background:transparent!important;border:none!important;cursor:pointer!important;color:var(--texts-dark, #404040)!important;border-radius:4px!important;opacity:.55!important;transition:opacity .15s ease!important}:host ::ng-deep .p-message-close-button:hover{opacity:1!important}:host ::ng-deep .p-message-close-icon{width:12px!important;height:12px!important}\n"], dependencies: [{ kind: "component", type: Message, selector: "p-message", inputs: ["severity", "text", "escape", "style", "styleClass", "closable", "icon", "closeIcon", "life", "showTransitionOptions", "hideTransitionOptions", "size", "variant", "motionOptions"], outputs: ["onClose"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkAlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-alert', standalone: true, imports: [Message], template: `
    <p-message
      [severity]="_severity()"
      [closable]="closable()"
      (onClose)="closed.emit()"
    >
      <ng-template #icon>
        <span class="sk-alert__icon" aria-hidden="true">
          @switch (variant()) {
            @case ('warning') {
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M26.7732 22.918C27.4607 24.1211 26.6014 25.625 25.1834 25.625H6.83573C5.41776 25.625 4.55838 24.1211 5.20291 22.918L14.3982 7.27734C14.7849 6.67578 15.3865 6.375 16.031 6.375C16.6326 6.375 17.2342 6.67578 17.6209 7.27734L26.7732 22.918ZM7.26541 23.5625H24.7537L15.9881 8.65234L7.26541 23.5625ZM16.031 19.5234C16.7615 19.5234 17.3631 20.125 17.3631 20.8555C17.3631 21.5859 16.7615 22.1875 16.031 22.1875C15.2576 22.1875 14.656 21.5859 14.656 20.8555C14.656 20.125 15.2576 19.5234 16.031 19.5234ZM14.9998 12.9062C14.9998 12.3477 15.4295 11.875 16.031 11.875C16.5896 11.875 17.0623 12.3477 17.0623 12.9062V17.0312C17.0623 17.6328 16.5896 18.0625 16.031 18.0625C15.4295 18.0625 14.9998 17.6328 14.9998 17.0312V12.9062Z" fill="currentColor"/>
              </svg>
            }
            @case ('error') {
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12.5195 12.5195C12.9062 12.1328 13.5508 12.1328 13.9375 12.5195L15.957 14.582L18.0195 12.5195C18.4062 12.1328 19.0508 12.1328 19.4375 12.5195C19.8672 12.9492 19.8672 13.5938 19.4375 13.9805L17.418 16L19.4375 18.0195C19.8672 18.4492 19.8672 19.0938 19.4375 19.4805C19.0508 19.9102 18.4062 19.9102 18.0195 19.4805L15.957 17.4609L13.9375 19.4805C13.5508 19.9102 12.9062 19.9102 12.5195 19.4805C12.0898 19.0938 12.0898 18.4492 12.5195 18.0195L14.5391 16L12.5195 13.9805C12.0898 13.5938 12.0898 12.9492 12.5195 12.5195ZM27 16C27 22.1016 22.0586 27 16 27C9.89844 27 5 22.1016 5 16C5 9.94141 9.89844 5 16 5C22.0586 5 27 9.94141 27 16ZM16 7.0625C11.0586 7.0625 7.0625 11.1016 7.0625 16C7.0625 20.9414 11.0586 24.9375 16 24.9375C20.8984 24.9375 24.9375 20.9414 24.9375 16C24.9375 11.1016 20.8984 7.0625 16 7.0625Z" fill="currentColor"/>
              </svg>
            }
            @case ('info') {
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 4C22.6094 4 28 9.39062 28 16C28 22.6562 22.6094 28 16 28C9.34375 28 4 22.6562 4 16C4 9.39062 9.34375 4 16 4ZM16 25.75C21.3438 25.75 25.75 21.3906 25.75 16C25.75 10.6562 21.3438 6.25 16 6.25C10.6094 6.25 6.25 10.6562 6.25 16C6.25 21.3906 10.6094 25.75 16 25.75ZM16 18.25C15.3438 18.25 14.875 17.7812 14.875 17.125V11.125C14.875 10.5156 15.3438 10 16 10C16.6094 10 17.125 10.5156 17.125 11.125V17.125C17.125 17.7812 16.6094 18.25 16 18.25ZM16 19.8438C16.7969 19.8438 17.4531 20.5 17.4531 21.2969C17.4531 22.0938 16.7969 22.75 16 22.75C15.1562 22.75 14.5 22.0938 14.5 21.2969C14.5 20.5 15.1562 19.8438 16 19.8438Z" fill="currentColor"/>
              </svg>
            }
            @case ('success') {
              <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M15.4414 19.6094C14.9688 20.082 14.2383 20.082 13.7656 19.6094L11.0156 16.8594C10.543 16.3867 10.543 15.6562 11.0156 15.1836C11.4883 14.7109 12.2188 14.7109 12.6914 15.1836L14.625 17.0742L19.2656 12.4336C19.7383 11.9609 20.4688 11.9609 20.9414 12.4336C21.4141 12.9062 21.4141 13.6367 20.9414 14.1094L15.4414 19.6094ZM27 16C27 22.1016 22.0586 27 16 27C9.89844 27 5 22.1016 5 16C5 9.94141 9.89844 5 16 5C22.0586 5 27 9.94141 27 16ZM16 7.0625C11.0586 7.0625 7.0625 11.1016 7.0625 16C7.0625 20.9414 11.0586 24.9375 16 24.9375C20.8984 24.9375 24.9375 20.9414 24.9375 16C24.9375 11.1016 20.8984 7.0625 16 7.0625Z" fill="currentColor"/>
              </svg>
            }
          }
        </span>
      </ng-template>

      <ng-template #container>
        <div class="sk-alert__content">
          @if (title()) {
            <p class="sk-alert__title">{{ title() }}</p>
          }
          @if (description()) {
            <p class="sk-alert__desc">{{ description() }}</p>
          }
        </div>
      </ng-template>
    </p-message>
  `, styles: [":host{display:block;width:100%}:host ::ng-deep .p-message{border-radius:var(--size-xs, 8px)!important;border:none!important;outline:none!important;box-shadow:none!important;width:100%!important;box-sizing:border-box!important;padding:0!important;margin:0!important}:host ::ng-deep .p-message-content-wrapper{padding:8px!important;margin:0!important}:host ::ng-deep .p-message-content{display:flex!important;align-items:center!important;gap:8px!important;padding:0!important;margin:0!important}:host ::ng-deep .p-message-success{background:var(--background-success-light, #ecfdf3)!important;border:1px solid var(--stroke-success, #16d727)!important;box-shadow:none!important;color:var(--texts-dark, #404040)!important}:host ::ng-deep .p-message-info{background:var(--background-info-light, #ebf4ff)!important;border:1px solid var(--stroke-info, #0099de)!important;box-shadow:none!important;color:var(--texts-dark, #404040)!important}:host ::ng-deep .p-message-warn{background:var(--background-warning-light, #fff3e0)!important;border:1px solid var(--stroke-warning, #ffae08)!important;box-shadow:none!important;color:var(--texts-dark, #404040)!important}:host ::ng-deep .p-message-error{background:var(--background-error-light, #fff5f4)!important;border:1px solid var(--stroke-error-dark, #e03430)!important;box-shadow:none!important;color:var(--texts-dark, #404040)!important}.sk-alert__icon{flex-shrink:0;display:flex;align-items:center;justify-content:center;width:32px;height:32px}:host ::ng-deep .p-message-success .sk-alert__icon{color:var(--icon-brand, #00c73d)}:host ::ng-deep .p-message-info .sk-alert__icon{color:var(--icon-link, #0099de)}:host ::ng-deep .p-message-warn .sk-alert__icon{color:var(--icon-warning, #ffae08)}:host ::ng-deep .p-message-error .sk-alert__icon{color:var(--icon-error, #e03430)}.sk-alert__content{flex:1;min-width:0;display:flex;flex-direction:column}.sk-alert__title{margin:0;font-family:var(--body, \"Open Sans\", sans-serif);font-size:14px;font-weight:700;line-height:22px;color:var(--texts-dark, #404040)}.sk-alert__desc{margin:0;font-family:var(--body, \"Open Sans\", sans-serif);font-size:14px;font-weight:400;line-height:22px;color:var(--texts-dark, #404040)}:host ::ng-deep .p-message-close-button{flex-shrink:0!important;margin-left:auto!important;width:24px!important;height:24px!important;padding:0!important;background:transparent!important;border:none!important;cursor:pointer!important;color:var(--texts-dark, #404040)!important;border-radius:4px!important;opacity:.55!important;transition:opacity .15s ease!important}:host ::ng-deep .p-message-close-button:hover{opacity:1!important}:host ::ng-deep .p-message-close-icon{width:12px!important;height:12px!important}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], closable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closable", required: false }] }], closed: [{ type: i0.Output, args: ["closed"] }] } });

let _autocompleteUid = 0;
class SkAutoCompleteComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    items = input(['Angular', 'React', 'Vue', 'Svelte', 'Ember', 'Next.js', 'Nuxt', 'Astro'], ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    helpText = input('', ...(ngDevMode ? [{ debugName: "helpText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    dropdown = input(true, { ...(ngDevMode ? { debugName: "dropdown" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    multiple = input(false, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    selected = output();
    inputId = `sk-autocomplete-${_autocompleteUid++}`;
    _value = signal(null, ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    filteredItems = [];
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    _onTouched = () => { };
    handleInput(val) {
        this._value.set(val);
        this._onChange(val);
        this.valueChange.emit(val);
    }
    handleBlur() { this._onTouched(); }
    filterItems(event) {
        const q = event.query.toLowerCase();
        this.filteredItems = this.items().filter(i => i.toLowerCase().includes(q));
    }
    writeValue(val) { this._value.set(val ?? null); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this._onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkAutoCompleteComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkAutoCompleteComponent, isStandalone: true, selector: "sk-autocomplete", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, dropdown: { classPropertyName: "dropdown", publicName: "dropdown", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange", selected: "selected" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkAutoCompleteComponent), multi: true }], ngImport: i0, template: "<div\r\n  class=\"sk-autocomplete\"\r\n  [class.sk-autocomplete--fluid]=\"fluid()\"\r\n  [class.sk-autocomplete--invalid]=\"invalid()\"\r\n  [class.sk-autocomplete--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-autocomplete__floatlabel\">\r\n    <p-autocomplete\r\n      [inputId]=\"inputId\"\r\n      [ngModel]=\"_value()\"\r\n      (ngModelChange)=\"handleInput($event)\"\r\n      [suggestions]=\"filteredItems\"\r\n      [dropdown]=\"dropdown()\"\r\n      [multiple]=\"multiple()\"\r\n      [disabled]=\"_isDisabled()\"\r\n      [invalid]=\"invalid()\"\r\n      [fluid]=\"fluid()\"\r\n      [forceSelection]=\"false\"\r\n      (completeMethod)=\"filterItems($event)\"\r\n      (onSelect)=\"selected.emit($event)\"\r\n      (onBlur)=\"handleBlur()\"\r\n      class=\"sk-autocomplete__field\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-autocomplete__help sk-autocomplete__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-autocomplete__help\" [class.sk-autocomplete__help--error]=\"invalid()\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-autocomplete{display:flex;flex-direction:column;gap:4px}.sk-autocomplete--fluid,.sk-autocomplete--fluid .sk-autocomplete__floatlabel,.sk-autocomplete--fluid .sk-autocomplete__field{width:100%}::ng-deep .sk-autocomplete__field.p-autocomplete{width:100%;min-height:var(--size-048, 48px);border-radius:var(--bordes-s);border:1px solid var(--stroke-grey-light, #dddddd);background:var(--background-principal, #ffffff);box-sizing:border-box;transition:border-color .15s ease;display:flex;align-items:stretch}::ng-deep .sk-autocomplete__field .p-autocomplete-input{flex:1;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline:12px;border:none!important;border-radius:var(--bordes-s) 0 0 var(--bordes-s);background:transparent;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);color:var(--texts-dark, #404040);box-sizing:border-box;box-shadow:none;outline:none}::ng-deep .sk-autocomplete__field .p-autocomplete-dropdown{background:transparent!important;border:none!important;box-shadow:none!important;color:var(--texts-medium, #666666);padding-inline:12px;flex-shrink:0}::ng-deep .sk-autocomplete__floatlabel label{font-size:14px}.sk-autocomplete:not(.sk-autocomplete--disabled):not(.sk-autocomplete--invalid):focus-within ::ng-deep .sk-autocomplete__field.p-autocomplete{border-color:var(--stroke-brand, #00c73d)}::ng-deep .sk-autocomplete--invalid .sk-autocomplete__field.p-autocomplete{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-autocomplete--disabled .sk-autocomplete__field.p-autocomplete{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;cursor:not-allowed}::ng-deep .sk-autocomplete--disabled .sk-autocomplete__field .p-autocomplete-input{color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-autocomplete__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-autocomplete__help--error{color:var(--color-error, #e03430)}\n"], dependencies: [{ kind: "component", type: AutoComplete, selector: "p-autoComplete, p-autocomplete, p-auto-complete", inputs: ["minLength", "minQueryLength", "delay", "panelStyle", "styleClass", "panelStyleClass", "inputStyle", "inputId", "inputStyleClass", "placeholder", "readonly", "scrollHeight", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "autoHighlight", "forceSelection", "type", "autoZIndex", "baseZIndex", "ariaLabel", "dropdownAriaLabel", "ariaLabelledBy", "dropdownIcon", "unique", "group", "completeOnFocus", "showClear", "dropdown", "showEmptyMessage", "dropdownMode", "multiple", "addOnTab", "tabindex", "dataKey", "emptyMessage", "showTransitionOptions", "hideTransitionOptions", "autofocus", "autocomplete", "optionGroupChildren", "optionGroupLabel", "overlayOptions", "suggestions", "optionLabel", "optionValue", "id", "searchMessage", "emptySelectionMessage", "selectionMessage", "autoOptionFocus", "selectOnFocus", "searchLocale", "optionDisabled", "focusOnHover", "typeahead", "addOnBlur", "separator", "appendTo", "motionOptions"], outputs: ["completeMethod", "onSelect", "onUnselect", "onAdd", "onFocus", "onBlur", "onDropdownClick", "onClear", "onInputKeydown", "onKeyUp", "onShow", "onHide", "onLazyLoad"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkAutoCompleteComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-autocomplete', standalone: true, imports: [AutoComplete, FloatLabel, FormsModule], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkAutoCompleteComponent), multi: true }], template: "<div\r\n  class=\"sk-autocomplete\"\r\n  [class.sk-autocomplete--fluid]=\"fluid()\"\r\n  [class.sk-autocomplete--invalid]=\"invalid()\"\r\n  [class.sk-autocomplete--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-autocomplete__floatlabel\">\r\n    <p-autocomplete\r\n      [inputId]=\"inputId\"\r\n      [ngModel]=\"_value()\"\r\n      (ngModelChange)=\"handleInput($event)\"\r\n      [suggestions]=\"filteredItems\"\r\n      [dropdown]=\"dropdown()\"\r\n      [multiple]=\"multiple()\"\r\n      [disabled]=\"_isDisabled()\"\r\n      [invalid]=\"invalid()\"\r\n      [fluid]=\"fluid()\"\r\n      [forceSelection]=\"false\"\r\n      (completeMethod)=\"filterItems($event)\"\r\n      (onSelect)=\"selected.emit($event)\"\r\n      (onBlur)=\"handleBlur()\"\r\n      class=\"sk-autocomplete__field\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-autocomplete__help sk-autocomplete__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-autocomplete__help\" [class.sk-autocomplete__help--error]=\"invalid()\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-autocomplete{display:flex;flex-direction:column;gap:4px}.sk-autocomplete--fluid,.sk-autocomplete--fluid .sk-autocomplete__floatlabel,.sk-autocomplete--fluid .sk-autocomplete__field{width:100%}::ng-deep .sk-autocomplete__field.p-autocomplete{width:100%;min-height:var(--size-048, 48px);border-radius:var(--bordes-s);border:1px solid var(--stroke-grey-light, #dddddd);background:var(--background-principal, #ffffff);box-sizing:border-box;transition:border-color .15s ease;display:flex;align-items:stretch}::ng-deep .sk-autocomplete__field .p-autocomplete-input{flex:1;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline:12px;border:none!important;border-radius:var(--bordes-s) 0 0 var(--bordes-s);background:transparent;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);color:var(--texts-dark, #404040);box-sizing:border-box;box-shadow:none;outline:none}::ng-deep .sk-autocomplete__field .p-autocomplete-dropdown{background:transparent!important;border:none!important;box-shadow:none!important;color:var(--texts-medium, #666666);padding-inline:12px;flex-shrink:0}::ng-deep .sk-autocomplete__floatlabel label{font-size:14px}.sk-autocomplete:not(.sk-autocomplete--disabled):not(.sk-autocomplete--invalid):focus-within ::ng-deep .sk-autocomplete__field.p-autocomplete{border-color:var(--stroke-brand, #00c73d)}::ng-deep .sk-autocomplete--invalid .sk-autocomplete__field.p-autocomplete{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-autocomplete--disabled .sk-autocomplete__field.p-autocomplete{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;cursor:not-allowed}::ng-deep .sk-autocomplete--disabled .sk-autocomplete__field .p-autocomplete-input{color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-autocomplete__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-autocomplete__help--error{color:var(--color-error, #e03430)}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], helpText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helpText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], dropdown: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdown", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], selected: [{ type: i0.Output, args: ["selected"] }] } });

class SkBadgeComponent {
    variant = input('info', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    type = input('fill', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    size = input('medium', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    count = input(null, ...(ngDevMode ? [{ debugName: "count" }] : /* istanbul ignore next */ []));
    showIcon = input(false, { ...(ngDevMode ? { debugName: "showIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    // compat aliases kept for catalog / existing integrations
    value = input(undefined, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    severity = input(undefined, ...(ngDevMode ? [{ debugName: "severity" }] : /* istanbul ignore next */ []));
    rounded = input(false, { ...(ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    icon = input(undefined, ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    styleClass = input(undefined, ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    resolvedShowIcon = computed(() => this.showIcon(), ...(ngDevMode ? [{ debugName: "resolvedShowIcon" }] : /* istanbul ignore next */ []));
    resolvedCount = computed(() => this.count() !== null ? String(this.count()) : '', ...(ngDevMode ? [{ debugName: "resolvedCount" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => {
        const cls = [
            'sk-badge',
            `sk-badge--${this.size()}`,
            `sk-badge--${this.type()}`,
            `sk-badge--${this.variant()}`,
        ];
        if (this.styleClass())
            cls.push(this.styleClass());
        return cls.join(' ');
    }, ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkBadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkBadgeComponent, isStandalone: true, selector: "sk-badge", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, count: { classPropertyName: "count", publicName: "count", isSignal: true, isRequired: false, transformFunction: null }, showIcon: { classPropertyName: "showIcon", publicName: "showIcon", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, severity: { classPropertyName: "severity", publicName: "severity", isSignal: true, isRequired: false, transformFunction: null }, rounded: { classPropertyName: "rounded", publicName: "rounded", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if (size() === 'mini') {\r\n      <span [class]=\"hostClasses()\" role=\"status\" [attr.aria-label]=\"'Estado: ' + variant()\"></span>\r\n    } @else if (size() === 'square') {\r\n      <span [class]=\"hostClasses()\">\r\n        @if (resolvedShowIcon()) {\r\n          <span class=\"sk-badge__icon\" aria-hidden=\"true\">\r\n            @switch (variant()) {\r\n              @case ('success') {\r\n                <svg width=\"14\" height=\"14\" viewBox=\"0 0 32 32\" fill=\"none\">\r\n                  <path d=\"M15.4414 19.6094C14.9688 20.082 14.2383 20.082 13.7656 19.6094L11.0156 16.8594C10.543 16.3867 10.543 15.6562 11.0156 15.1836C11.4883 14.7109 12.2188 14.7109 12.6914 15.1836L14.625 17.0742L19.2656 12.4336C19.7383 11.9609 20.4688 11.9609 20.9414 12.4336C21.4141 12.9062 21.4141 13.6367 20.9414 14.1094L15.4414 19.6094ZM27 16C27 22.1016 22.0586 27 16 27C9.89844 27 5 22.1016 5 16C5 9.94141 9.89844 5 16 5C22.0586 5 27 9.94141 27 16ZM16 7.0625C11.0586 7.0625 7.0625 11.1016 7.0625 16C7.0625 20.9414 11.0586 24.9375 16 24.9375C20.8984 24.9375 24.9375 20.9414 24.9375 16C24.9375 11.1016 20.8984 7.0625 16 7.0625Z\" fill=\"currentColor\"/>\r\n                </svg>\r\n              }\r\n              @case ('warning') {\r\n                <svg width=\"14\" height=\"14\" viewBox=\"0 0 32 32\" fill=\"none\">\r\n                  <path d=\"M26.7732 22.918C27.4607 24.1211 26.6014 25.625 25.1834 25.625H6.83573C5.41776 25.625 4.55838 24.1211 5.20291 22.918L14.3982 7.27734C14.7849 6.67578 15.3865 6.375 16.031 6.375C16.6326 6.375 17.2342 6.67578 17.6209 7.27734L26.7732 22.918ZM7.26541 23.5625H24.7537L15.9881 8.65234L7.26541 23.5625ZM16.031 19.5234C16.7615 19.5234 17.3631 20.125 17.3631 20.8555C17.3631 21.5859 16.7615 22.1875 16.031 22.1875C15.2576 22.1875 14.656 21.5859 14.656 20.8555C14.656 20.125 15.2576 19.5234 16.031 19.5234ZM14.9998 12.9062C14.9998 12.3477 15.4295 11.875 16.031 11.875C16.5896 11.875 17.0623 12.3477 17.0623 12.9062V17.0312C17.0623 17.6328 16.5896 18.0625 16.031 18.0625C15.4295 18.0625 14.9998 17.6328 14.9998 17.0312V12.9062Z\" fill=\"currentColor\"/>\r\n                </svg>\r\n              }\r\n              @case ('info') {\r\n                <svg width=\"14\" height=\"14\" viewBox=\"0 0 32 32\" fill=\"none\">\r\n                  <path d=\"M16 4C22.6094 4 28 9.39062 28 16C28 22.6562 22.6094 28 16 28C9.34375 28 4 22.6562 4 16C4 9.39062 9.34375 4 16 4ZM16 25.75C21.3438 25.75 25.75 21.3906 25.75 16C25.75 10.6562 21.3438 6.25 16 6.25C10.6094 6.25 6.25 10.6562 6.25 16C6.25 21.3906 10.6094 25.75 16 25.75ZM16 18.25C15.3438 18.25 14.875 17.7812 14.875 17.125V11.125C14.875 10.5156 15.3438 10 16 10C16.6094 10 17.125 10.5156 17.125 11.125V17.125C17.125 17.7812 16.6094 18.25 16 18.25ZM16 19.8438C16.7969 19.8438 17.4531 20.5 17.4531 21.2969C17.4531 22.0938 16.7969 22.75 16 22.75C15.1562 22.75 14.5 22.0938 14.5 21.2969C14.5 20.5 15.1562 19.8438 16 19.8438Z\" fill=\"currentColor\"/>\r\n                </svg>\r\n              }\r\n              @case ('error') {\r\n                <svg width=\"14\" height=\"14\" viewBox=\"0 0 32 32\" fill=\"none\">\r\n                  <path d=\"M12.5195 12.5195C12.9062 12.1328 13.5508 12.1328 13.9375 12.5195L15.957 14.582L18.0195 12.5195C18.4062 12.1328 19.0508 12.1328 19.4375 12.5195C19.8672 12.9492 19.8672 13.5938 19.4375 13.9805L17.418 16L19.4375 18.0195C19.8672 18.4492 19.8672 19.0938 19.4375 19.4805C19.0508 19.9102 18.4062 19.9102 18.0195 19.4805L15.957 17.4609L13.9375 19.4805C13.5508 19.9102 12.9062 19.9102 12.5195 19.4805C12.0898 19.0938 12.0898 18.4492 12.5195 18.0195L14.5391 16L12.5195 13.9805C12.0898 13.5938 12.0898 12.9492 12.5195 12.5195ZM27 16C27 22.1016 22.0586 27 16 27C9.89844 27 5 22.1016 5 16C5 9.94141 9.89844 5 16 5C22.0586 5 27 9.94141 27 16ZM16 7.0625C11.0586 7.0625 7.0625 11.1016 7.0625 16C7.0625 20.9414 11.0586 24.9375 16 24.9375C20.8984 24.9375 24.9375 20.9414 24.9375 16C24.9375 11.1016 20.8984 7.0625 16 7.0625Z\" fill=\"currentColor\"/>\r\n                </svg>\r\n              }\r\n            }\r\n          </span>\r\n        }\r\n        @if (label()) {\r\n          <span class=\"sk-badge__label\">{{ label() }}</span>\r\n        }\r\n      </span>\r\n    } @else {\r\n      <span [class]=\"hostClasses()\">\r\n        <span class=\"sk-badge__count\">{{ label() || resolvedCount() }}</span>\r\n      </span>\r\n    }\r\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex;align-items:center}.sk-badge{display:inline-flex;align-items:center;justify-content:center;font-family:var(--label-medium-font, \"Open Sans\", sans-serif);font-size:var(--label-medium-size, .875rem);font-weight:var(--label-medium-weight, 500);line-height:var(--label-medium-line-height, 1.375rem);letter-spacing:var(--label-medium-tracking, 0);box-sizing:border-box;border:1px solid transparent}.sk-badge--mini{width:var(--size-xs, 8px);height:var(--size-xs, 8px);border-radius:50%}.sk-badge--square{min-height:38px;gap:var(--size-xxs, 4px);padding:0 var(--size-xs, 8px);border-radius:6px}.sk-badge--medium{width:var(--size-m, 16px);height:var(--size-m, 16px);border-radius:50%;font-size:10px;line-height:1;overflow:hidden}.sk-badge--large{width:var(--size-l, 24px);height:var(--size-l, 24px);border-radius:50%;font-size:12px;line-height:1;overflow:hidden}.sk-badge--fill.sk-badge--success{background:var(--background-success-dark);border-color:var(--stroke-success);color:var(--texts-dark)}.sk-badge--fill.sk-badge--warning{background:var(--background-warning-dark);border-color:var(--stroke-warning);color:var(--texts-dark)}.sk-badge--fill.sk-badge--info{background:var(--background-info-dark);border-color:var(--stroke-info);color:var(--icon-white, #ffffff)}.sk-badge--fill.sk-badge--error{background:var(--background-error-dark);border-color:var(--stroke-error-dark);color:var(--icon-white, #ffffff)}.sk-badge--mini.sk-badge--fill{border-color:transparent}.sk-badge--stroke.sk-badge--success{background:var(--background-success-light);border-color:var(--stroke-success);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--warning{background:var(--background-warning-light);border-color:var(--stroke-warning);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--info{background:var(--background-info-light);border-color:var(--stroke-info);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--error{background:var(--background-error-light);border-color:var(--stroke-error-dark);color:var(--background-error-dark)}.sk-badge--mini.sk-badge--stroke{background:transparent}.sk-badge__icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:14px;height:14px}.sk-badge__count{font-size:inherit;line-height:inherit}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkBadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-badge', standalone: true, template: "@if (size() === 'mini') {\r\n      <span [class]=\"hostClasses()\" role=\"status\" [attr.aria-label]=\"'Estado: ' + variant()\"></span>\r\n    } @else if (size() === 'square') {\r\n      <span [class]=\"hostClasses()\">\r\n        @if (resolvedShowIcon()) {\r\n          <span class=\"sk-badge__icon\" aria-hidden=\"true\">\r\n            @switch (variant()) {\r\n              @case ('success') {\r\n                <svg width=\"14\" height=\"14\" viewBox=\"0 0 32 32\" fill=\"none\">\r\n                  <path d=\"M15.4414 19.6094C14.9688 20.082 14.2383 20.082 13.7656 19.6094L11.0156 16.8594C10.543 16.3867 10.543 15.6562 11.0156 15.1836C11.4883 14.7109 12.2188 14.7109 12.6914 15.1836L14.625 17.0742L19.2656 12.4336C19.7383 11.9609 20.4688 11.9609 20.9414 12.4336C21.4141 12.9062 21.4141 13.6367 20.9414 14.1094L15.4414 19.6094ZM27 16C27 22.1016 22.0586 27 16 27C9.89844 27 5 22.1016 5 16C5 9.94141 9.89844 5 16 5C22.0586 5 27 9.94141 27 16ZM16 7.0625C11.0586 7.0625 7.0625 11.1016 7.0625 16C7.0625 20.9414 11.0586 24.9375 16 24.9375C20.8984 24.9375 24.9375 20.9414 24.9375 16C24.9375 11.1016 20.8984 7.0625 16 7.0625Z\" fill=\"currentColor\"/>\r\n                </svg>\r\n              }\r\n              @case ('warning') {\r\n                <svg width=\"14\" height=\"14\" viewBox=\"0 0 32 32\" fill=\"none\">\r\n                  <path d=\"M26.7732 22.918C27.4607 24.1211 26.6014 25.625 25.1834 25.625H6.83573C5.41776 25.625 4.55838 24.1211 5.20291 22.918L14.3982 7.27734C14.7849 6.67578 15.3865 6.375 16.031 6.375C16.6326 6.375 17.2342 6.67578 17.6209 7.27734L26.7732 22.918ZM7.26541 23.5625H24.7537L15.9881 8.65234L7.26541 23.5625ZM16.031 19.5234C16.7615 19.5234 17.3631 20.125 17.3631 20.8555C17.3631 21.5859 16.7615 22.1875 16.031 22.1875C15.2576 22.1875 14.656 21.5859 14.656 20.8555C14.656 20.125 15.2576 19.5234 16.031 19.5234ZM14.9998 12.9062C14.9998 12.3477 15.4295 11.875 16.031 11.875C16.5896 11.875 17.0623 12.3477 17.0623 12.9062V17.0312C17.0623 17.6328 16.5896 18.0625 16.031 18.0625C15.4295 18.0625 14.9998 17.6328 14.9998 17.0312V12.9062Z\" fill=\"currentColor\"/>\r\n                </svg>\r\n              }\r\n              @case ('info') {\r\n                <svg width=\"14\" height=\"14\" viewBox=\"0 0 32 32\" fill=\"none\">\r\n                  <path d=\"M16 4C22.6094 4 28 9.39062 28 16C28 22.6562 22.6094 28 16 28C9.34375 28 4 22.6562 4 16C4 9.39062 9.34375 4 16 4ZM16 25.75C21.3438 25.75 25.75 21.3906 25.75 16C25.75 10.6562 21.3438 6.25 16 6.25C10.6094 6.25 6.25 10.6562 6.25 16C6.25 21.3906 10.6094 25.75 16 25.75ZM16 18.25C15.3438 18.25 14.875 17.7812 14.875 17.125V11.125C14.875 10.5156 15.3438 10 16 10C16.6094 10 17.125 10.5156 17.125 11.125V17.125C17.125 17.7812 16.6094 18.25 16 18.25ZM16 19.8438C16.7969 19.8438 17.4531 20.5 17.4531 21.2969C17.4531 22.0938 16.7969 22.75 16 22.75C15.1562 22.75 14.5 22.0938 14.5 21.2969C14.5 20.5 15.1562 19.8438 16 19.8438Z\" fill=\"currentColor\"/>\r\n                </svg>\r\n              }\r\n              @case ('error') {\r\n                <svg width=\"14\" height=\"14\" viewBox=\"0 0 32 32\" fill=\"none\">\r\n                  <path d=\"M12.5195 12.5195C12.9062 12.1328 13.5508 12.1328 13.9375 12.5195L15.957 14.582L18.0195 12.5195C18.4062 12.1328 19.0508 12.1328 19.4375 12.5195C19.8672 12.9492 19.8672 13.5938 19.4375 13.9805L17.418 16L19.4375 18.0195C19.8672 18.4492 19.8672 19.0938 19.4375 19.4805C19.0508 19.9102 18.4062 19.9102 18.0195 19.4805L15.957 17.4609L13.9375 19.4805C13.5508 19.9102 12.9062 19.9102 12.5195 19.4805C12.0898 19.0938 12.0898 18.4492 12.5195 18.0195L14.5391 16L12.5195 13.9805C12.0898 13.5938 12.0898 12.9492 12.5195 12.5195ZM27 16C27 22.1016 22.0586 27 16 27C9.89844 27 5 22.1016 5 16C5 9.94141 9.89844 5 16 5C22.0586 5 27 9.94141 27 16ZM16 7.0625C11.0586 7.0625 7.0625 11.1016 7.0625 16C7.0625 20.9414 11.0586 24.9375 16 24.9375C20.8984 24.9375 24.9375 20.9414 24.9375 16C24.9375 11.1016 20.8984 7.0625 16 7.0625Z\" fill=\"currentColor\"/>\r\n                </svg>\r\n              }\r\n            }\r\n          </span>\r\n        }\r\n        @if (label()) {\r\n          <span class=\"sk-badge__label\">{{ label() }}</span>\r\n        }\r\n      </span>\r\n    } @else {\r\n      <span [class]=\"hostClasses()\">\r\n        <span class=\"sk-badge__count\">{{ label() || resolvedCount() }}</span>\r\n      </span>\r\n    }\r\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex;align-items:center}.sk-badge{display:inline-flex;align-items:center;justify-content:center;font-family:var(--label-medium-font, \"Open Sans\", sans-serif);font-size:var(--label-medium-size, .875rem);font-weight:var(--label-medium-weight, 500);line-height:var(--label-medium-line-height, 1.375rem);letter-spacing:var(--label-medium-tracking, 0);box-sizing:border-box;border:1px solid transparent}.sk-badge--mini{width:var(--size-xs, 8px);height:var(--size-xs, 8px);border-radius:50%}.sk-badge--square{min-height:38px;gap:var(--size-xxs, 4px);padding:0 var(--size-xs, 8px);border-radius:6px}.sk-badge--medium{width:var(--size-m, 16px);height:var(--size-m, 16px);border-radius:50%;font-size:10px;line-height:1;overflow:hidden}.sk-badge--large{width:var(--size-l, 24px);height:var(--size-l, 24px);border-radius:50%;font-size:12px;line-height:1;overflow:hidden}.sk-badge--fill.sk-badge--success{background:var(--background-success-dark);border-color:var(--stroke-success);color:var(--texts-dark)}.sk-badge--fill.sk-badge--warning{background:var(--background-warning-dark);border-color:var(--stroke-warning);color:var(--texts-dark)}.sk-badge--fill.sk-badge--info{background:var(--background-info-dark);border-color:var(--stroke-info);color:var(--icon-white, #ffffff)}.sk-badge--fill.sk-badge--error{background:var(--background-error-dark);border-color:var(--stroke-error-dark);color:var(--icon-white, #ffffff)}.sk-badge--mini.sk-badge--fill{border-color:transparent}.sk-badge--stroke.sk-badge--success{background:var(--background-success-light);border-color:var(--stroke-success);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--warning{background:var(--background-warning-light);border-color:var(--stroke-warning);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--info{background:var(--background-info-light);border-color:var(--stroke-info);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--error{background:var(--background-error-light);border-color:var(--stroke-error-dark);color:var(--background-error-dark)}.sk-badge--mini.sk-badge--stroke{background:transparent}.sk-badge__icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:14px;height:14px}.sk-badge__count{font-size:inherit;line-height:inherit}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], count: [{ type: i0.Input, args: [{ isSignal: true, alias: "count", required: false }] }], showIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showIcon", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], severity: [{ type: i0.Input, args: [{ isSignal: true, alias: "severity", required: false }] }], rounded: [{ type: i0.Input, args: [{ isSignal: true, alias: "rounded", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }] } });

class SkAvatarComponent {
    type = input('icon', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    size = input('large', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    src = input('', ...(ngDevMode ? [{ debugName: "src" }] : /* istanbul ignore next */ []));
    initials = input('', ...(ngDevMode ? [{ debugName: "initials" }] : /* istanbul ignore next */ []));
    badge = input(false, { ...(ngDevMode ? { debugName: "badge" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    badgeCount = input(0, ...(ngDevMode ? [{ debugName: "badgeCount" }] : /* istanbul ignore next */ []));
    active = input(false, { ...(ngDevMode ? { debugName: "active" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    image = input(undefined, ...(ngDevMode ? [{ debugName: "image" }] : /* istanbul ignore next */ []));
    label = input(undefined, ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    icon = input(undefined, ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    styleClass = input(undefined, ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    imageError = output();
    isActive = computed(() => this.active(), ...(ngDevMode ? [{ debugName: "isActive" }] : /* istanbul ignore next */ []));
    hasBadge = computed(() => this.badge(), ...(ngDevMode ? [{ debugName: "hasBadge" }] : /* istanbul ignore next */ []));
    numBadgeCount = computed(() => Number(this.badgeCount()) || 0, ...(ngDevMode ? [{ debugName: "numBadgeCount" }] : /* istanbul ignore next */ []));
    displayInitials = computed(() => (this.initials() || this.label() || '').slice(0, 2).toUpperCase(), ...(ngDevMode ? [{ debugName: "displayInitials" }] : /* istanbul ignore next */ []));
    badgeLabel = computed(() => {
        const n = this.numBadgeCount();
        if (n <= 0)
            return '';
        return n > 99 ? '99+' : String(n);
    }, ...(ngDevMode ? [{ debugName: "badgeLabel" }] : /* istanbul ignore next */ []));
    /** Dimensión interior: total (40/32px) menos 2px de padding por cada lado */
    avatarDim = computed(() => this.size() === 'large' ? '36px' : '28px', ...(ngDevMode ? [{ debugName: "avatarDim" }] : /* istanbul ignore next */ []));
    avatarStyleClass = computed(() => {
        const parts = [`sk-avatar__pv--${this.type()}`];
        if (this.styleClass())
            parts.push(this.styleClass());
        return parts.join(' ');
    }, ...(ngDevMode ? [{ debugName: "avatarStyleClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkAvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkAvatarComponent, isStandalone: true, selector: "sk-avatar", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, src: { classPropertyName: "src", publicName: "src", isSignal: true, isRequired: false, transformFunction: null }, initials: { classPropertyName: "initials", publicName: "initials", isSignal: true, isRequired: false, transformFunction: null }, badge: { classPropertyName: "badge", publicName: "badge", isSignal: true, isRequired: false, transformFunction: null }, badgeCount: { classPropertyName: "badgeCount", publicName: "badgeCount", isSignal: true, isRequired: false, transformFunction: null }, active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: false, transformFunction: null }, image: { classPropertyName: "image", publicName: "image", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { imageError: "imageError" }, ngImport: i0, template: "<div\r\n      class=\"sk-avatar-wrap\"\r\n      [class.sk-avatar-wrap--large]=\"size() === 'large'\"\r\n      [class.sk-avatar-wrap--small]=\"size() === 'small'\"\r\n      [class.sk-avatar-wrap--active]=\"isActive()\"\r\n      [attr.aria-label]=\"ariaLabel() || (initials() ? 'Avatar de ' + initials() : 'Avatar de usuario')\"\r\n      role=\"img\"\r\n    >\r\n      <p-avatar\r\n        [image]=\"type() === 'img' ? (image() || src()) : undefined\"\r\n        [label]=\"type() === 'text' ? displayInitials() : undefined\"\r\n        [icon]=\"type() === 'icon' ? (icon() || 'pi pi-user') : undefined\"\r\n        shape=\"circle\"\r\n        [style]=\"{ width: avatarDim(), height: avatarDim() }\"\r\n        [styleClass]=\"avatarStyleClass()\"\r\n        (onImageError)=\"imageError.emit($event)\"\r\n      ></p-avatar>\r\n\r\n      @if (hasBadge()) {\r\n        <span class=\"sk-avatar__badge-wrap\" aria-label=\"Notificaciones\">\r\n          <sk-badge\r\n            variant=\"error\"\r\n            type=\"fill\"\r\n            size=\"medium\"\r\n            [label]=\"badgeLabel()\"\r\n          ></sk-badge>\r\n        </span>\r\n      }\r\n    </div>\r\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}.sk-avatar-wrap{position:relative;display:inline-flex;flex-shrink:0;padding:2px;border-radius:9999px;background:transparent;overflow:visible}.sk-avatar-wrap--active{background:var(--estilos-degrade)}::ng-deep .sk-avatar__pv--text,::ng-deep .sk-avatar__pv--icon{background:var(--background-brand-light, #f6fcf2)!important;color:var(--texts-brand, #00c73d)!important;font-family:var(--title, \"Montserrat\"),sans-serif!important;font-size:var(--auxiliary-title-h6-bold-14px-size, .875rem)!important;font-weight:var(--auxiliary-title-h6-bold-14px-weight, 700)!important}.sk-avatar__badge-wrap{position:absolute;top:2px;right:2px;transform:translate(40%,-40%);line-height:0;z-index:1}\n"], dependencies: [{ kind: "component", type: Avatar, selector: "p-avatar", inputs: ["label", "icon", "image", "size", "shape", "styleClass", "ariaLabel", "ariaLabelledBy"], outputs: ["onImageError"] }, { kind: "component", type: SkBadgeComponent, selector: "sk-badge", inputs: ["variant", "type", "size", "label", "count", "showIcon", "value", "severity", "rounded", "icon", "styleClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkAvatarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-avatar', standalone: true, imports: [Avatar, SkBadgeComponent], template: "<div\r\n      class=\"sk-avatar-wrap\"\r\n      [class.sk-avatar-wrap--large]=\"size() === 'large'\"\r\n      [class.sk-avatar-wrap--small]=\"size() === 'small'\"\r\n      [class.sk-avatar-wrap--active]=\"isActive()\"\r\n      [attr.aria-label]=\"ariaLabel() || (initials() ? 'Avatar de ' + initials() : 'Avatar de usuario')\"\r\n      role=\"img\"\r\n    >\r\n      <p-avatar\r\n        [image]=\"type() === 'img' ? (image() || src()) : undefined\"\r\n        [label]=\"type() === 'text' ? displayInitials() : undefined\"\r\n        [icon]=\"type() === 'icon' ? (icon() || 'pi pi-user') : undefined\"\r\n        shape=\"circle\"\r\n        [style]=\"{ width: avatarDim(), height: avatarDim() }\"\r\n        [styleClass]=\"avatarStyleClass()\"\r\n        (onImageError)=\"imageError.emit($event)\"\r\n      ></p-avatar>\r\n\r\n      @if (hasBadge()) {\r\n        <span class=\"sk-avatar__badge-wrap\" aria-label=\"Notificaciones\">\r\n          <sk-badge\r\n            variant=\"error\"\r\n            type=\"fill\"\r\n            size=\"medium\"\r\n            [label]=\"badgeLabel()\"\r\n          ></sk-badge>\r\n        </span>\r\n      }\r\n    </div>\r\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}.sk-avatar-wrap{position:relative;display:inline-flex;flex-shrink:0;padding:2px;border-radius:9999px;background:transparent;overflow:visible}.sk-avatar-wrap--active{background:var(--estilos-degrade)}::ng-deep .sk-avatar__pv--text,::ng-deep .sk-avatar__pv--icon{background:var(--background-brand-light, #f6fcf2)!important;color:var(--texts-brand, #00c73d)!important;font-family:var(--title, \"Montserrat\"),sans-serif!important;font-size:var(--auxiliary-title-h6-bold-14px-size, .875rem)!important;font-weight:var(--auxiliary-title-h6-bold-14px-weight, 700)!important}.sk-avatar__badge-wrap{position:absolute;top:2px;right:2px;transform:translate(40%,-40%);line-height:0;z-index:1}\n"] }]
        }], propDecorators: { type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], src: [{ type: i0.Input, args: [{ isSignal: true, alias: "src", required: false }] }], initials: [{ type: i0.Input, args: [{ isSignal: true, alias: "initials", required: false }] }], badge: [{ type: i0.Input, args: [{ isSignal: true, alias: "badge", required: false }] }], badgeCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "badgeCount", required: false }] }], active: [{ type: i0.Input, args: [{ isSignal: true, alias: "active", required: false }] }], image: [{ type: i0.Input, args: [{ isSignal: true, alias: "image", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], imageError: [{ type: i0.Output, args: ["imageError"] }] } });

class SkAvatarGroupComponent {
    surplus = input(3, ...(ngDevMode ? [{ debugName: "surplus" }] : /* istanbul ignore next */ []));
    avatars = input([
        { label: 'AG', image: '', bg: 'var(--accent-1)' },
        { label: 'CL', image: '', bg: 'var(--accent-2)' },
        { label: 'MT', image: '', bg: 'var(--accent-4)' },
        { label: 'JM', image: '', bg: 'var(--accent-5)' },
    ], ...(ngDevMode ? [{ debugName: "avatars" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkAvatarGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkAvatarGroupComponent, isStandalone: true, selector: "sk-avatargroup", inputs: { surplus: { classPropertyName: "surplus", publicName: "surplus", isSignal: true, isRequired: false, transformFunction: null }, avatars: { classPropertyName: "avatars", publicName: "avatars", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-avatargroup [style]="{ marginBottom: '8px' }">
      @for (av of avatars(); track av.label) {
        <p-avatar [label]="av.label" [image]="av.image" shape="circle" size="large" [style]="{ background: av.bg, color: 'var(--color-white)' }" />
      }
      @if (surplus() > 0) {
        <p-avatar [label]="'+' + surplus()" shape="circle" size="large" [style]="{ background: 'var(--p-surface-300,#d1d5db)', color: 'var(--p-surface-700,#374151)' }" />
      }
    </p-avatargroup>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: AvatarGroup, selector: "p-avatarGroup, p-avatar-group, p-avatargroup", inputs: ["styleClass", "style"] }, { kind: "component", type: Avatar, selector: "p-avatar", inputs: ["label", "icon", "image", "size", "shape", "styleClass", "ariaLabel", "ariaLabelledBy"], outputs: ["onImageError"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkAvatarGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-avatargroup', standalone: true, imports: [AvatarGroup, Avatar], template: `
    <p-avatargroup [style]="{ marginBottom: '8px' }">
      @for (av of avatars(); track av.label) {
        <p-avatar [label]="av.label" [image]="av.image" shape="circle" size="large" [style]="{ background: av.bg, color: 'var(--color-white)' }" />
      }
      @if (surplus() > 0) {
        <p-avatar [label]="'+' + surplus()" shape="circle" size="large" [style]="{ background: 'var(--p-surface-300,#d1d5db)', color: 'var(--p-surface-700,#374151)' }" />
      }
    </p-avatargroup>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { surplus: [{ type: i0.Input, args: [{ isSignal: true, alias: "surplus", required: false }] }], avatars: [{ type: i0.Input, args: [{ isSignal: true, alias: "avatars", required: false }] }] } });

class SkBlockUIComponent {
    blocked = input(true, { ...(ngDevMode ? { debugName: "blocked" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    baseZIndex = input(0, { ...(ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    message = input('', ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    label = input('Contenido de la sección bloqueada durante la carga', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkBlockUIComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkBlockUIComponent, isStandalone: true, selector: "sk-blockui", inputs: { blocked: { classPropertyName: "blocked", publicName: "blocked", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div #wrapper class="sk-blockui__wrap">
      <!-- gradient para el color del spinner -->
      <svg width="0" height="0" style="position:absolute;overflow:hidden;">
        <defs>
          <linearGradient id="sk-blockui-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%"   stop-color="var(--primary-00, #00c73d)" />
            <stop offset="100%" stop-color="var(--secondarygreencomplementary-00, #8fe000)" />
          </linearGradient>
        </defs>
      </svg>

      <p-blockui
        [target]="wrapper"
        [blocked]="blocked()"
        [baseZIndex]="baseZIndex()"
        [autoZIndex]="autoZIndex()"
      >
        <div class="sk-blockui__overlay">
          <p-progressspinner [style]="{ width: '40px', height: '40px' }" strokeWidth="4" animationDuration=".8s" />
          @if (message()) {
            <span class="sk-blockui__message">{{ message() }}</span>
          }
        </div>
      </p-blockui>

      @if (label()) {
        <div class="sk-blockui__demo-content">{{ label() }}</div>
      }
      <ng-content />
    </div>
  `, isInline: true, styles: [":host{display:block}.sk-blockui__wrap{position:relative;min-height:80px;border-radius:var(--radius-md, 8px);overflow:hidden}::ng-deep .sk-blockui__wrap .p-blockui-mask{display:flex!important;align-items:center!important;justify-content:center!important}::ng-deep .sk-blockui__wrap .p-blockui-mask .p-progressspinner-circle{stroke:url(#sk-blockui-gradient)!important}.sk-blockui__overlay{display:flex;flex-direction:column;align-items:center;gap:10px}.sk-blockui__message{font-size:13px;font-weight:500;color:#fff}.sk-blockui__demo-content{padding:24px;font-size:14px;color:var(--texts-medium, #666);text-align:center;border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--radius-md, 8px);background:var(--background-white, #fff)}\n"], dependencies: [{ kind: "component", type: BlockUI, selector: "p-blockUI, p-blockui, p-block-ui", inputs: ["target", "autoZIndex", "baseZIndex", "styleClass", "blocked"] }, { kind: "component", type: ProgressSpinner, selector: "p-progressSpinner, p-progress-spinner, p-progressspinner", inputs: ["styleClass", "strokeWidth", "fill", "animationDuration", "ariaLabel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkBlockUIComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-blockui', standalone: true, imports: [BlockUI, ProgressSpinner], template: `
    <div #wrapper class="sk-blockui__wrap">
      <!-- gradient para el color del spinner -->
      <svg width="0" height="0" style="position:absolute;overflow:hidden;">
        <defs>
          <linearGradient id="sk-blockui-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%"   stop-color="var(--primary-00, #00c73d)" />
            <stop offset="100%" stop-color="var(--secondarygreencomplementary-00, #8fe000)" />
          </linearGradient>
        </defs>
      </svg>

      <p-blockui
        [target]="wrapper"
        [blocked]="blocked()"
        [baseZIndex]="baseZIndex()"
        [autoZIndex]="autoZIndex()"
      >
        <div class="sk-blockui__overlay">
          <p-progressspinner [style]="{ width: '40px', height: '40px' }" strokeWidth="4" animationDuration=".8s" />
          @if (message()) {
            <span class="sk-blockui__message">{{ message() }}</span>
          }
        </div>
      </p-blockui>

      @if (label()) {
        <div class="sk-blockui__demo-content">{{ label() }}</div>
      }
      <ng-content />
    </div>
  `, styles: [":host{display:block}.sk-blockui__wrap{position:relative;min-height:80px;border-radius:var(--radius-md, 8px);overflow:hidden}::ng-deep .sk-blockui__wrap .p-blockui-mask{display:flex!important;align-items:center!important;justify-content:center!important}::ng-deep .sk-blockui__wrap .p-blockui-mask .p-progressspinner-circle{stroke:url(#sk-blockui-gradient)!important}.sk-blockui__overlay{display:flex;flex-direction:column;align-items:center;gap:10px}.sk-blockui__message{font-size:13px;font-weight:500;color:#fff}.sk-blockui__demo-content{padding:24px;font-size:14px;color:var(--texts-medium, #666);text-align:center;border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--radius-md, 8px);background:var(--background-white, #fff)}\n"] }]
        }], propDecorators: { blocked: [{ type: i0.Input, args: [{ isSignal: true, alias: "blocked", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

const HOME_ICON = `<svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M2 6.5 8 1.5 14 6.5V14a.5.5 0 0 1-.5.5H10V10H6v4.5H2.5A.5.5 0 0 1 2 14V6.5Z" stroke="currentColor" stroke-width="1.25" stroke-linejoin="round"/>
</svg>`;
class SkBreadcrumbComponent {
    items = input([], ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    separator = input('/', ...(ngDevMode ? [{ debugName: "separator" }] : /* istanbul ignore next */ []));
    /** Muestra el ícono de casa en el primer ítem si no tiene icon propio */
    showHomeIcon = input(false, { ...(ngDevMode ? { debugName: "showHomeIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    // compat aliases
    model = input([], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    home = input(undefined, ...(ngDevMode ? [{ debugName: "home" }] : /* istanbul ignore next */ []));
    styleClass = input(undefined, ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    resolvedItems = computed(() => {
        const rawItems = this.items();
        let parsed = [];
        if (typeof rawItems === 'string') {
            try {
                parsed = JSON.parse(rawItems);
            }
            catch {
                parsed = [];
            }
        }
        else {
            parsed = rawItems || [];
        }
        return parsed.map((item, i) => ({
            ...item,
            icon: item.icon !== undefined
                ? item.icon
                : (this.showHomeIcon() && i === 0 ? HOME_ICON : undefined),
        }));
    }, ...(ngDevMode ? [{ debugName: "resolvedItems" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkBreadcrumbComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkBreadcrumbComponent, isStandalone: true, selector: "sk-breadcrumb", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, separator: { classPropertyName: "separator", publicName: "separator", isSignal: true, isRequired: false, transformFunction: null }, showHomeIcon: { classPropertyName: "showHomeIcon", publicName: "showHomeIcon", isSignal: true, isRequired: false, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, home: { classPropertyName: "home", publicName: "home", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<nav aria-label=\"Ruta de navegaci\u00F3n\">\r\n      <ol class=\"sk-bc\">\r\n        @for (item of resolvedItems(); track item.label; let last = $last) {\r\n          <li class=\"sk-bc__item\">\r\n            @if (!last) {\r\n              <a\r\n                class=\"sk-bc__link\"\r\n                [href]=\"item.href || '#'\"\r\n                [attr.aria-label]=\"item.label\"\r\n              >\r\n                @if (item.icon !== undefined) {\r\n                  <span class=\"sk-bc__icon\" aria-hidden=\"true\" [innerHTML]=\"item.icon\"></span>\r\n                }\r\n                <span class=\"sk-bc__text\">{{ item.label }}</span>\r\n              </a>\r\n              <span class=\"sk-bc__sep\" aria-hidden=\"true\">{{ separator() }}</span>\r\n            } @else {\r\n              <span class=\"sk-bc__active\" aria-current=\"page\">\r\n                @if (item.icon !== undefined) {\r\n                  <span class=\"sk-bc__icon\" aria-hidden=\"true\" [innerHTML]=\"item.icon\"></span>\r\n                }\r\n                <span class=\"sk-bc__text\">{{ item.label }}</span>\r\n              </span>\r\n            }\r\n          </li>\r\n        }\r\n      </ol>\r\n    </nav>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-bc{display:flex;flex-wrap:wrap;align-items:center;gap:0;list-style:none;margin:0;padding:0;font-family:Open Sans,sans-serif;font-size:14px;line-height:22px}.sk-bc__item{display:inline-flex;align-items:center}.sk-bc__link{display:inline-flex;align-items:center;gap:4px;font-weight:400;color:var(--texts-dark, #404040);text-decoration:none;border-radius:4px;padding:1px 4px;outline:none;transition:color .15s ease}.sk-bc__link:hover{color:var(--texts-brand, #00c73d);text-decoration:underline}.sk-bc__link:focus-visible{outline:2px solid var(--stroke-brand, #00c73d);outline-offset:1px}.sk-bc__active{display:inline-flex;align-items:center;gap:4px;font-weight:700;color:var(--texts-brand, #00c73d);padding:1px 4px}.sk-bc__sep{margin:0 4px;color:var(--texts-dark, #404040);font-weight:400;-webkit-user-select:none;user-select:none}.sk-bc__icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:14px;height:14px}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkBreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-breadcrumb', standalone: true, imports: [], template: "<nav aria-label=\"Ruta de navegaci\u00F3n\">\r\n      <ol class=\"sk-bc\">\r\n        @for (item of resolvedItems(); track item.label; let last = $last) {\r\n          <li class=\"sk-bc__item\">\r\n            @if (!last) {\r\n              <a\r\n                class=\"sk-bc__link\"\r\n                [href]=\"item.href || '#'\"\r\n                [attr.aria-label]=\"item.label\"\r\n              >\r\n                @if (item.icon !== undefined) {\r\n                  <span class=\"sk-bc__icon\" aria-hidden=\"true\" [innerHTML]=\"item.icon\"></span>\r\n                }\r\n                <span class=\"sk-bc__text\">{{ item.label }}</span>\r\n              </a>\r\n              <span class=\"sk-bc__sep\" aria-hidden=\"true\">{{ separator() }}</span>\r\n            } @else {\r\n              <span class=\"sk-bc__active\" aria-current=\"page\">\r\n                @if (item.icon !== undefined) {\r\n                  <span class=\"sk-bc__icon\" aria-hidden=\"true\" [innerHTML]=\"item.icon\"></span>\r\n                }\r\n                <span class=\"sk-bc__text\">{{ item.label }}</span>\r\n              </span>\r\n            }\r\n          </li>\r\n        }\r\n      </ol>\r\n    </nav>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-bc{display:flex;flex-wrap:wrap;align-items:center;gap:0;list-style:none;margin:0;padding:0;font-family:Open Sans,sans-serif;font-size:14px;line-height:22px}.sk-bc__item{display:inline-flex;align-items:center}.sk-bc__link{display:inline-flex;align-items:center;gap:4px;font-weight:400;color:var(--texts-dark, #404040);text-decoration:none;border-radius:4px;padding:1px 4px;outline:none;transition:color .15s ease}.sk-bc__link:hover{color:var(--texts-brand, #00c73d);text-decoration:underline}.sk-bc__link:focus-visible{outline:2px solid var(--stroke-brand, #00c73d);outline-offset:1px}.sk-bc__active{display:inline-flex;align-items:center;gap:4px;font-weight:700;color:var(--texts-brand, #00c73d);padding:1px 4px}.sk-bc__sep{margin:0 4px;color:var(--texts-dark, #404040);font-weight:400;-webkit-user-select:none;user-select:none}.sk-bc__icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:14px;height:14px}\n"] }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], separator: [{ type: i0.Input, args: [{ isSignal: true, alias: "separator", required: false }] }], showHomeIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showHomeIcon", required: false }] }], model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], home: [{ type: i0.Input, args: [{ isSignal: true, alias: "home", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }] } });

const VARIANT_ALIASES = {
    primary: 'fill',
    secondary: 'outline',
    tertiary: 'ghost',
    fill: 'fill',
    outline: 'outline',
    ghost: 'ghost',
};
class SkButtonComponent {
    variant = input('primary', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    product = input('skandia', ...(ngDevMode ? [{ debugName: "product" }] : /* istanbul ignore next */ []));
    size = input('large', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    icon = input(...(ngDevMode ? [undefined, { debugName: "icon" }] : /* istanbul ignore next */ []));
    iconLeft = input('', ...(ngDevMode ? [{ debugName: "iconLeft" }] : /* istanbul ignore next */ []));
    iconRight = input('', ...(ngDevMode ? [{ debugName: "iconRight" }] : /* istanbul ignore next */ []));
    type = input('button', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    iconOnly = input(false, { ...(ngDevMode ? { debugName: "iconOnly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaLabel = input(...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    raised = input(false, { ...(ngDevMode ? { debugName: "raised" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    rounded = input(false, { ...(ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    text = input(false, { ...(ngDevMode ? { debugName: "text" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    plain = input(false, { ...(ngDevMode ? { debugName: "plain" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    outlined = input(false, { ...(ngDevMode ? { debugName: "outlined" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    link = input(false, { ...(ngDevMode ? { debugName: "link" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    severity = input(...(ngDevMode ? [undefined, { debugName: "severity" }] : /* istanbul ignore next */ []));
    loadingIcon = input(...(ngDevMode ? [undefined, { debugName: "loadingIcon" }] : /* istanbul ignore next */ []));
    badge = input(...(ngDevMode ? [undefined, { debugName: "badge" }] : /* istanbul ignore next */ []));
    badgeClass = input(...(ngDevMode ? [undefined, { debugName: "badgeClass" }] : /* istanbul ignore next */ []));
    styleClass = input(...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    clicked = output();
    focused = output();
    blurred = output();
    resolvedVariant = computed(() => {
        if (this.outlined())
            return 'outline';
        if (this.text() || this.plain())
            return 'ghost';
        return VARIANT_ALIASES[this.variant()] ?? 'fill';
    }, ...(ngDevMode ? [{ debugName: "resolvedVariant" }] : /* istanbul ignore next */ []));
    resolvedLabel = computed(() => this.label() || '', ...(ngDevMode ? [{ debugName: "resolvedLabel" }] : /* istanbul ignore next */ []));
    resolvedIcon = computed(() => this.normalizeIconName(this.iconLeft() || this.iconRight() || this.icon()) || '', ...(ngDevMode ? [{ debugName: "resolvedIcon" }] : /* istanbul ignore next */ []));
    resolvedIconPos = computed(() => this.iconRight() ? 'right' : 'left', ...(ngDevMode ? [{ debugName: "resolvedIconPos" }] : /* istanbul ignore next */ []));
    resolvedSeverity = computed(() => this.severity(), ...(ngDevMode ? [{ debugName: "resolvedSeverity" }] : /* istanbul ignore next */ []));
    resolvedLoadingIcon = computed(() => this.normalizeIconName(this.loadingIcon()), ...(ngDevMode ? [{ debugName: "resolvedLoadingIcon" }] : /* istanbul ignore next */ []));
    resolvedOutlined = computed(() => this.outlined() || this.resolvedVariant() === 'outline', ...(ngDevMode ? [{ debugName: "resolvedOutlined" }] : /* istanbul ignore next */ []));
    resolvedText = computed(() => this.text() || this.plain() || this.resolvedVariant() === 'ghost', ...(ngDevMode ? [{ debugName: "resolvedText" }] : /* istanbul ignore next */ []));
    resolvedLink = computed(() => this.link(), ...(ngDevMode ? [{ debugName: "resolvedLink" }] : /* istanbul ignore next */ []));
    resolvedStyleClass = computed(() => [
        `sk-btn--${this.resolvedVariant()}`,
        this.link() ? 'sk-btn--link' : '',
        this.product() === 'fiduciaria' ? 'sk-btn--fiduciaria' : '',
        this.iconOnly() ? 'sk-btn--icon-only' : '',
        this.styleClass(),
    ].filter(Boolean).join(' '), ...(ngDevMode ? [{ debugName: "resolvedStyleClass" }] : /* istanbul ignore next */ []));
    handleClick(event) {
        if (!this.disabled() && !this.loading()) {
            this.clicked.emit(event);
        }
    }
    normalizeIconName(value) {
        if (!value?.trim())
            return undefined;
        const normalized = value.trim();
        if (normalized.startsWith('pi '))
            return normalized;
        if (normalized.startsWith('pi-'))
            return `pi ${normalized}`;
        return `pi pi-${normalized}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkButtonComponent, isStandalone: true, selector: "sk-button", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, product: { classPropertyName: "product", publicName: "product", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, iconLeft: { classPropertyName: "iconLeft", publicName: "iconLeft", isSignal: true, isRequired: false, transformFunction: null }, iconRight: { classPropertyName: "iconRight", publicName: "iconRight", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, iconOnly: { classPropertyName: "iconOnly", publicName: "iconOnly", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, raised: { classPropertyName: "raised", publicName: "raised", isSignal: true, isRequired: false, transformFunction: null }, rounded: { classPropertyName: "rounded", publicName: "rounded", isSignal: true, isRequired: false, transformFunction: null }, text: { classPropertyName: "text", publicName: "text", isSignal: true, isRequired: false, transformFunction: null }, plain: { classPropertyName: "plain", publicName: "plain", isSignal: true, isRequired: false, transformFunction: null }, outlined: { classPropertyName: "outlined", publicName: "outlined", isSignal: true, isRequired: false, transformFunction: null }, link: { classPropertyName: "link", publicName: "link", isSignal: true, isRequired: false, transformFunction: null }, severity: { classPropertyName: "severity", publicName: "severity", isSignal: true, isRequired: false, transformFunction: null }, loadingIcon: { classPropertyName: "loadingIcon", publicName: "loadingIcon", isSignal: true, isRequired: false, transformFunction: null }, badge: { classPropertyName: "badge", publicName: "badge", isSignal: true, isRequired: false, transformFunction: null }, badgeClass: { classPropertyName: "badgeClass", publicName: "badgeClass", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { clicked: "clicked", focused: "focused", blurred: "blurred" }, ngImport: i0, template: `
    <p-button
      [label]="resolvedLabel()"
      [icon]="resolvedIcon()"
      [iconPos]="resolvedIconPos()"
      [type]="type()"
      [disabled]="disabled() || loading()"
      [raised]="raised()"
      [rounded]="rounded() || iconOnly()"
      [outlined]="resolvedOutlined()"
      [text]="resolvedText()"
      [plain]="plain()"
      [link]="resolvedLink()"
      [severity]="resolvedSeverity()"
      [size]="size()"
      [loading]="loading()"
      [loadingIcon]="resolvedLoadingIcon()"
      [badge]="badge()"
      [badgeClass]="badgeClass()"
      [ariaLabel]="ariaLabel() || resolvedLabel()"
      [styleClass]="resolvedStyleClass()"
      (onClick)="handleClick($event)"
      (onFocus)="focused.emit($event)"
      (onBlur)="blurred.emit($event)"
    ></p-button>
  `, isInline: true, styles: [":host{display:inline-flex}\n"], dependencies: [{ kind: "component", type: Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-button', standalone: true, imports: [Button], template: `
    <p-button
      [label]="resolvedLabel()"
      [icon]="resolvedIcon()"
      [iconPos]="resolvedIconPos()"
      [type]="type()"
      [disabled]="disabled() || loading()"
      [raised]="raised()"
      [rounded]="rounded() || iconOnly()"
      [outlined]="resolvedOutlined()"
      [text]="resolvedText()"
      [plain]="plain()"
      [link]="resolvedLink()"
      [severity]="resolvedSeverity()"
      [size]="size()"
      [loading]="loading()"
      [loadingIcon]="resolvedLoadingIcon()"
      [badge]="badge()"
      [badgeClass]="badgeClass()"
      [ariaLabel]="ariaLabel() || resolvedLabel()"
      [styleClass]="resolvedStyleClass()"
      (onClick)="handleClick($event)"
      (onFocus)="focused.emit($event)"
      (onBlur)="blurred.emit($event)"
    ></p-button>
  `, styles: [":host{display:inline-flex}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], product: [{ type: i0.Input, args: [{ isSignal: true, alias: "product", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], iconLeft: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconLeft", required: false }] }], iconRight: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconRight", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], iconOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOnly", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], raised: [{ type: i0.Input, args: [{ isSignal: true, alias: "raised", required: false }] }], rounded: [{ type: i0.Input, args: [{ isSignal: true, alias: "rounded", required: false }] }], text: [{ type: i0.Input, args: [{ isSignal: true, alias: "text", required: false }] }], plain: [{ type: i0.Input, args: [{ isSignal: true, alias: "plain", required: false }] }], outlined: [{ type: i0.Input, args: [{ isSignal: true, alias: "outlined", required: false }] }], link: [{ type: i0.Input, args: [{ isSignal: true, alias: "link", required: false }] }], severity: [{ type: i0.Input, args: [{ isSignal: true, alias: "severity", required: false }] }], loadingIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingIcon", required: false }] }], badge: [{ type: i0.Input, args: [{ isSignal: true, alias: "badge", required: false }] }], badgeClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "badgeClass", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], clicked: [{ type: i0.Output, args: ["clicked"] }], focused: [{ type: i0.Output, args: ["focused"] }], blurred: [{ type: i0.Output, args: ["blurred"] }] } });

class SkButtonGroupComponent {
    buttons = input([
        { label: 'Año', icon: 'pi pi-calendar' },
        { label: 'Mes', icon: 'pi pi-clock' },
        { label: 'Día', icon: 'pi pi-sun' },
    ], ...(ngDevMode ? [{ debugName: "buttons" }] : /* istanbul ignore next */ []));
    outlined = input(false, ...(ngDevMode ? [{ debugName: "outlined" }] : /* istanbul ignore next */ []));
    severity = input(undefined, ...(ngDevMode ? [{ debugName: "severity" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkButtonGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkButtonGroupComponent, isStandalone: true, selector: "sk-buttongroup", inputs: { buttons: { classPropertyName: "buttons", publicName: "buttons", isSignal: true, isRequired: false, transformFunction: null }, outlined: { classPropertyName: "outlined", publicName: "outlined", isSignal: true, isRequired: false, transformFunction: null }, severity: { classPropertyName: "severity", publicName: "severity", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-buttongroup>
      @for (btn of buttons(); track btn.label) {
        <p-button [label]="btn.label" [icon]="btn.icon" [outlined]="outlined()" [severity]="severity()" />
      }
    </p-buttongroup>
  `, isInline: true, styles: [":host{display:inline-flex}\n"], dependencies: [{ kind: "component", type: ButtonGroup, selector: "p-buttonGroup, p-buttongroup, p-button-group" }, { kind: "component", type: Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkButtonGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-buttongroup', standalone: true, imports: [ButtonGroup, Button], template: `
    <p-buttongroup>
      @for (btn of buttons(); track btn.label) {
        <p-button [label]="btn.label" [icon]="btn.icon" [outlined]="outlined()" [severity]="severity()" />
      }
    </p-buttongroup>
  `, styles: [":host{display:inline-flex}\n"] }]
        }], propDecorators: { buttons: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttons", required: false }] }], outlined: [{ type: i0.Input, args: [{ isSignal: true, alias: "outlined", required: false }] }], severity: [{ type: i0.Input, args: [{ isSignal: true, alias: "severity", required: false }] }] } });

class SkCardComponent {
    header = input('', ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    subheader = input('', ...(ngDevMode ? [{ debugName: "subheader" }] : /* istanbul ignore next */ []));
    content = input('', ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    footer = input('', ...(ngDevMode ? [{ debugName: "footer" }] : /* istanbul ignore next */ []));
    elevated = input(false, { ...(ngDevMode ? { debugName: "elevated" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkCardComponent, isStandalone: true, selector: "sk-card", inputs: { header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, subheader: { classPropertyName: "subheader", publicName: "subheader", isSignal: true, isRequired: false, transformFunction: null }, content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: false, transformFunction: null }, footer: { classPropertyName: "footer", publicName: "footer", isSignal: true, isRequired: false, transformFunction: null }, elevated: { classPropertyName: "elevated", publicName: "elevated", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="sk-card" [class.sk-card--elevated]="elevated()">
      @if (header() || subheader()) {
        <header class="sk-card__header">
          @if (header())    { <h3 class="sk-card__title">{{ header() }}</h3> }
          @if (subheader()) { <p  class="sk-card__subtitle">{{ subheader() }}</p> }
        </header>
      }
      <div class="sk-card__body">
        @if (content()) { <p class="sk-card__text">{{ content() }}</p> }
        <ng-content />
      </div>
      @if (footer()) {
        <footer class="sk-card__footer">{{ footer() }}</footer>
      }
    </div>
  `, isInline: true, styles: [":host{display:block}.sk-card{background:var(--background-white, #fff);border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-m, 16px);overflow:hidden;transition:box-shadow .2s}.sk-card--elevated{border-color:transparent;box-shadow:0 2px 12px #00000017}.sk-card--elevated:hover{box-shadow:0 4px 20px #0000001f}.sk-card__header{padding:16px 20px 12px;border-bottom:1px solid var(--stroke-grey-light, #e5e7eb)}.sk-card__title{margin:0 0 4px;font-size:16px;font-weight:600;color:var(--texts-dark, #404040);line-height:1.3}.sk-card__subtitle{margin:0;font-size:13px;color:var(--texts-medium, #666);line-height:1.4}.sk-card__body{padding:16px 20px}.sk-card__text{margin:0;font-size:14px;color:var(--texts-medium, #666);line-height:1.6}.sk-card__footer{padding:12px 20px;border-top:1px solid var(--stroke-grey-light, #e5e7eb);background:var(--background-grey-light, #f7f7f7);font-size:12px;color:var(--texts-medium, #888)}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-card', standalone: true, template: `
    <div class="sk-card" [class.sk-card--elevated]="elevated()">
      @if (header() || subheader()) {
        <header class="sk-card__header">
          @if (header())    { <h3 class="sk-card__title">{{ header() }}</h3> }
          @if (subheader()) { <p  class="sk-card__subtitle">{{ subheader() }}</p> }
        </header>
      }
      <div class="sk-card__body">
        @if (content()) { <p class="sk-card__text">{{ content() }}</p> }
        <ng-content />
      </div>
      @if (footer()) {
        <footer class="sk-card__footer">{{ footer() }}</footer>
      }
    </div>
  `, styles: [":host{display:block}.sk-card{background:var(--background-white, #fff);border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-m, 16px);overflow:hidden;transition:box-shadow .2s}.sk-card--elevated{border-color:transparent;box-shadow:0 2px 12px #00000017}.sk-card--elevated:hover{box-shadow:0 4px 20px #0000001f}.sk-card__header{padding:16px 20px 12px;border-bottom:1px solid var(--stroke-grey-light, #e5e7eb)}.sk-card__title{margin:0 0 4px;font-size:16px;font-weight:600;color:var(--texts-dark, #404040);line-height:1.3}.sk-card__subtitle{margin:0;font-size:13px;color:var(--texts-medium, #666);line-height:1.4}.sk-card__body{padding:16px 20px}.sk-card__text{margin:0;font-size:14px;color:var(--texts-medium, #666);line-height:1.6}.sk-card__footer{padding:12px 20px;border-top:1px solid var(--stroke-grey-light, #e5e7eb);background:var(--background-grey-light, #f7f7f7);font-size:12px;color:var(--texts-medium, #888)}\n"] }]
        }], propDecorators: { header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], subheader: [{ type: i0.Input, args: [{ isSignal: true, alias: "subheader", required: false }] }], content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: false }] }], footer: [{ type: i0.Input, args: [{ isSignal: true, alias: "footer", required: false }] }], elevated: [{ type: i0.Input, args: [{ isSignal: true, alias: "elevated", required: false }] }] } });

class SkCarouselComponent {
    value = input([
        { title: 'Portafolio conservador', subtitle: 'Bajo riesgo', icon: 'shield', color: 'var(--extras-c03)' },
        { title: 'Portafolio moderado', subtitle: 'Riesgo medio', icon: 'chart-line', color: 'var(--extras-c01)' },
        { title: 'Portafolio dinámico', subtitle: 'Alto potencial', icon: 'bolt', color: 'var(--extras-c04)' },
        { title: 'Renta fija', subtitle: 'Estabilidad', icon: 'lock', color: 'var(--extras-c02)' },
    ], ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    numVisible = input(2, { ...(ngDevMode ? { debugName: "numVisible" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    numScroll = input(1, { ...(ngDevMode ? { debugName: "numScroll" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    circular = input(false, { ...(ngDevMode ? { debugName: "circular" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoplayInterval = input(0, { ...(ngDevMode ? { debugName: "autoplayInterval" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    showIndicators = input(true, { ...(ngDevMode ? { debugName: "showIndicators" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showNavigators = input(true, { ...(ngDevMode ? { debugName: "showNavigators" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkCarouselComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkCarouselComponent, isStandalone: true, selector: "sk-carousel", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, numVisible: { classPropertyName: "numVisible", publicName: "numVisible", isSignal: true, isRequired: false, transformFunction: null }, numScroll: { classPropertyName: "numScroll", publicName: "numScroll", isSignal: true, isRequired: false, transformFunction: null }, circular: { classPropertyName: "circular", publicName: "circular", isSignal: true, isRequired: false, transformFunction: null }, autoplayInterval: { classPropertyName: "autoplayInterval", publicName: "autoplayInterval", isSignal: true, isRequired: false, transformFunction: null }, showIndicators: { classPropertyName: "showIndicators", publicName: "showIndicators", isSignal: true, isRequired: false, transformFunction: null }, showNavigators: { classPropertyName: "showNavigators", publicName: "showNavigators", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-carousel
      [value]="value()"
      [numVisible]="numVisible()"
      [numScroll]="numScroll()"
      [circular]="circular()"
      [autoplayInterval]="autoplayInterval()"
      [showIndicators]="showIndicators()"
      [showNavigators]="showNavigators()"
    >
      <ng-template #item let-item>
        <div class="sk-carousel__card">
          @if (item.image) {
            <img [src]="item.image" [alt]="item.title" class="sk-carousel__img" />
          } @else if (item.icon) {
            <div class="sk-carousel__icon-wrap" [style.background]="item.color || 'var(--color-primary, #00c73d)'">
              <i [class]="'pi pi-' + item.icon"></i>
            </div>
          }
          <p class="sk-carousel__title">{{ item.title }}</p>
          @if (item.subtitle) {
            <p class="sk-carousel__subtitle">{{ item.subtitle }}</p>
          }
        </div>
      </ng-template>
    </p-carousel>
  `, isInline: true, styles: [":host{display:block}.sk-carousel__card{display:flex;flex-direction:column;align-items:center;gap:10px;padding:20px 16px;margin:4px;border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--radius-md, 8px);background:var(--background-white, #fff);text-align:center;min-height:140px}.sk-carousel__img{width:100%;height:120px;object-fit:cover;border-radius:var(--radius-sm, 4px)}.sk-carousel__icon-wrap{width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center}.sk-carousel__icon-wrap i{font-size:24px;color:#fff}.sk-carousel__title{margin:0;font-weight:600;font-size:14px;color:var(--texts-dark, #404040)}.sk-carousel__subtitle{margin:0;font-size:12px;color:var(--texts-medium, #666);line-height:1.4}\n"], dependencies: [{ kind: "component", type: Carousel, selector: "p-carousel", inputs: ["page", "numVisible", "numScroll", "responsiveOptions", "orientation", "verticalViewPortHeight", "contentClass", "indicatorsContentClass", "indicatorsContentStyle", "indicatorStyleClass", "indicatorStyle", "value", "circular", "showIndicators", "showNavigators", "autoplayInterval", "styleClass", "prevButtonProps", "nextButtonProps"], outputs: ["onPage"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkCarouselComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-carousel', standalone: true, imports: [Carousel], template: `
    <p-carousel
      [value]="value()"
      [numVisible]="numVisible()"
      [numScroll]="numScroll()"
      [circular]="circular()"
      [autoplayInterval]="autoplayInterval()"
      [showIndicators]="showIndicators()"
      [showNavigators]="showNavigators()"
    >
      <ng-template #item let-item>
        <div class="sk-carousel__card">
          @if (item.image) {
            <img [src]="item.image" [alt]="item.title" class="sk-carousel__img" />
          } @else if (item.icon) {
            <div class="sk-carousel__icon-wrap" [style.background]="item.color || 'var(--color-primary, #00c73d)'">
              <i [class]="'pi pi-' + item.icon"></i>
            </div>
          }
          <p class="sk-carousel__title">{{ item.title }}</p>
          @if (item.subtitle) {
            <p class="sk-carousel__subtitle">{{ item.subtitle }}</p>
          }
        </div>
      </ng-template>
    </p-carousel>
  `, styles: [":host{display:block}.sk-carousel__card{display:flex;flex-direction:column;align-items:center;gap:10px;padding:20px 16px;margin:4px;border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--radius-md, 8px);background:var(--background-white, #fff);text-align:center;min-height:140px}.sk-carousel__img{width:100%;height:120px;object-fit:cover;border-radius:var(--radius-sm, 4px)}.sk-carousel__icon-wrap{width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center}.sk-carousel__icon-wrap i{font-size:24px;color:#fff}.sk-carousel__title{margin:0;font-weight:600;font-size:14px;color:var(--texts-dark, #404040)}.sk-carousel__subtitle{margin:0;font-size:12px;color:var(--texts-medium, #666);line-height:1.4}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], numVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "numVisible", required: false }] }], numScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "numScroll", required: false }] }], circular: [{ type: i0.Input, args: [{ isSignal: true, alias: "circular", required: false }] }], autoplayInterval: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoplayInterval", required: false }] }], showIndicators: [{ type: i0.Input, args: [{ isSignal: true, alias: "showIndicators", required: false }] }], showNavigators: [{ type: i0.Input, args: [{ isSignal: true, alias: "showNavigators", required: false }] }] } });

let _cascadeSelectUid = 0;
class SkCascadeSelectComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    options = input([
        { label: 'Colombia', code: 'CO', cities: [{ label: 'Bogotá', code: 'BOG' }, { label: 'Medellín', code: 'MDE' }] },
        { label: 'México', code: 'MX', cities: [{ label: 'Ciudad de México', code: 'CDMX' }, { label: 'Guadalajara', code: 'GDL' }] },
        { label: 'Argentina', code: 'AR', cities: [{ label: 'Buenos Aires', code: 'BA' }, { label: 'Córdoba', code: 'CBA' }] },
    ], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    optionLabel = input('label', ...(ngDevMode ? [{ debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    optionGroupLabel = input('label', ...(ngDevMode ? [{ debugName: "optionGroupLabel" }] : /* istanbul ignore next */ []));
    optionGroupChildren = input(['cities'], ...(ngDevMode ? [{ debugName: "optionGroupChildren" }] : /* istanbul ignore next */ []));
    placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    inputId = `sk-cascadeselect-${_cascadeSelectUid++}`;
    innerControl = new FormControl(null);
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isOpen = signal(false, ...(ngDevMode ? [{ debugName: "_isOpen" }] : /* istanbul ignore next */ []));
    _value = signal(null, ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _isFloatActive = computed(() => this._value() != null || this._isOpen(), ...(ngDevMode ? [{ debugName: "_isFloatActive" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    onTouched = () => { };
    sub;
    constructor() {
        this.sub = this.innerControl.valueChanges.subscribe(val => {
            this._value.set(val);
            this._onChange(val);
            this.valueChange.emit(val);
        });
        effect(() => {
            this._isDisabled()
                ? this.innerControl.disable({ emitEvent: false })
                : this.innerControl.enable({ emitEvent: false });
        });
    }
    onPanelShow() { this._isOpen.set(true); }
    onPanelHide() { this._isOpen.set(false); this.onTouched(); }
    writeValue(val) { const v = val ?? null; this.innerControl.setValue(v, { emitEvent: false }); this._value.set(v); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    ngOnDestroy() { this.sub.unsubscribe(); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkCascadeSelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkCascadeSelectComponent, isStandalone: true, selector: "sk-cascadeselect", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionGroupLabel: { classPropertyName: "optionGroupLabel", publicName: "optionGroupLabel", isSignal: true, isRequired: false, transformFunction: null }, optionGroupChildren: { classPropertyName: "optionGroupChildren", publicName: "optionGroupChildren", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkCascadeSelectComponent), multi: true }], ngImport: i0, template: "<div\r\n  class=\"sk-cascadeselect\"\r\n  [class.sk-cascadeselect--fluid]=\"fluid()\"\r\n  [class.sk-cascadeselect--invalid]=\"invalid()\"\r\n  [class.sk-cascadeselect--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel\r\n    variant=\"in\"\r\n    class=\"sk-cascadeselect__floatlabel\"\r\n    [class.p-floatlabel-active]=\"_isFloatActive()\"\r\n  >\r\n    <p-cascadeselect\r\n      [inputId]=\"inputId\"\r\n      [formControl]=\"innerControl\"\r\n      [options]=\"options()\"\r\n      [optionLabel]=\"optionLabel()\"\r\n      [optionGroupLabel]=\"optionGroupLabel()\"\r\n      [optionGroupChildren]=\"optionGroupChildren()\"\r\n      [placeholder]=\"placeholder()\"\r\n      class=\"sk-cascadeselect__field\"\r\n      (onBeforeShow)=\"onPanelShow()\"\r\n      (onHide)=\"onPanelHide()\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-cascadeselect__error\">{{ errorMessage() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-cascadeselect{display:flex;flex-direction:column;gap:4px}.sk-cascadeselect__floatlabel,.sk-cascadeselect--fluid,.sk-cascadeselect--fluid .sk-cascadeselect__floatlabel,.sk-cascadeselect--fluid .sk-cascadeselect__field{width:100%}::ng-deep .sk-cascadeselect__field.p-cascadeselect{width:100%;height:var(--size-048, 48px);padding-inline:12px;border-radius:4px}::ng-deep .sk-cascadeselect__field.p-cascadeselect .p-cascadeselect-dropdown{padding:0!important;width:auto!important}::ng-deep .sk-cascadeselect__field.p-cascadeselect .p-cascadeselect-label{padding-block-start:20px;padding-block-end:6px;padding-inline:0!important;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);color:var(--texts-dark, #404040)}::ng-deep .sk-cascadeselect__floatlabel label{font-size:14px!important;top:50%!important;transform:translateY(-50%)!important}::ng-deep .sk-cascadeselect__floatlabel.p-floatlabel-active label{font-size:11px!important;top:8px!important;transform:translateY(0)!important}::ng-deep .sk-cascadeselect--invalid .sk-cascadeselect__field.p-cascadeselect{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-cascadeselect--disabled .sk-cascadeselect__field.p-cascadeselect{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;cursor:not-allowed}.sk-cascadeselect__error{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--color-error, #e03430);padding:0 4px}\n"], dependencies: [{ kind: "component", type: CascadeSelect, selector: "p-cascadeSelect, p-cascadeselect, p-cascade-select", inputs: ["id", "searchMessage", "emptyMessage", "selectionMessage", "emptySearchMessage", "emptySelectionMessage", "searchLocale", "optionDisabled", "focusOnHover", "selectOnFocus", "autoOptionFocus", "styleClass", "options", "optionLabel", "optionValue", "optionGroupLabel", "optionGroupChildren", "placeholder", "value", "dataKey", "inputId", "tabindex", "ariaLabelledBy", "inputLabel", "ariaLabel", "showClear", "panelStyleClass", "panelStyle", "overlayOptions", "autofocus", "loading", "loadingIcon", "breakpoint", "size", "variant", "fluid", "appendTo", "motionOptions"], outputs: ["onChange", "onGroupChange", "onShow", "onHide", "onClear", "onBeforeShow", "onBeforeHide", "onFocus", "onBlur"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkCascadeSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-cascadeselect', standalone: true, imports: [CascadeSelect, FloatLabel, ReactiveFormsModule], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkCascadeSelectComponent), multi: true }], template: "<div\r\n  class=\"sk-cascadeselect\"\r\n  [class.sk-cascadeselect--fluid]=\"fluid()\"\r\n  [class.sk-cascadeselect--invalid]=\"invalid()\"\r\n  [class.sk-cascadeselect--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel\r\n    variant=\"in\"\r\n    class=\"sk-cascadeselect__floatlabel\"\r\n    [class.p-floatlabel-active]=\"_isFloatActive()\"\r\n  >\r\n    <p-cascadeselect\r\n      [inputId]=\"inputId\"\r\n      [formControl]=\"innerControl\"\r\n      [options]=\"options()\"\r\n      [optionLabel]=\"optionLabel()\"\r\n      [optionGroupLabel]=\"optionGroupLabel()\"\r\n      [optionGroupChildren]=\"optionGroupChildren()\"\r\n      [placeholder]=\"placeholder()\"\r\n      class=\"sk-cascadeselect__field\"\r\n      (onBeforeShow)=\"onPanelShow()\"\r\n      (onHide)=\"onPanelHide()\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-cascadeselect__error\">{{ errorMessage() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-cascadeselect{display:flex;flex-direction:column;gap:4px}.sk-cascadeselect__floatlabel,.sk-cascadeselect--fluid,.sk-cascadeselect--fluid .sk-cascadeselect__floatlabel,.sk-cascadeselect--fluid .sk-cascadeselect__field{width:100%}::ng-deep .sk-cascadeselect__field.p-cascadeselect{width:100%;height:var(--size-048, 48px);padding-inline:12px;border-radius:4px}::ng-deep .sk-cascadeselect__field.p-cascadeselect .p-cascadeselect-dropdown{padding:0!important;width:auto!important}::ng-deep .sk-cascadeselect__field.p-cascadeselect .p-cascadeselect-label{padding-block-start:20px;padding-block-end:6px;padding-inline:0!important;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);color:var(--texts-dark, #404040)}::ng-deep .sk-cascadeselect__floatlabel label{font-size:14px!important;top:50%!important;transform:translateY(-50%)!important}::ng-deep .sk-cascadeselect__floatlabel.p-floatlabel-active label{font-size:11px!important;top:8px!important;transform:translateY(0)!important}::ng-deep .sk-cascadeselect--invalid .sk-cascadeselect__field.p-cascadeselect{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-cascadeselect--disabled .sk-cascadeselect__field.p-cascadeselect{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;cursor:not-allowed}.sk-cascadeselect__error{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--color-error, #e03430);padding:0 4px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionGroupLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupLabel", required: false }] }], optionGroupChildren: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupChildren", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkCheckboxComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    showLabel = input(true, { ...(ngDevMode ? { debugName: "showLabel" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    error = input(false, { ...(ngDevMode ? { debugName: "error" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    checked = input(false, { ...(ngDevMode ? { debugName: "checked" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    checkedChange = output();
    focused = output();
    blurred = output();
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    indeterminate = input(false, { ...(ngDevMode ? { debugName: "indeterminate" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    inputId = input(undefined, ...(ngDevMode ? [{ debugName: "inputId" }] : /* istanbul ignore next */ []));
    ariaLabel = input(undefined, ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    styleClass = input(undefined, ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    uid = Math.random().toString(36).slice(2, 8);
    isChecked = false;
    cvaChange = () => { };
    cvaTouched = () => { };
    isShowLabel = computed(() => this.showLabel(), ...(ngDevMode ? [{ debugName: "isShowLabel" }] : /* istanbul ignore next */ []));
    isDisabled = computed(() => this.disabled(), ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    isIndeterminate = computed(() => this.indeterminate(), ...(ngDevMode ? [{ debugName: "isIndeterminate" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => ['sk-checkbox', this.disabled() ? 'sk-checkbox--disabled' : ''].filter(Boolean).join(' '), ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    pCheckboxClass = computed(() => [this.styleClass(), this.error() ? 'sk-cb-error' : ''].filter(Boolean).join(' '), ...(ngDevMode ? [{ debugName: "pCheckboxClass" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            this.isChecked = this.checked();
        });
    }
    handleChange(event) {
        this.isChecked = !!event.checked;
        this.cvaChange(this.isChecked);
        this.cvaTouched();
        this.checkedChange.emit(this.isChecked);
    }
    writeValue(value) {
        this.isChecked = !!value;
    }
    registerOnChange(fn) {
        this.cvaChange = fn;
    }
    registerOnTouched(fn) {
        this.cvaTouched = fn;
    }
    setDisabledState(_isDisabled) {
        // disabled state is managed via the disabled signal input
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkCheckboxComponent, isStandalone: true, selector: "sk-checkbox", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, showLabel: { classPropertyName: "showLabel", publicName: "showLabel", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, indeterminate: { classPropertyName: "indeterminate", publicName: "indeterminate", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checkedChange: "checkedChange", focused: "focused", blurred: "blurred" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SkCheckboxComponent),
                multi: true,
            },
        ], ngImport: i0, template: "<label [class]=\"hostClasses()\" [for]=\"inputId() || ('sk-cb-' + uid)\">\r\n\r\n      <p-checkbox\r\n        [binary]=\"true\"\r\n        [(ngModel)]=\"isChecked\"\r\n        [disabled]=\"isDisabled()\"\r\n        [indeterminate]=\"isIndeterminate()\"\r\n        [inputId]=\"inputId() || ('sk-cb-' + uid)\"\r\n        [ariaLabel]=\"ariaLabel() || (!isShowLabel() ? label() : undefined)\"\r\n        [styleClass]=\"pCheckboxClass()\"\r\n        (onChange)=\"handleChange($event)\"\r\n        (onFocus)=\"focused.emit($any($event))\"\r\n        (onBlur)=\"blurred.emit($any($event))\"\r\n      ></p-checkbox>\r\n\r\n      @if (isShowLabel() && label()) {\r\n        <span class=\"sk-checkbox__label\">{{ label() }}</span>\r\n      }\r\n\r\n    </label>\r\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}.sk-checkbox{display:inline-flex;align-items:center;gap:8px;cursor:pointer;-webkit-user-select:none;user-select:none}.sk-checkbox--disabled{cursor:not-allowed}:host ::ng-deep p-checkbox{display:inline-flex!important;position:relative;width:auto!important;height:auto!important;border:none!important;background:transparent!important;border-radius:0!important;box-shadow:none!important}:host ::ng-deep .p-checkbox-box{width:20px!important;height:20px!important;border-radius:4px!important;border:1.5px solid var(--stroke-default, #a5a5a5)!important;background:#fff!important;box-shadow:none!important;display:flex!important;align-items:center!important;justify-content:center!important;transition:background .15s ease,border-color .15s ease,box-shadow .15s ease!important;color:#fff!important;overflow:visible!important;position:relative!important}:host ::ng-deep .p-checkbox-box:before{content:\"\";position:absolute;width:36px;height:36px;border-radius:50%;background:color-mix(in srgb,var(--background-success-dark),transparent 78%);top:50%;left:50%;transform:translate(-50%,-50%) scale(.5);opacity:0;transition:opacity .15s ease,transform .18s ease;pointer-events:none;z-index:-1}:host ::ng-deep .p-checkbox-input:focus-visible~.p-checkbox-box:before{opacity:1;transform:translate(-50%,-50%) scale(1)}:host ::ng-deep .p-checkbox-icon{width:12px!important;height:12px!important;color:#fff!important}:host ::ng-deep .p-checkbox-checked .p-checkbox-box,:host ::ng-deep .p-highlight .p-checkbox-box{background:var(--background-brand, #00c73d)!important;border-color:var(--background-brand, #00c73d)!important}.sk-checkbox:not(.sk-checkbox--disabled):hover ::ng-deep .p-checkbox-box{box-shadow:0 0 8px color-mix(in srgb,var(--background-brand),transparent 70%)!important;border-color:var(--background-brand, #00c73d)!important}.sk-checkbox:not(.sk-checkbox--disabled):hover ::ng-deep .p-checkbox-checked .p-checkbox-box,.sk-checkbox:not(.sk-checkbox--disabled):hover ::ng-deep .p-highlight .p-checkbox-box{box-shadow:0 0 8px color-mix(in srgb,var(--background-brand),transparent 70%)!important;border-color:var(--background-brand, #00c73d)!important}:host ::ng-deep p-checkbox.sk-cb-error:not(.p-checkbox-checked):not(.p-highlight) .p-checkbox-box{border-color:var(--stroke-error-dark, #e03430)!important}:host ::ng-deep .p-disabled .p-checkbox-box,:host ::ng-deep p-checkbox.p-disabled .p-checkbox-box{border-color:var(--stroke-grey-light, #d4d4d4)!important;background:#f5f5f5!important;box-shadow:none!important}:host ::ng-deep .p-disabled.p-checkbox-checked .p-checkbox-box,:host ::ng-deep .p-disabled.p-highlight .p-checkbox-box{background:#b5b5b5!important;border-color:#b5b5b5!important}:host ::ng-deep .p-disabled .p-checkbox-icon{color:#fff!important}.sk-checkbox__label{font-family:Open Sans,system-ui,sans-serif;font-size:14px;font-weight:400;line-height:20px;color:var(--texts-dark, #404040);transition:color .15s ease}.sk-checkbox--disabled .sk-checkbox__label{color:var(--texts-light, #a5a5a5)}\n"], dependencies: [{ kind: "component", type: Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-checkbox', standalone: true, imports: [Checkbox, FormsModule], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SkCheckboxComponent),
                            multi: true,
                        },
                    ], template: "<label [class]=\"hostClasses()\" [for]=\"inputId() || ('sk-cb-' + uid)\">\r\n\r\n      <p-checkbox\r\n        [binary]=\"true\"\r\n        [(ngModel)]=\"isChecked\"\r\n        [disabled]=\"isDisabled()\"\r\n        [indeterminate]=\"isIndeterminate()\"\r\n        [inputId]=\"inputId() || ('sk-cb-' + uid)\"\r\n        [ariaLabel]=\"ariaLabel() || (!isShowLabel() ? label() : undefined)\"\r\n        [styleClass]=\"pCheckboxClass()\"\r\n        (onChange)=\"handleChange($event)\"\r\n        (onFocus)=\"focused.emit($any($event))\"\r\n        (onBlur)=\"blurred.emit($any($event))\"\r\n      ></p-checkbox>\r\n\r\n      @if (isShowLabel() && label()) {\r\n        <span class=\"sk-checkbox__label\">{{ label() }}</span>\r\n      }\r\n\r\n    </label>\r\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}.sk-checkbox{display:inline-flex;align-items:center;gap:8px;cursor:pointer;-webkit-user-select:none;user-select:none}.sk-checkbox--disabled{cursor:not-allowed}:host ::ng-deep p-checkbox{display:inline-flex!important;position:relative;width:auto!important;height:auto!important;border:none!important;background:transparent!important;border-radius:0!important;box-shadow:none!important}:host ::ng-deep .p-checkbox-box{width:20px!important;height:20px!important;border-radius:4px!important;border:1.5px solid var(--stroke-default, #a5a5a5)!important;background:#fff!important;box-shadow:none!important;display:flex!important;align-items:center!important;justify-content:center!important;transition:background .15s ease,border-color .15s ease,box-shadow .15s ease!important;color:#fff!important;overflow:visible!important;position:relative!important}:host ::ng-deep .p-checkbox-box:before{content:\"\";position:absolute;width:36px;height:36px;border-radius:50%;background:color-mix(in srgb,var(--background-success-dark),transparent 78%);top:50%;left:50%;transform:translate(-50%,-50%) scale(.5);opacity:0;transition:opacity .15s ease,transform .18s ease;pointer-events:none;z-index:-1}:host ::ng-deep .p-checkbox-input:focus-visible~.p-checkbox-box:before{opacity:1;transform:translate(-50%,-50%) scale(1)}:host ::ng-deep .p-checkbox-icon{width:12px!important;height:12px!important;color:#fff!important}:host ::ng-deep .p-checkbox-checked .p-checkbox-box,:host ::ng-deep .p-highlight .p-checkbox-box{background:var(--background-brand, #00c73d)!important;border-color:var(--background-brand, #00c73d)!important}.sk-checkbox:not(.sk-checkbox--disabled):hover ::ng-deep .p-checkbox-box{box-shadow:0 0 8px color-mix(in srgb,var(--background-brand),transparent 70%)!important;border-color:var(--background-brand, #00c73d)!important}.sk-checkbox:not(.sk-checkbox--disabled):hover ::ng-deep .p-checkbox-checked .p-checkbox-box,.sk-checkbox:not(.sk-checkbox--disabled):hover ::ng-deep .p-highlight .p-checkbox-box{box-shadow:0 0 8px color-mix(in srgb,var(--background-brand),transparent 70%)!important;border-color:var(--background-brand, #00c73d)!important}:host ::ng-deep p-checkbox.sk-cb-error:not(.p-checkbox-checked):not(.p-highlight) .p-checkbox-box{border-color:var(--stroke-error-dark, #e03430)!important}:host ::ng-deep .p-disabled .p-checkbox-box,:host ::ng-deep p-checkbox.p-disabled .p-checkbox-box{border-color:var(--stroke-grey-light, #d4d4d4)!important;background:#f5f5f5!important;box-shadow:none!important}:host ::ng-deep .p-disabled.p-checkbox-checked .p-checkbox-box,:host ::ng-deep .p-disabled.p-highlight .p-checkbox-box{background:#b5b5b5!important;border-color:#b5b5b5!important}:host ::ng-deep .p-disabled .p-checkbox-icon{color:#fff!important}.sk-checkbox__label{font-family:Open Sans,system-ui,sans-serif;font-size:14px;font-weight:400;line-height:20px;color:var(--texts-dark, #404040);transition:color .15s ease}.sk-checkbox--disabled .sk-checkbox__label{color:var(--texts-light, #a5a5a5)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], showLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "showLabel", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "checked", required: false }] }], checkedChange: [{ type: i0.Output, args: ["checkedChange"] }], focused: [{ type: i0.Output, args: ["focused"] }], blurred: [{ type: i0.Output, args: ["blurred"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], indeterminate: [{ type: i0.Input, args: [{ isSignal: true, alias: "indeterminate", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }] } });

class SkChipComponent {
    variant = input('primary', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    size = input('large', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    showIcon = input(false, { ...(ngDevMode ? { debugName: "showIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showDelete = input(false, { ...(ngDevMode ? { debugName: "showDelete" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    label = input(undefined, ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    icon = input(undefined, ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    image = input(undefined, ...(ngDevMode ? [{ debugName: "image" }] : /* istanbul ignore next */ []));
    alt = input(undefined, ...(ngDevMode ? [{ debugName: "alt" }] : /* istanbul ignore next */ []));
    removable = input(false, { ...(ngDevMode ? { debugName: "removable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    styleClass = input(undefined, ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    removed = output();
    imageError = output();
    visible = true;
    constructor() {
        effect(() => {
            // reset visibility when label changes
            this.label();
            this.visible = true;
        });
    }
    handleRemove(_event) {
        this.visible = false;
        this.removed.emit(this.label() || '');
    }
    isRemovable = computed(() => this.removable() || this.showDelete(), ...(ngDevMode ? [{ debugName: "isRemovable" }] : /* istanbul ignore next */ []));
    /** Normalises icon name: accepts 'user', 'pi pi-user', or undefined. */
    resolvedLeftIcon = computed(() => {
        if (!this.showIcon())
            return '';
        const icon = this.icon();
        if (!icon)
            return 'pi pi-user';
        return icon.startsWith('pi ') ? icon : `pi pi-${icon}`;
    }, ...(ngDevMode ? [{ debugName: "resolvedLeftIcon" }] : /* istanbul ignore next */ []));
    chipStyleClass = computed(() => [`sk-chip--${this.variant()}`, `sk-chip--${this.size()}`, this.styleClass() ?? '']
        .filter(Boolean).join(' '), ...(ngDevMode ? [{ debugName: "chipStyleClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkChipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkChipComponent, isStandalone: true, selector: "sk-chip", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, showIcon: { classPropertyName: "showIcon", publicName: "showIcon", isSignal: true, isRequired: false, transformFunction: null }, showDelete: { classPropertyName: "showDelete", publicName: "showDelete", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, image: { classPropertyName: "image", publicName: "image", isSignal: true, isRequired: false, transformFunction: null }, alt: { classPropertyName: "alt", publicName: "alt", isSignal: true, isRequired: false, transformFunction: null }, removable: { classPropertyName: "removable", publicName: "removable", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { removed: "removed", imageError: "imageError" }, ngImport: i0, template: "@if (visible) {\r\n      <p-chip\r\n        [label]=\"label()\"\r\n        [icon]=\"resolvedLeftIcon()\"\r\n        [image]=\"image()\"\r\n        [alt]=\"alt()\"\r\n        [removable]=\"isRemovable()\"\r\n        [disabled]=\"disabled()\"\r\n        [styleClass]=\"chipStyleClass()\"\r\n        (onRemove)=\"handleRemove($event)\"\r\n        (onImageError)=\"imageError.emit($event)\"\r\n      ></p-chip>\r\n    }\r\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}:host ::ng-deep p-chip{display:inline-flex!important;align-items:center!important;border:none!important;box-shadow:none!important;gap:0!important;cursor:default}:host ::ng-deep .p-chip{border-radius:9999px!important}:host ::ng-deep .p-chip-label{color:var(--texts-dark, #404040)!important;margin:0!important;padding:0!important}:host ::ng-deep .p-chip-icon{color:var(--icon-neutral, #404040)!important;margin:0!important;flex-shrink:0}:host ::ng-deep .p-chip-remove-icon{color:var(--icon-neutral-2, #666666)!important;margin:0!important;cursor:pointer;flex-shrink:0}:host ::ng-deep .p-chip-remove-icon path{fill:var(--icon-neutral-2, #666666)!important}:host ::ng-deep .p-chip.sk-chip--large{height:38px;padding:0 12px!important;font-size:var(--label-medium-size, .875rem)!important;font-weight:var(--label-medium-weight, 500)!important;line-height:var(--label-medium-line-height, 1.375rem)!important}:host ::ng-deep .p-chip.sk-chip--large .p-chip-icon{font-size:16px!important;margin-right:8px!important}:host ::ng-deep .p-chip.sk-chip--large .p-chip-remove-icon{width:16px!important;height:16px!important;font-size:16px!important;margin-left:12px!important}:host ::ng-deep .p-chip.sk-chip--small{height:28px;padding:0 8px!important;font-size:var(--caption-body-3-size, .75rem)!important;font-weight:var(--caption-body-3-weight, 500)!important;line-height:var(--caption-body-3-line-height, 1.25rem)!important}:host ::ng-deep .p-chip.sk-chip--small .p-chip-icon{font-size:12px!important;margin-right:4px!important}:host ::ng-deep .p-chip.sk-chip--small .p-chip-remove-icon{width:12px!important;height:12px!important;font-size:12px!important;margin-left:8px!important}:host ::ng-deep .p-chip.sk-chip--primary{background:var(--background-brand-light, #f6fcf2)!important}:host ::ng-deep .p-chip.sk-chip--secondary{background:var(--background-grey-light, #f7f7f7)!important}\n"], dependencies: [{ kind: "component", type: Chip, selector: "p-chip", inputs: ["label", "icon", "image", "alt", "styleClass", "disabled", "removable", "removeIcon", "chipProps"], outputs: ["onRemove", "onImageError"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkChipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-chip', standalone: true, imports: [Chip], template: "@if (visible) {\r\n      <p-chip\r\n        [label]=\"label()\"\r\n        [icon]=\"resolvedLeftIcon()\"\r\n        [image]=\"image()\"\r\n        [alt]=\"alt()\"\r\n        [removable]=\"isRemovable()\"\r\n        [disabled]=\"disabled()\"\r\n        [styleClass]=\"chipStyleClass()\"\r\n        (onRemove)=\"handleRemove($event)\"\r\n        (onImageError)=\"imageError.emit($event)\"\r\n      ></p-chip>\r\n    }\r\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}:host ::ng-deep p-chip{display:inline-flex!important;align-items:center!important;border:none!important;box-shadow:none!important;gap:0!important;cursor:default}:host ::ng-deep .p-chip{border-radius:9999px!important}:host ::ng-deep .p-chip-label{color:var(--texts-dark, #404040)!important;margin:0!important;padding:0!important}:host ::ng-deep .p-chip-icon{color:var(--icon-neutral, #404040)!important;margin:0!important;flex-shrink:0}:host ::ng-deep .p-chip-remove-icon{color:var(--icon-neutral-2, #666666)!important;margin:0!important;cursor:pointer;flex-shrink:0}:host ::ng-deep .p-chip-remove-icon path{fill:var(--icon-neutral-2, #666666)!important}:host ::ng-deep .p-chip.sk-chip--large{height:38px;padding:0 12px!important;font-size:var(--label-medium-size, .875rem)!important;font-weight:var(--label-medium-weight, 500)!important;line-height:var(--label-medium-line-height, 1.375rem)!important}:host ::ng-deep .p-chip.sk-chip--large .p-chip-icon{font-size:16px!important;margin-right:8px!important}:host ::ng-deep .p-chip.sk-chip--large .p-chip-remove-icon{width:16px!important;height:16px!important;font-size:16px!important;margin-left:12px!important}:host ::ng-deep .p-chip.sk-chip--small{height:28px;padding:0 8px!important;font-size:var(--caption-body-3-size, .75rem)!important;font-weight:var(--caption-body-3-weight, 500)!important;line-height:var(--caption-body-3-line-height, 1.25rem)!important}:host ::ng-deep .p-chip.sk-chip--small .p-chip-icon{font-size:12px!important;margin-right:4px!important}:host ::ng-deep .p-chip.sk-chip--small .p-chip-remove-icon{width:12px!important;height:12px!important;font-size:12px!important;margin-left:8px!important}:host ::ng-deep .p-chip.sk-chip--primary{background:var(--background-brand-light, #f6fcf2)!important}:host ::ng-deep .p-chip.sk-chip--secondary{background:var(--background-grey-light, #f7f7f7)!important}\n"] }]
        }], ctorParameters: () => [], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], showIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showIcon", required: false }] }], showDelete: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDelete", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], image: [{ type: i0.Input, args: [{ isSignal: true, alias: "image", required: false }] }], alt: [{ type: i0.Input, args: [{ isSignal: true, alias: "alt", required: false }] }], removable: [{ type: i0.Input, args: [{ isSignal: true, alias: "removable", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], removed: [{ type: i0.Output, args: ["removed"] }], imageError: [{ type: i0.Output, args: ["imageError"] }] } });

class SkColorPickerComponent {
    inline = input(false, { ...(ngDevMode ? { debugName: "inline" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    format = input('hex', ...(ngDevMode ? [{ debugName: "format" }] : /* istanbul ignore next */ []));
    valueChange = output();
    value = '#22c55e';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkColorPickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkColorPickerComponent, isStandalone: true, selector: "sk-colorpicker", inputs: { inline: { classPropertyName: "inline", publicName: "inline", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, format: { classPropertyName: "format", publicName: "format", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <p-colorpicker
      [(ngModel)]="value"
      [inline]="inline()"
      [disabled]="disabled()"
      [format]="format()"
      (onChange)="valueChange.emit($event)"
    />
  `, isInline: true, styles: [":host{display:inline-flex}\n"], dependencies: [{ kind: "component", type: ColorPicker, selector: "p-colorPicker, p-colorpicker, p-color-picker", inputs: ["styleClass", "showTransitionOptions", "hideTransitionOptions", "inline", "format", "tabindex", "inputId", "autoZIndex", "autofocus", "defaultColor", "appendTo", "overlayOptions", "motionOptions"], outputs: ["onChange", "onShow", "onHide"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkColorPickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-colorpicker', standalone: true, imports: [ColorPicker, FormsModule], template: `
    <p-colorpicker
      [(ngModel)]="value"
      [inline]="inline()"
      [disabled]="disabled()"
      [format]="format()"
      (onChange)="valueChange.emit($event)"
    />
  `, styles: [":host{display:inline-flex}\n"] }]
        }], propDecorators: { inline: [{ type: i0.Input, args: [{ isSignal: true, alias: "inline", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], format: [{ type: i0.Input, args: [{ isSignal: true, alias: "format", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkConfirmDialogComponent {
    message = input('¿Estás seguro de que deseas continuar con esta acción?', ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    header = input('Confirmación requerida', ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    acceptLabel = input('Sí, continuar', ...(ngDevMode ? [{ debugName: "acceptLabel" }] : /* istanbul ignore next */ []));
    rejectLabel = input('Cancelar', ...(ngDevMode ? [{ debugName: "rejectLabel" }] : /* istanbul ignore next */ []));
    triggerLabel = input('Abrir diálogo', ...(ngDevMode ? [{ debugName: "triggerLabel" }] : /* istanbul ignore next */ []));
    showTrigger = input(true, { ...(ngDevMode ? { debugName: "showTrigger" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    accepted = output();
    rejected = output();
    visible = signal(false, ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    get dialogTitle() { return this.header(); }
    open() { this.visible.set(true); }
    showConfirm() { this.open(); }
    onAccept() {
        this.visible.set(false);
        this.accepted.emit();
    }
    onReject() {
        this.visible.set(false);
        this.rejected.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkConfirmDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkConfirmDialogComponent, isStandalone: true, selector: "sk-confirmdialog", inputs: { message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, acceptLabel: { classPropertyName: "acceptLabel", publicName: "acceptLabel", isSignal: true, isRequired: false, transformFunction: null }, rejectLabel: { classPropertyName: "rejectLabel", publicName: "rejectLabel", isSignal: true, isRequired: false, transformFunction: null }, triggerLabel: { classPropertyName: "triggerLabel", publicName: "triggerLabel", isSignal: true, isRequired: false, transformFunction: null }, showTrigger: { classPropertyName: "showTrigger", publicName: "showTrigger", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { accepted: "accepted", rejected: "rejected" }, ngImport: i0, template: `
    @if (showTrigger()) {
      <p-button
        [label]="triggerLabel()"
        styleClass="sk-btn--fill"
        (onClick)="open()"
      />
    }

    <p-dialog
      [visible]="visible()"
      (visibleChange)="visible.set($event)"
      [modal]="true"
      [closable]="true"
      [style]="{ width: '420px', 'max-width': '90vw' }"
      styleClass="sk-confirmdialog__dialog"
    >
      <ng-template #header>
        <h4 class="sk-confirmdialog__title">{{ dialogTitle }}</h4>
      </ng-template>

      <div class="sk-confirmdialog__body">
        <span class="sk-confirmdialog__message">{{ message() }}</span>
      </div>

      <div class="sk-confirmdialog__actions">
        <p-button [label]="rejectLabel()" styleClass="sk-btn--outline" [outlined]="true" (onClick)="onReject()" />
        <p-button [label]="acceptLabel()" styleClass="sk-btn--fill"                      (onClick)="onAccept()" />
      </div>
    </p-dialog>
  `, isInline: true, styles: [":host{display:block}::ng-deep .sk-confirmdialog__dialog .p-dialog-header h4.sk-confirmdialog__title{flex:1!important;margin:0!important;font-family:var(--supporting-title-h4-bold-18px-font, var(--title, \"Montserrat\", sans-serif))!important;font-size:var(--supporting-title-h4-bold-18px-size, 1.125rem)!important;font-weight:var(--supporting-title-h4-bold-18px-weight, 700)!important;line-height:var(--supporting-title-h4-bold-18px-line-height, 1.625rem)!important;letter-spacing:var(--supporting-title-h4-bold-18px-tracking, 0rem)!important;color:var(--texts-dark, #232323)!important;text-align:center!important}.sk-confirmdialog__body{display:flex;align-items:flex-start;gap:12px;padding:4px 0 20px}.sk-confirmdialog__message{font-family:var(--body-medium-font, var(--body, \"Open Sans\", sans-serif));font-weight:var(--body-medium-weight, 500);font-size:var(--body-medium-size, 1rem);line-height:var(--body-medium-line-height, 1.5rem);letter-spacing:var(--body-medium-tracking, 0);color:var(--texts-medium, #666666);text-align:center}.sk-confirmdialog__actions{display:flex;gap:12px;justify-content:center;padding-bottom:4px}::ng-deep .sk-confirmdialog__dialog.p-dialog{border-radius:var(--radius-lg, 16px)!important;overflow:hidden;box-shadow:0 20px 48px #23232329!important}::ng-deep .sk-confirmdialog__dialog .p-dialog-header{padding:20px 24px 12px!important;border-bottom:none!important;position:relative!important}::ng-deep .sk-confirmdialog__dialog .p-dialog-header-actions{position:absolute!important;right:16px!important;top:50%!important;transform:translateY(-50%)!important}::ng-deep .sk-confirmdialog__dialog .p-dialog-content{padding:8px 24px 20px!important}\n"], dependencies: [{ kind: "component", type: Dialog, selector: "p-dialog", inputs: ["hostName", "header", "draggable", "resizable", "contentStyle", "contentStyleClass", "modal", "closeOnEscape", "dismissableMask", "rtl", "closable", "breakpoints", "styleClass", "maskStyleClass", "maskStyle", "showHeader", "blockScroll", "autoZIndex", "baseZIndex", "minX", "minY", "focusOnShow", "maximizable", "keepInViewport", "focusTrap", "transitionOptions", "maskMotionOptions", "motionOptions", "closeIcon", "closeAriaLabel", "closeTabindex", "minimizeIcon", "maximizeIcon", "closeButtonProps", "maximizeButtonProps", "visible", "style", "position", "role", "appendTo", "content", "contentTemplate", "footerTemplate", "closeIconTemplate", "maximizeIconTemplate", "minimizeIconTemplate", "headlessTemplate"], outputs: ["onShow", "onHide", "visibleChange", "onResizeInit", "onResizeEnd", "onDragEnd", "onMaximize"] }, { kind: "component", type: Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkConfirmDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-confirmdialog', standalone: true, imports: [Dialog, Button], template: `
    @if (showTrigger()) {
      <p-button
        [label]="triggerLabel()"
        styleClass="sk-btn--fill"
        (onClick)="open()"
      />
    }

    <p-dialog
      [visible]="visible()"
      (visibleChange)="visible.set($event)"
      [modal]="true"
      [closable]="true"
      [style]="{ width: '420px', 'max-width': '90vw' }"
      styleClass="sk-confirmdialog__dialog"
    >
      <ng-template #header>
        <h4 class="sk-confirmdialog__title">{{ dialogTitle }}</h4>
      </ng-template>

      <div class="sk-confirmdialog__body">
        <span class="sk-confirmdialog__message">{{ message() }}</span>
      </div>

      <div class="sk-confirmdialog__actions">
        <p-button [label]="rejectLabel()" styleClass="sk-btn--outline" [outlined]="true" (onClick)="onReject()" />
        <p-button [label]="acceptLabel()" styleClass="sk-btn--fill"                      (onClick)="onAccept()" />
      </div>
    </p-dialog>
  `, styles: [":host{display:block}::ng-deep .sk-confirmdialog__dialog .p-dialog-header h4.sk-confirmdialog__title{flex:1!important;margin:0!important;font-family:var(--supporting-title-h4-bold-18px-font, var(--title, \"Montserrat\", sans-serif))!important;font-size:var(--supporting-title-h4-bold-18px-size, 1.125rem)!important;font-weight:var(--supporting-title-h4-bold-18px-weight, 700)!important;line-height:var(--supporting-title-h4-bold-18px-line-height, 1.625rem)!important;letter-spacing:var(--supporting-title-h4-bold-18px-tracking, 0rem)!important;color:var(--texts-dark, #232323)!important;text-align:center!important}.sk-confirmdialog__body{display:flex;align-items:flex-start;gap:12px;padding:4px 0 20px}.sk-confirmdialog__message{font-family:var(--body-medium-font, var(--body, \"Open Sans\", sans-serif));font-weight:var(--body-medium-weight, 500);font-size:var(--body-medium-size, 1rem);line-height:var(--body-medium-line-height, 1.5rem);letter-spacing:var(--body-medium-tracking, 0);color:var(--texts-medium, #666666);text-align:center}.sk-confirmdialog__actions{display:flex;gap:12px;justify-content:center;padding-bottom:4px}::ng-deep .sk-confirmdialog__dialog.p-dialog{border-radius:var(--radius-lg, 16px)!important;overflow:hidden;box-shadow:0 20px 48px #23232329!important}::ng-deep .sk-confirmdialog__dialog .p-dialog-header{padding:20px 24px 12px!important;border-bottom:none!important;position:relative!important}::ng-deep .sk-confirmdialog__dialog .p-dialog-header-actions{position:absolute!important;right:16px!important;top:50%!important;transform:translateY(-50%)!important}::ng-deep .sk-confirmdialog__dialog .p-dialog-content{padding:8px 24px 20px!important}\n"] }]
        }], propDecorators: { message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], acceptLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "acceptLabel", required: false }] }], rejectLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "rejectLabel", required: false }] }], triggerLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "triggerLabel", required: false }] }], showTrigger: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTrigger", required: false }] }], accepted: [{ type: i0.Output, args: ["accepted"] }], rejected: [{ type: i0.Output, args: ["rejected"] }] } });

class SkContextMenuComponent {
    cm;
    model = input([
        { label: 'Ver', icon: 'pi pi-eye' },
        { label: 'Editar', icon: 'pi pi-pencil' },
        { label: 'Copiar', icon: 'pi pi-copy' },
        { separator: true },
        { label: 'Eliminar', icon: 'pi pi-trash' },
    ], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkContextMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkContextMenuComponent, isStandalone: true, selector: "sk-contextmenu", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "cm", first: true, predicate: ["cm"], descendants: true }], ngImport: i0, template: `
    <div
      style="padding:32px;border:2px dashed var(--p-surface-300,#d1d5db);border-radius:8px;text-align:center;cursor:context-menu;user-select:none;color:var(--p-surface-500,#6b7280);font-size:13px;"
      (contextmenu)="cm.show($event)"
    >
      <i class="pi pi-mouse" style="font-size:20px;margin-bottom:8px;display:block;"></i>
      Haz clic derecho aquí para ver el menú contextual
    </div>
    <p-contextmenu #cm [model]="model()" />
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: ContextMenu, selector: "p-contextMenu, p-contextmenu, p-context-menu", inputs: ["model", "triggerEvent", "target", "global", "style", "styleClass", "autoZIndex", "baseZIndex", "id", "breakpoint", "ariaLabel", "ariaLabelledBy", "pressDelay", "appendTo", "motionOptions"], outputs: ["onShow", "onHide"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkContextMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-contextmenu', standalone: true, imports: [ContextMenu], template: `
    <div
      style="padding:32px;border:2px dashed var(--p-surface-300,#d1d5db);border-radius:8px;text-align:center;cursor:context-menu;user-select:none;color:var(--p-surface-500,#6b7280);font-size:13px;"
      (contextmenu)="cm.show($event)"
    >
      <i class="pi pi-mouse" style="font-size:20px;margin-bottom:8px;display:block;"></i>
      Haz clic derecho aquí para ver el menú contextual
    </div>
    <p-contextmenu #cm [model]="model()" />
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { cm: [{
                type: ViewChild,
                args: ['cm']
            }], model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }] } });

/**
 * sk-data-table
 * ============================================================================
 *
 * Tabla AVANZADA del Design System de Skandia.
 *
 * No es un componente nuevo: es la re-exportación directa del `TableModule`
 * de PrimeNG bajo el namespace de Skandia. La idea es no reinventar la rueda:
 * el dev tiene acceso a todo el poder de PrimeNG Table (filtros, sort,
 * paginación lazy/cliente, selección, expansión, edición de celda/fila,
 * reorder/resize, frozen, export CSV, etc.) sin que el sistema agregue una
 * capa de wrapping que limite o duplique.
 *
 * ## Cuándo usar sk-data-table vs sk-table
 *
 * - `sk-table`  →  Tabla rápida y simple: data + columns + paginator/striped/
 *                   gridlines. Sin filtros, sin sort, sin edición. 5 props.
 *                   Cubre el caso "necesito mostrar datos sin complicarme".
 * - `sk-data-table` (este) → Tabla avanzada para casos de negocio reales.
 *                   API completa de PrimeNG Table.
 *
 * ## Importante sobre el selector HTML
 *
 * Angular no permite alias de selector. Por eso el tag HTML sigue siendo
 * `<p-table>` (el de PrimeNG). El namespace `sk` vive en el import, no en
 * el tag. Esto es intencional: usar PrimeNG directamente nos da la API
 * idéntica, la documentación oficial sigue aplicando, y los upgrades de
 * PrimeNG se reflejan automáticamente.
 *
 * ## Look & feel Skandia
 *
 * El preset Skandia (`skandia.preset.ts`) ya define el bloque `datatable` y
 * `paginator` con tokens de Skandia (colores, bordes, paddings, tipografía).
 * Cualquier `<p-table>` que se renderice en la app hereda automáticamente
 * el look Skandia. No hace falta CSS adicional.
 *
 * ## Ejemplo de uso
 *
 * ```ts
 * import {
 *   SkDataTableModule,
 *   SkDataTableLazyLoadEvent,
 *   SkDataTableEditCompleteEvent,
 * } from '@sk-design-system/sk-data-table';
 *
 * @Component({
 *   standalone: true,
 *   imports: [SkDataTableModule],
 *   template: `
 *     <p-table
 *       [value]="rows"
 *       [paginator]="true"
 *       [rows]="10"
 *       [rowsPerPageOptions]="[10, 25, 50]"
 *       [globalFilterFields]="['name', 'role']"
 *       sortMode="single"
 *       dataKey="id"
 *       editMode="cell"
 *       (onLazyLoad)="onLazy($event)"
 *       (onEditComplete)="onEdit($event)"
 *     >
 *       <ng-template pTemplate="caption">
 *         <input pInputText type="text" placeholder="Buscar..."
 *                (input)="dt.filterGlobal($event.target.value, 'contains')"/>
 *       </ng-template>
 *
 *       <ng-template pTemplate="header">
 *         <tr>
 *           <th pSortableColumn="name">
 *             Nombre <p-sortIcon field="name" />
 *           </th>
 *           <th>
 *             Rol
 *             <p-columnFilter type="text" field="role" display="menu" />
 *           </th>
 *         </tr>
 *       </ng-template>
 *
 *       <ng-template pTemplate="body" let-row>
 *         <tr>
 *           <td [pEditableColumn]="row" pEditableColumnField="name">
 *             <p-cellEditor>
 *               <ng-template pTemplate="input">
 *                 <input pInputText [(ngModel)]="row.name" />
 *               </ng-template>
 *               <ng-template pTemplate="output">{{ row.name }}</ng-template>
 *             </p-cellEditor>
 *           </td>
 *           <td>{{ row.role }}</td>
 *         </tr>
 *       </ng-template>
 *     </p-table>
 *   `,
 * })
 * export class MyPage { ... }
 * ```
 *
 * Ver documentación completa: https://primeng.org/table
 */
// ── Módulo y componentes/directivas ─────────────────────────────────────────

class SkDataViewComponent {
    items = input([
        { name: 'Angular', category: 'Framework', status: 'Activo' },
        { name: 'React', category: 'Librería', status: 'Activo' },
        { name: 'Vue', category: 'Framework', status: 'Activo' },
        { name: 'Ember', category: 'Framework', status: 'Inactivo' },
        { name: 'Backbone', category: 'Librería', status: 'Inactivo' },
        { name: 'Svelte', category: 'Compilador', status: 'Activo' },
    ], ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    layout = input('list', ...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDataViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkDataViewComponent, isStandalone: true, selector: "sk-dataview", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-dataview [value]="items()" [layout]="layout()">
      <ng-template #list let-items>
        <div style="display:flex;flex-direction:column;gap:8px;padding:8px;">
          @for (item of items; track item.name) {
            <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border:1px solid var(--p-surface-200,#e5e7eb);border-radius:8px;background:#fff;">
              <div>
                <div style="font-weight:600;font-size:14px;">{{ item.name }}</div>
                <div style="font-size:12px;color:var(--p-surface-500,#6b7280);">{{ item.category }}</div>
              </div>
              <p-tag [value]="item.status" [severity]="item.status === 'Activo' ? 'success' : 'warn'" />
            </div>
          }
        </div>
      </ng-template>
      <ng-template #grid let-items>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;padding:8px;">
          @for (item of items; track item.name) {
            <div style="padding:16px;border:1px solid var(--p-surface-200,#e5e7eb);border-radius:8px;background:#fff;text-align:center;">
              <div style="font-weight:600;font-size:14px;margin-bottom:8px;">{{ item.name }}</div>
              <p-tag [value]="item.status" [severity]="item.status === 'Activo' ? 'success' : 'warn'" />
            </div>
          }
        </div>
      </ng-template>
    </p-dataview>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: DataView, selector: "p-dataView, p-dataview, p-data-view", inputs: ["paginator", "rows", "totalRecords", "pageLinks", "rowsPerPageOptions", "paginatorPosition", "paginatorStyleClass", "alwaysShowPaginator", "paginatorDropdownAppendTo", "paginatorDropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showFirstLastIcon", "showPageLinks", "lazy", "lazyLoadOnInit", "emptyMessage", "styleClass", "gridStyleClass", "trackBy", "filterBy", "filterLocale", "loading", "loadingIcon", "first", "sortField", "sortOrder", "value", "layout"], outputs: ["onLazyLoad", "onPage", "onSort", "onChangeLayout"] }, { kind: "component", type: Tag, selector: "p-tag", inputs: ["styleClass", "severity", "value", "icon", "rounded"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDataViewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-dataview', standalone: true, imports: [DataView, Tag], template: `
    <p-dataview [value]="items()" [layout]="layout()">
      <ng-template #list let-items>
        <div style="display:flex;flex-direction:column;gap:8px;padding:8px;">
          @for (item of items; track item.name) {
            <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border:1px solid var(--p-surface-200,#e5e7eb);border-radius:8px;background:#fff;">
              <div>
                <div style="font-weight:600;font-size:14px;">{{ item.name }}</div>
                <div style="font-size:12px;color:var(--p-surface-500,#6b7280);">{{ item.category }}</div>
              </div>
              <p-tag [value]="item.status" [severity]="item.status === 'Activo' ? 'success' : 'warn'" />
            </div>
          }
        </div>
      </ng-template>
      <ng-template #grid let-items>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;padding:8px;">
          @for (item of items; track item.name) {
            <div style="padding:16px;border:1px solid var(--p-surface-200,#e5e7eb);border-radius:8px;background:#fff;text-align:center;">
              <div style="font-weight:600;font-size:14px;margin-bottom:8px;">{{ item.name }}</div>
              <p-tag [value]="item.status" [severity]="item.status === 'Activo' ? 'success' : 'warn'" />
            </div>
          }
        </div>
      </ng-template>
    </p-dataview>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: false }] }] } });

let _datepickerUid = 0;
class SkDatePickerComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    helpText = input('', ...(ngDevMode ? [{ debugName: "helpText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    showIcon = input(true, { ...(ngDevMode ? { debugName: "showIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dateFormat = input('dd/mm/yy', ...(ngDevMode ? [{ debugName: "dateFormat" }] : /* istanbul ignore next */ []));
    showTime = input(false, { ...(ngDevMode ? { debugName: "showTime" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showButtonBar = input(false, { ...(ngDevMode ? { debugName: "showButtonBar" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    inline = input(false, { ...(ngDevMode ? { debugName: "inline" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selected = output();
    inputId = `sk-datepicker-${_datepickerUid++}`;
    _value = signal(null, ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    _onTouched = () => { };
    handleInput(val) {
        this._value.set(val);
        this._onChange(val);
    }
    handleBlur() { this._onTouched(); }
    writeValue(val) { this._value.set(val ?? null); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this._onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDatePickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkDatePickerComponent, isStandalone: true, selector: "sk-datepicker", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, showIcon: { classPropertyName: "showIcon", publicName: "showIcon", isSignal: true, isRequired: false, transformFunction: null }, dateFormat: { classPropertyName: "dateFormat", publicName: "dateFormat", isSignal: true, isRequired: false, transformFunction: null }, showTime: { classPropertyName: "showTime", publicName: "showTime", isSignal: true, isRequired: false, transformFunction: null }, showButtonBar: { classPropertyName: "showButtonBar", publicName: "showButtonBar", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, inline: { classPropertyName: "inline", publicName: "inline", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selected: "selected" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkDatePickerComponent), multi: true }], ngImport: i0, template: "<div\r\n  class=\"sk-datepicker\"\r\n  [class.sk-datepicker--fluid]=\"fluid()\"\r\n  [class.sk-datepicker--invalid]=\"invalid()\"\r\n  [class.sk-datepicker--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-datepicker__floatlabel\">\r\n    <p-datepicker\r\n      [inputId]=\"inputId\"\r\n      [ngModel]=\"_value()\"\r\n      (ngModelChange)=\"handleInput($event)\"\r\n      [showIcon]=\"showIcon()\"\r\n      iconDisplay=\"input\"\r\n      [dateFormat]=\"dateFormat()\"\r\n      [showTime]=\"showTime()\"\r\n      [showButtonBar]=\"showButtonBar()\"\r\n      [disabled]=\"_isDisabled()\"\r\n      [invalid]=\"invalid()\"\r\n      [inline]=\"inline()\"\r\n      [fluid]=\"true\"\r\n      (onSelect)=\"selected.emit($event)\"\r\n      (onBlur)=\"handleBlur()\"\r\n      class=\"sk-datepicker__field\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-datepicker__help sk-datepicker__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-datepicker__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-datepicker{display:flex;flex-direction:column;gap:4px}.sk-datepicker__floatlabel,.sk-datepicker--fluid,.sk-datepicker--fluid .sk-datepicker__floatlabel,.sk-datepicker--fluid .sk-datepicker__field{width:100%}::ng-deep .sk-datepicker__field{width:100%}::ng-deep .sk-datepicker__field .p-datepicker-input{width:100%;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline-start:12px;padding-inline-end:40px!important;border-radius:var(--bordes-s, 4px);font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);box-sizing:border-box}::ng-deep .sk-datepicker__floatlabel label{font-size:14px}::ng-deep .p-datepicker-panel{font-size:var(--label-body-2-size, 14px);border-radius:var(--bordes-s, 4px)!important}::ng-deep .p-datepicker-panel .p-datepicker-day-view{font-size:var(--label-body-2-size, 14px)}::ng-deep .p-datepicker-panel .p-datepicker-weekday-cell{text-align:center}::ng-deep .sk-datepicker--invalid .sk-datepicker__field.p-datepicker-input{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-datepicker--disabled .sk-datepicker__field.p-datepicker-input{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-datepicker__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-datepicker__help--error{color:var(--color-error, #e03430)}\n"], dependencies: [{ kind: "component", type: DatePicker, selector: "p-datePicker, p-datepicker, p-date-picker", inputs: ["iconDisplay", "styleClass", "inputStyle", "inputId", "inputStyleClass", "placeholder", "ariaLabelledBy", "ariaLabel", "iconAriaLabel", "dateFormat", "multipleSeparator", "rangeSeparator", "inline", "showOtherMonths", "selectOtherMonths", "showIcon", "icon", "readonlyInput", "shortYearCutoff", "hourFormat", "timeOnly", "stepHour", "stepMinute", "stepSecond", "showSeconds", "showOnFocus", "showWeek", "startWeekFromFirstDayOfYear", "showClear", "dataType", "selectionMode", "maxDateCount", "showButtonBar", "todayButtonStyleClass", "clearButtonStyleClass", "autofocus", "autoZIndex", "baseZIndex", "panelStyleClass", "panelStyle", "keepInvalid", "hideOnDateTimeSelect", "touchUI", "timeSeparator", "focusTrap", "showTransitionOptions", "hideTransitionOptions", "tabindex", "minDate", "maxDate", "disabledDates", "disabledDays", "showTime", "responsiveOptions", "numberOfMonths", "firstDayOfWeek", "view", "defaultDate", "appendTo", "motionOptions"], outputs: ["onFocus", "onBlur", "onClose", "onSelect", "onClear", "onInput", "onTodayClick", "onClearClick", "onMonthChange", "onYearChange", "onClickOutside", "onShow"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-datepicker', standalone: true, imports: [DatePicker, FloatLabel, FormsModule], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkDatePickerComponent), multi: true }], template: "<div\r\n  class=\"sk-datepicker\"\r\n  [class.sk-datepicker--fluid]=\"fluid()\"\r\n  [class.sk-datepicker--invalid]=\"invalid()\"\r\n  [class.sk-datepicker--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-datepicker__floatlabel\">\r\n    <p-datepicker\r\n      [inputId]=\"inputId\"\r\n      [ngModel]=\"_value()\"\r\n      (ngModelChange)=\"handleInput($event)\"\r\n      [showIcon]=\"showIcon()\"\r\n      iconDisplay=\"input\"\r\n      [dateFormat]=\"dateFormat()\"\r\n      [showTime]=\"showTime()\"\r\n      [showButtonBar]=\"showButtonBar()\"\r\n      [disabled]=\"_isDisabled()\"\r\n      [invalid]=\"invalid()\"\r\n      [inline]=\"inline()\"\r\n      [fluid]=\"true\"\r\n      (onSelect)=\"selected.emit($event)\"\r\n      (onBlur)=\"handleBlur()\"\r\n      class=\"sk-datepicker__field\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-datepicker__help sk-datepicker__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-datepicker__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-datepicker{display:flex;flex-direction:column;gap:4px}.sk-datepicker__floatlabel,.sk-datepicker--fluid,.sk-datepicker--fluid .sk-datepicker__floatlabel,.sk-datepicker--fluid .sk-datepicker__field{width:100%}::ng-deep .sk-datepicker__field{width:100%}::ng-deep .sk-datepicker__field .p-datepicker-input{width:100%;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline-start:12px;padding-inline-end:40px!important;border-radius:var(--bordes-s, 4px);font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);box-sizing:border-box}::ng-deep .sk-datepicker__floatlabel label{font-size:14px}::ng-deep .p-datepicker-panel{font-size:var(--label-body-2-size, 14px);border-radius:var(--bordes-s, 4px)!important}::ng-deep .p-datepicker-panel .p-datepicker-day-view{font-size:var(--label-body-2-size, 14px)}::ng-deep .p-datepicker-panel .p-datepicker-weekday-cell{text-align:center}::ng-deep .sk-datepicker--invalid .sk-datepicker__field.p-datepicker-input{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-datepicker--disabled .sk-datepicker__field.p-datepicker-input{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-datepicker__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-datepicker__help--error{color:var(--color-error, #e03430)}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], helpText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helpText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], showIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showIcon", required: false }] }], dateFormat: [{ type: i0.Input, args: [{ isSignal: true, alias: "dateFormat", required: false }] }], showTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTime", required: false }] }], showButtonBar: [{ type: i0.Input, args: [{ isSignal: true, alias: "showButtonBar", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], inline: [{ type: i0.Input, args: [{ isSignal: true, alias: "inline", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], selected: [{ type: i0.Output, args: ["selected"] }] } });

class SkDialogComponent {
    header = input('Título del diálogo', ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    content = input('Este es el contenido del diálogo modal. Aquí va la información o el formulario que el usuario debe revisar.', ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    contentHtml = input('', ...(ngDevMode ? [{ debugName: "contentHtml" }] : /* istanbul ignore next */ []));
    triggerLabel = input('Abrir diálogo', ...(ngDevMode ? [{ debugName: "triggerLabel" }] : /* istanbul ignore next */ []));
    showTrigger = input(false, { ...(ngDevMode ? { debugName: "showTrigger" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    modal = input(true, { ...(ngDevMode ? { debugName: "modal" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closable = input(true, { ...(ngDevMode ? { debugName: "closable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeOnEscape = input(true, { ...(ngDevMode ? { debugName: "closeOnEscape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    buttons = input({ confirm: 'Confirmar', cancel: 'Cancelar' }, ...(ngDevMode ? [{ debugName: "buttons" }] : /* istanbul ignore next */ []));
    confirm = output();
    cancel = output();
    show = output();
    hide = output();
    visible = false;
    onConfirm() {
        this.visible = false;
        this.confirm.emit();
    }
    onCancel() {
        this.visible = false;
        this.cancel.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkDialogComponent, isStandalone: true, selector: "sk-dialog", inputs: { header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: false, transformFunction: null }, contentHtml: { classPropertyName: "contentHtml", publicName: "contentHtml", isSignal: true, isRequired: false, transformFunction: null }, triggerLabel: { classPropertyName: "triggerLabel", publicName: "triggerLabel", isSignal: true, isRequired: false, transformFunction: null }, showTrigger: { classPropertyName: "showTrigger", publicName: "showTrigger", isSignal: true, isRequired: false, transformFunction: null }, modal: { classPropertyName: "modal", publicName: "modal", isSignal: true, isRequired: false, transformFunction: null }, closable: { classPropertyName: "closable", publicName: "closable", isSignal: true, isRequired: false, transformFunction: null }, closeOnEscape: { classPropertyName: "closeOnEscape", publicName: "closeOnEscape", isSignal: true, isRequired: false, transformFunction: null }, buttons: { classPropertyName: "buttons", publicName: "buttons", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { confirm: "confirm", cancel: "cancel", show: "show", hide: "hide" }, ngImport: i0, template: `
    @if (showTrigger()) {
      <p-button [label]="triggerLabel()" icon="pi pi-window-maximize" (onClick)="visible = true" />
    }
    <p-dialog
      [(visible)]="visible"
      [header]="header()"
      [modal]="modal()"
      [closable]="closable()"
      [closeOnEscape]="closeOnEscape()"
      [style]="{ width: '400px' }"
      (onShow)="show.emit()"
      (onHide)="hide.emit()"
    >
      @if (contentHtml()) {
        <div [innerHTML]="contentHtml()" style="margin:0;font-size:14px;color:var(--p-surface-600,#4b5563);"></div>
      } @else {
        <p style="margin:0;font-size:14px;color:var(--p-surface-600,#4b5563);">{{ content() }}</p>
      }
      <ng-template #footer>
        <p-button [label]="buttons().cancel" [text]="true" severity="secondary" (onClick)="onCancel()" />
        <p-button [label]="buttons().confirm" icon="pi pi-check" (onClick)="onConfirm()" />
      </ng-template>
    </p-dialog>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Dialog, selector: "p-dialog", inputs: ["hostName", "header", "draggable", "resizable", "contentStyle", "contentStyleClass", "modal", "closeOnEscape", "dismissableMask", "rtl", "closable", "breakpoints", "styleClass", "maskStyleClass", "maskStyle", "showHeader", "blockScroll", "autoZIndex", "baseZIndex", "minX", "minY", "focusOnShow", "maximizable", "keepInViewport", "focusTrap", "transitionOptions", "maskMotionOptions", "motionOptions", "closeIcon", "closeAriaLabel", "closeTabindex", "minimizeIcon", "maximizeIcon", "closeButtonProps", "maximizeButtonProps", "visible", "style", "position", "role", "appendTo", "content", "contentTemplate", "footerTemplate", "closeIconTemplate", "maximizeIconTemplate", "minimizeIconTemplate", "headlessTemplate"], outputs: ["onShow", "onHide", "visibleChange", "onResizeInit", "onResizeEnd", "onDragEnd", "onMaximize"] }, { kind: "component", type: Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-dialog', standalone: true, imports: [Dialog, Button], template: `
    @if (showTrigger()) {
      <p-button [label]="triggerLabel()" icon="pi pi-window-maximize" (onClick)="visible = true" />
    }
    <p-dialog
      [(visible)]="visible"
      [header]="header()"
      [modal]="modal()"
      [closable]="closable()"
      [closeOnEscape]="closeOnEscape()"
      [style]="{ width: '400px' }"
      (onShow)="show.emit()"
      (onHide)="hide.emit()"
    >
      @if (contentHtml()) {
        <div [innerHTML]="contentHtml()" style="margin:0;font-size:14px;color:var(--p-surface-600,#4b5563);"></div>
      } @else {
        <p style="margin:0;font-size:14px;color:var(--p-surface-600,#4b5563);">{{ content() }}</p>
      }
      <ng-template #footer>
        <p-button [label]="buttons().cancel" [text]="true" severity="secondary" (onClick)="onCancel()" />
        <p-button [label]="buttons().confirm" icon="pi pi-check" (onClick)="onConfirm()" />
      </ng-template>
    </p-dialog>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: false }] }], contentHtml: [{ type: i0.Input, args: [{ isSignal: true, alias: "contentHtml", required: false }] }], triggerLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "triggerLabel", required: false }] }], showTrigger: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTrigger", required: false }] }], modal: [{ type: i0.Input, args: [{ isSignal: true, alias: "modal", required: false }] }], closable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closable", required: false }] }], closeOnEscape: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnEscape", required: false }] }], buttons: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttons", required: false }] }], confirm: [{ type: i0.Output, args: ["confirm"] }], cancel: [{ type: i0.Output, args: ["cancel"] }], show: [{ type: i0.Output, args: ["show"] }], hide: [{ type: i0.Output, args: ["hide"] }] } });

class SkDividerComponent {
    layout = input('horizontal', ...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    type = input('solid', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    align = input('center', ...(ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []));
    label = input('o', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDividerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkDividerComponent, isStandalone: true, selector: "sk-divider", inputs: { layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-divider [layout]="layout()" [type]="type()" [align]="align()">
      @if (label()) {
        <span class="sk-divider__label">{{ label() }}</span>
      }
    </p-divider>
  `, isInline: true, styles: [":host{display:block}.sk-divider__label{font-size:.75rem;color:var(--texts-medium)}\n"], dependencies: [{ kind: "component", type: Divider, selector: "p-divider", inputs: ["styleClass", "layout", "type", "align"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDividerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-divider', standalone: true, imports: [Divider], template: `
    <p-divider [layout]="layout()" [type]="type()" [align]="align()">
      @if (label()) {
        <span class="sk-divider__label">{{ label() }}</span>
      }
    </p-divider>
  `, styles: [":host{display:block}.sk-divider__label{font-size:.75rem;color:var(--texts-medium)}\n"] }]
        }], propDecorators: { layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], align: [{ type: i0.Input, args: [{ isSignal: true, alias: "align", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

class SkDockComponent {
    position = input('bottom', ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    model = input([
        { label: 'Inicio', icon: 'pi pi-home', command: () => { } },
        { label: 'Archivos', icon: 'pi pi-folder', command: () => { } },
        { label: 'Mensajes', icon: 'pi pi-envelope', command: () => { } },
        { label: 'Galería', icon: 'pi pi-images', command: () => { } },
        { label: 'Música', icon: 'pi pi-headphones', command: () => { } },
        { label: 'Config', icon: 'pi pi-cog', command: () => { } },
    ], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDockComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkDockComponent, isStandalone: true, selector: "sk-dock", inputs: { position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div style="position:relative;height:140px;border:1px solid var(--p-surface-200,#e5e7eb);border-radius:8px;overflow:hidden;background:linear-gradient(135deg,#0f172a,#1e3a5f);">
      <p-dock [model]="model()" [position]="position()" />
    </div>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Dock, selector: "p-dock", inputs: ["id", "styleClass", "model", "position", "ariaLabel", "breakpoint", "ariaLabelledBy"], outputs: ["onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDockComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-dock', standalone: true, imports: [Dock], template: `
    <div style="position:relative;height:140px;border:1px solid var(--p-surface-200,#e5e7eb);border-radius:8px;overflow:hidden;background:linear-gradient(135deg,#0f172a,#1e3a5f);">
      <p-dock [model]="model()" [position]="position()" />
    </div>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: false }] }], model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }] } });

class SkDrawerComponent {
    header = input('Panel lateral', ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    content = input('', ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    triggerLabel = input('Abrir panel', ...(ngDevMode ? [{ debugName: "triggerLabel" }] : /* istanbul ignore next */ []));
    footerLabel = input('Cerrar', ...(ngDevMode ? [{ debugName: "footerLabel" }] : /* istanbul ignore next */ []));
    position = input('right', ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    modal = input(true, { ...(ngDevMode ? { debugName: "modal" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeOnEscape = input(true, { ...(ngDevMode ? { debugName: "closeOnEscape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    visible = input(false, { ...(ngDevMode ? { debugName: "visible" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    visibleChange = output();
    closed = output();
    _visible = signal(false, ...(ngDevMode ? [{ debugName: "_visible" }] : /* istanbul ignore next */ []));
    ngOnChanges(changes) {
        if (changes['visible']) {
            this._visible.set(this.visible());
        }
    }
    open() { this._visible.set(true); this.visibleChange.emit(true); }
    close() { this._visible.set(false); this.visibleChange.emit(false); }
    onVisibleChange(v) {
        this._visible.set(v);
        this.visibleChange.emit(v);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDrawerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkDrawerComponent, isStandalone: true, selector: "sk-drawer", inputs: { header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: false, transformFunction: null }, triggerLabel: { classPropertyName: "triggerLabel", publicName: "triggerLabel", isSignal: true, isRequired: false, transformFunction: null }, footerLabel: { classPropertyName: "footerLabel", publicName: "footerLabel", isSignal: true, isRequired: false, transformFunction: null }, position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, modal: { classPropertyName: "modal", publicName: "modal", isSignal: true, isRequired: false, transformFunction: null }, closeOnEscape: { classPropertyName: "closeOnEscape", publicName: "closeOnEscape", isSignal: true, isRequired: false, transformFunction: null }, visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { visibleChange: "visibleChange", closed: "closed" }, usesOnChanges: true, ngImport: i0, template: `
    @if (triggerLabel()) {
      <p-button
        [label]="triggerLabel()"
        icon="pi pi-arrow-right"
        severity="secondary"
        (onClick)="open()"
      />
    }
    <p-drawer
      [visible]="_visible()"
      (visibleChange)="onVisibleChange($event)"
      [header]="header()"
      [position]="position()"
      [modal]="modal()"
      [closeOnEscape]="closeOnEscape()"
      (onHide)="closed.emit()"
    >
      <div class="sk-drawer__body">
        @if (content()) {
          <p class="sk-drawer__text">{{ content() }}</p>
        }
        <ng-content />
      </div>
      @if (footerLabel()) {
        <ng-template #footer>
          <p-button
            [label]="footerLabel()"
            severity="secondary"
            [outlined]="true"
            [style]="{ width: '100%' }"
            (onClick)="close()"
          />
        </ng-template>
      }
    </p-drawer>
  `, isInline: true, styles: [":host{display:inline-block}.sk-drawer__body{padding:0;display:flex;flex-direction:column;gap:12px}.sk-drawer__text{margin:0;font-size:14px;line-height:1.6;color:var(--texts-medium, #666)}\n"], dependencies: [{ kind: "component", type: Drawer, selector: "p-drawer", inputs: ["appendTo", "motionOptions", "blockScroll", "style", "styleClass", "ariaCloseLabel", "autoZIndex", "baseZIndex", "modal", "closeButtonProps", "dismissible", "showCloseIcon", "closeOnEscape", "transitionOptions", "visible", "position", "fullScreen", "header", "maskStyle", "closable"], outputs: ["onShow", "onHide", "visibleChange"] }, { kind: "component", type: Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDrawerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-drawer', standalone: true, imports: [Drawer, Button], template: `
    @if (triggerLabel()) {
      <p-button
        [label]="triggerLabel()"
        icon="pi pi-arrow-right"
        severity="secondary"
        (onClick)="open()"
      />
    }
    <p-drawer
      [visible]="_visible()"
      (visibleChange)="onVisibleChange($event)"
      [header]="header()"
      [position]="position()"
      [modal]="modal()"
      [closeOnEscape]="closeOnEscape()"
      (onHide)="closed.emit()"
    >
      <div class="sk-drawer__body">
        @if (content()) {
          <p class="sk-drawer__text">{{ content() }}</p>
        }
        <ng-content />
      </div>
      @if (footerLabel()) {
        <ng-template #footer>
          <p-button
            [label]="footerLabel()"
            severity="secondary"
            [outlined]="true"
            [style]="{ width: '100%' }"
            (onClick)="close()"
          />
        </ng-template>
      }
    </p-drawer>
  `, styles: [":host{display:inline-block}.sk-drawer__body{padding:0;display:flex;flex-direction:column;gap:12px}.sk-drawer__text{margin:0;font-size:14px;line-height:1.6;color:var(--texts-medium, #666)}\n"] }]
        }], propDecorators: { header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: false }] }], triggerLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "triggerLabel", required: false }] }], footerLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "footerLabel", required: false }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: false }] }], modal: [{ type: i0.Input, args: [{ isSignal: true, alias: "modal", required: false }] }], closeOnEscape: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnEscape", required: false }] }], visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }], visibleChange: [{ type: i0.Output, args: ["visibleChange"] }], closed: [{ type: i0.Output, args: ["closed"] }] } });

let _dropdownUid = 0;
class SkDropdownComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    options = input([
        { label: 'Opción A', value: 'a' },
        { label: 'Opción B', value: 'b' },
        { label: 'Opción C', value: 'c' },
    ], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    optionLabel = input('label', ...(ngDevMode ? [{ debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    optionValue = input('value', ...(ngDevMode ? [{ debugName: "optionValue" }] : /* istanbul ignore next */ []));
    placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    helpText = input('', ...(ngDevMode ? [{ debugName: "helpText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showClear = input(false, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    filter = input(false, { ...(ngDevMode ? { debugName: "filter" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    inputId = `sk-dropdown-${_dropdownUid++}`;
    innerControl = new FormControl(null);
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    onTouched = () => { };
    sub;
    constructor() {
        this.sub = this.innerControl.valueChanges.subscribe(val => {
            this._onChange(val);
            this.valueChange.emit(val);
        });
        effect(() => {
            this._isDisabled()
                ? this.innerControl.disable({ emitEvent: false })
                : this.innerControl.enable({ emitEvent: false });
        });
    }
    writeValue(val) { this.innerControl.setValue(val ?? null, { emitEvent: false }); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    ngOnDestroy() { this.sub.unsubscribe(); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDropdownComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkDropdownComponent, isStandalone: true, selector: "sk-dropdown", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkDropdownComponent), multi: true }], ngImport: i0, template: "<div\r\n  class=\"sk-dropdown\"\r\n  [class.sk-dropdown--fluid]=\"fluid()\"\r\n  [class.sk-dropdown--invalid]=\"invalid()\"\r\n  [class.sk-dropdown--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-dropdown__floatlabel\">\r\n    <p-select\r\n      [inputId]=\"inputId\"\r\n      [formControl]=\"innerControl\"\r\n      [options]=\"options()\"\r\n      [optionLabel]=\"optionLabel()\"\r\n      [optionValue]=\"optionValue()\"\r\n      [showClear]=\"showClear()\"\r\n      [filter]=\"filter()\"\r\n      [invalid]=\"invalid()\"\r\n      [fluid]=\"fluid()\"\r\n      (onHide)=\"onTouched()\"\r\n      class=\"sk-dropdown__field\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-dropdown__help sk-dropdown__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-dropdown__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-dropdown{display:flex;flex-direction:column;gap:4px}.sk-dropdown__floatlabel,.sk-dropdown--fluid,.sk-dropdown--fluid .sk-dropdown__floatlabel,.sk-dropdown--fluid .sk-dropdown__field{width:100%}::ng-deep .sk-dropdown__field.p-select{width:100%;min-height:var(--size-048, 48px);padding-inline:12px;border-radius:var(--bordes-s, 4px)}::ng-deep .sk-dropdown__field.p-select .p-select-dropdown{padding:0!important;width:auto!important}::ng-deep .sk-dropdown__field.p-select .p-select-label{padding-block-start:20px;padding-block-end:6px;padding-inline:0!important;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);color:var(--texts-dark, #404040)}::ng-deep .sk-dropdown__floatlabel label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;color:var(--texts-medium, #666666)}::ng-deep .sk-dropdown--invalid .sk-dropdown__field.p-select{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-dropdown--disabled .sk-dropdown__field.p-select{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;cursor:not-allowed}.sk-dropdown__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, .75rem);font-weight:var(--caption-body-3-weight, 500);line-height:var(--caption-body-3-line-height, 1.25rem);color:var(--texts-medium, #666666);padding:0 4px}.sk-dropdown__help--error{color:var(--color-error, #e03430)}\n"], dependencies: [{ kind: "component", type: Select, selector: "p-select", inputs: ["id", "scrollHeight", "filter", "panelStyle", "styleClass", "panelStyleClass", "readonly", "editable", "tabindex", "placeholder", "loadingIcon", "filterPlaceholder", "filterLocale", "inputId", "dataKey", "filterBy", "filterFields", "autofocus", "resetFilterOnHide", "checkmark", "dropdownIcon", "loading", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "group", "showClear", "emptyFilterMessage", "emptyMessage", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "ariaLabel", "ariaLabelledBy", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "focusOnHover", "selectOnFocus", "autoOptionFocus", "autofocusFilter", "filterValue", "options", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onShow", "onHide", "onClear", "onLazyLoad"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkDropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-dropdown', standalone: true, imports: [Select, FloatLabel, ReactiveFormsModule], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkDropdownComponent), multi: true }], template: "<div\r\n  class=\"sk-dropdown\"\r\n  [class.sk-dropdown--fluid]=\"fluid()\"\r\n  [class.sk-dropdown--invalid]=\"invalid()\"\r\n  [class.sk-dropdown--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-dropdown__floatlabel\">\r\n    <p-select\r\n      [inputId]=\"inputId\"\r\n      [formControl]=\"innerControl\"\r\n      [options]=\"options()\"\r\n      [optionLabel]=\"optionLabel()\"\r\n      [optionValue]=\"optionValue()\"\r\n      [showClear]=\"showClear()\"\r\n      [filter]=\"filter()\"\r\n      [invalid]=\"invalid()\"\r\n      [fluid]=\"fluid()\"\r\n      (onHide)=\"onTouched()\"\r\n      class=\"sk-dropdown__field\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-dropdown__help sk-dropdown__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-dropdown__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-dropdown{display:flex;flex-direction:column;gap:4px}.sk-dropdown__floatlabel,.sk-dropdown--fluid,.sk-dropdown--fluid .sk-dropdown__floatlabel,.sk-dropdown--fluid .sk-dropdown__field{width:100%}::ng-deep .sk-dropdown__field.p-select{width:100%;min-height:var(--size-048, 48px);padding-inline:12px;border-radius:var(--bordes-s, 4px)}::ng-deep .sk-dropdown__field.p-select .p-select-dropdown{padding:0!important;width:auto!important}::ng-deep .sk-dropdown__field.p-select .p-select-label{padding-block-start:20px;padding-block-end:6px;padding-inline:0!important;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);color:var(--texts-dark, #404040)}::ng-deep .sk-dropdown__floatlabel label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;color:var(--texts-medium, #666666)}::ng-deep .sk-dropdown--invalid .sk-dropdown__field.p-select{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-dropdown--disabled .sk-dropdown__field.p-select{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;cursor:not-allowed}.sk-dropdown__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, .75rem);font-weight:var(--caption-body-3-weight, 500);line-height:var(--caption-body-3-line-height, 1.25rem);color:var(--texts-medium, #666666);padding:0 4px}.sk-dropdown__help--error{color:var(--color-error, #e03430)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], helpText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helpText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkFieldsetComponent {
    legend = input('', ...(ngDevMode ? [{ debugName: "legend" }] : /* istanbul ignore next */ []));
    content = input('', ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    toggleable = input(false, { ...(ngDevMode ? { debugName: "toggleable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    collapsed = input(false, { ...(ngDevMode ? { debugName: "collapsed" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    beforeToggle = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkFieldsetComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkFieldsetComponent, isStandalone: true, selector: "sk-fieldset", inputs: { legend: { classPropertyName: "legend", publicName: "legend", isSignal: true, isRequired: false, transformFunction: null }, content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: false, transformFunction: null }, toggleable: { classPropertyName: "toggleable", publicName: "toggleable", isSignal: true, isRequired: false, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { beforeToggle: "beforeToggle" }, ngImport: i0, template: `
    <p-fieldset
      styleClass="sk-fieldset"
      [legend]="legend()"
      [toggleable]="toggleable()"
      [collapsed]="collapsed()"
      (onBeforeToggle)="beforeToggle.emit($event)"
    >
      @if (content()) {
        <p class="sk-fieldset__text">{{ content() }}</p>
      }
      <ng-content />
    </p-fieldset>
  `, isInline: true, styles: [":host{display:block}:host ::ng-deep .sk-fieldset.p-fieldset{border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);padding:0 16px 14px}:host ::ng-deep .sk-fieldset .p-fieldset-legend{background:var(--background-white, #fff);border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:999px;padding:4px 14px;margin-left:8px}:host ::ng-deep .sk-fieldset .p-fieldset-legend-label{font-size:12px;font-weight:700;color:var(--color-primary, #00c73d);letter-spacing:.04em;text-transform:uppercase}:host ::ng-deep .sk-fieldset .p-fieldset-toggle-button{color:var(--color-primary, #00c73d);width:20px;height:20px}:host ::ng-deep .sk-fieldset .p-fieldset-content{padding:12px 0 0}.sk-fieldset__text{margin:0;font-size:14px;color:var(--texts-medium, #666);line-height:1.6}\n"], dependencies: [{ kind: "component", type: Fieldset, selector: "p-fieldset", inputs: ["legend", "toggleable", "style", "styleClass", "transitionOptions", "motionOptions", "collapsed"], outputs: ["collapsedChange", "onBeforeToggle", "onAfterToggle"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkFieldsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-fieldset', standalone: true, imports: [Fieldset], template: `
    <p-fieldset
      styleClass="sk-fieldset"
      [legend]="legend()"
      [toggleable]="toggleable()"
      [collapsed]="collapsed()"
      (onBeforeToggle)="beforeToggle.emit($event)"
    >
      @if (content()) {
        <p class="sk-fieldset__text">{{ content() }}</p>
      }
      <ng-content />
    </p-fieldset>
  `, styles: [":host{display:block}:host ::ng-deep .sk-fieldset.p-fieldset{border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);padding:0 16px 14px}:host ::ng-deep .sk-fieldset .p-fieldset-legend{background:var(--background-white, #fff);border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:999px;padding:4px 14px;margin-left:8px}:host ::ng-deep .sk-fieldset .p-fieldset-legend-label{font-size:12px;font-weight:700;color:var(--color-primary, #00c73d);letter-spacing:.04em;text-transform:uppercase}:host ::ng-deep .sk-fieldset .p-fieldset-toggle-button{color:var(--color-primary, #00c73d);width:20px;height:20px}:host ::ng-deep .sk-fieldset .p-fieldset-content{padding:12px 0 0}.sk-fieldset__text{margin:0;font-size:14px;color:var(--texts-medium, #666);line-height:1.6}\n"] }]
        }], propDecorators: { legend: [{ type: i0.Input, args: [{ isSignal: true, alias: "legend", required: false }] }], content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: false }] }], toggleable: [{ type: i0.Input, args: [{ isSignal: true, alias: "toggleable", required: false }] }], collapsed: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsed", required: false }] }], beforeToggle: [{ type: i0.Output, args: ["beforeToggle"] }] } });

class SkFileUploadComponent {
    name = input('file', ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    url = input('', ...(ngDevMode ? [{ debugName: "url" }] : /* istanbul ignore next */ []));
    multiple = input(false, ...(ngDevMode ? [{ debugName: "multiple" }] : /* istanbul ignore next */ []));
    accept = input('image/*', ...(ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ []));
    maxFileSize = input(5000000, ...(ngDevMode ? [{ debugName: "maxFileSize" }] : /* istanbul ignore next */ []));
    mode = input('basic', ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    auto = input(false, ...(ngDevMode ? [{ debugName: "auto" }] : /* istanbul ignore next */ []));
    chooseLabel = input('Seleccionar archivo', ...(ngDevMode ? [{ debugName: "chooseLabel" }] : /* istanbul ignore next */ []));
    selected = output();
    uploaded = output();
    error = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkFileUploadComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkFileUploadComponent, isStandalone: true, selector: "sk-fileupload", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, url: { classPropertyName: "url", publicName: "url", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, accept: { classPropertyName: "accept", publicName: "accept", isSignal: true, isRequired: false, transformFunction: null }, maxFileSize: { classPropertyName: "maxFileSize", publicName: "maxFileSize", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, auto: { classPropertyName: "auto", publicName: "auto", isSignal: true, isRequired: false, transformFunction: null }, chooseLabel: { classPropertyName: "chooseLabel", publicName: "chooseLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selected: "selected", uploaded: "uploaded", error: "error" }, ngImport: i0, template: `
    <p-fileupload
      [name]="name()"
      [url]="url()"
      [multiple]="multiple()"
      [accept]="accept()"
      [maxFileSize]="maxFileSize()"
      [mode]="mode()"
      [auto]="auto()"
      [chooseLabel]="chooseLabel()"
      (onSelect)="selected.emit($event)"
      (onUpload)="uploaded.emit($event)"
      (onError)="error.emit($event)"
    />
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: FileUpload, selector: "p-fileupload, p-fileUpload", inputs: ["name", "url", "method", "multiple", "accept", "disabled", "auto", "withCredentials", "maxFileSize", "invalidFileSizeMessageSummary", "invalidFileSizeMessageDetail", "invalidFileTypeMessageSummary", "invalidFileTypeMessageDetail", "invalidFileLimitMessageDetail", "invalidFileLimitMessageSummary", "style", "styleClass", "previewWidth", "chooseLabel", "uploadLabel", "cancelLabel", "chooseIcon", "uploadIcon", "cancelIcon", "showUploadButton", "showCancelButton", "mode", "headers", "customUpload", "fileLimit", "uploadStyleClass", "cancelStyleClass", "removeStyleClass", "chooseStyleClass", "chooseButtonProps", "uploadButtonProps", "cancelButtonProps", "files"], outputs: ["onBeforeUpload", "onSend", "onUpload", "onError", "onClear", "onRemove", "onSelect", "onProgress", "uploadHandler", "onImageError", "onRemoveUploadedFile"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkFileUploadComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-fileupload', standalone: true, imports: [FileUpload], template: `
    <p-fileupload
      [name]="name()"
      [url]="url()"
      [multiple]="multiple()"
      [accept]="accept()"
      [maxFileSize]="maxFileSize()"
      [mode]="mode()"
      [auto]="auto()"
      [chooseLabel]="chooseLabel()"
      (onSelect)="selected.emit($event)"
      (onUpload)="uploaded.emit($event)"
      (onError)="error.emit($event)"
    />
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], url: [{ type: i0.Input, args: [{ isSignal: true, alias: "url", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], accept: [{ type: i0.Input, args: [{ isSignal: true, alias: "accept", required: false }] }], maxFileSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxFileSize", required: false }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], auto: [{ type: i0.Input, args: [{ isSignal: true, alias: "auto", required: false }] }], chooseLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "chooseLabel", required: false }] }], selected: [{ type: i0.Output, args: ["selected"] }], uploaded: [{ type: i0.Output, args: ["uploaded"] }], error: [{ type: i0.Output, args: ["error"] }] } });

class SkGalleriaComponent {
    images = input([
        { label: 'Imagen 1', short: 'Img 1', color: 'var(--accent-1)' },
        { label: 'Imagen 2', short: 'Img 2', color: 'var(--accent-2)' },
        { label: 'Imagen 3', short: 'Img 3', color: 'var(--accent-4)' },
        { label: 'Imagen 4', short: 'Img 4', color: 'var(--accent-5)' },
        { label: 'Imagen 5', short: 'Img 5', color: 'var(--accent-6)' },
    ], ...(ngDevMode ? [{ debugName: "images" }] : /* istanbul ignore next */ []));
    numVisible = input(5, ...(ngDevMode ? [{ debugName: "numVisible" }] : /* istanbul ignore next */ []));
    showThumbnails = input(true, ...(ngDevMode ? [{ debugName: "showThumbnails" }] : /* istanbul ignore next */ []));
    showIndicators = input(false, ...(ngDevMode ? [{ debugName: "showIndicators" }] : /* istanbul ignore next */ []));
    circular = input(true, ...(ngDevMode ? [{ debugName: "circular" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkGalleriaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkGalleriaComponent, isStandalone: true, selector: "sk-galleria", inputs: { images: { classPropertyName: "images", publicName: "images", isSignal: true, isRequired: false, transformFunction: null }, numVisible: { classPropertyName: "numVisible", publicName: "numVisible", isSignal: true, isRequired: false, transformFunction: null }, showThumbnails: { classPropertyName: "showThumbnails", publicName: "showThumbnails", isSignal: true, isRequired: false, transformFunction: null }, showIndicators: { classPropertyName: "showIndicators", publicName: "showIndicators", isSignal: true, isRequired: false, transformFunction: null }, circular: { classPropertyName: "circular", publicName: "circular", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-galleria [value]="images()" [numVisible]="numVisible()" [showThumbnails]="showThumbnails()" [showIndicators]="showIndicators()" [circular]="circular()" [style]="{ maxWidth: '640px' }">
      <ng-template #item let-item>
        <div [style]="{ background: item.color, width: '100%', height: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 'var(--radius-md, 8px)' }">
          <span style="color:var(--color-white,#fff);font-size:18px;font-weight:600;">{{ item.label }}</span>
        </div>
      </ng-template>
      <ng-template #thumbnail let-item>
        <div [style]="{ background: item.color, width: '60px', height: '40px', borderRadius: 'var(--radius-sm, 4px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }">
          <span style="color:var(--color-white,#fff);font-size:10px;font-weight:600;">{{ item.short }}</span>
        </div>
      </ng-template>
    </p-galleria>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: GalleriaModule }, { kind: "component", type: i1$1.Galleria, selector: "p-galleria", inputs: ["activeIndex", "fullScreen", "id", "value", "numVisible", "responsiveOptions", "showItemNavigators", "showThumbnailNavigators", "showItemNavigatorsOnHover", "changeItemOnIndicatorHover", "circular", "autoPlay", "shouldStopAutoplayByClick", "transitionInterval", "showThumbnails", "thumbnailsPosition", "verticalThumbnailViewPortHeight", "showIndicators", "showIndicatorsOnItem", "indicatorsPosition", "baseZIndex", "maskClass", "containerClass", "containerStyle", "showTransitionOptions", "hideTransitionOptions", "motionOptions", "maskMotionOptions", "visible"], outputs: ["activeIndexChange", "visibleChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkGalleriaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-galleria', standalone: true, imports: [GalleriaModule], template: `
    <p-galleria [value]="images()" [numVisible]="numVisible()" [showThumbnails]="showThumbnails()" [showIndicators]="showIndicators()" [circular]="circular()" [style]="{ maxWidth: '640px' }">
      <ng-template #item let-item>
        <div [style]="{ background: item.color, width: '100%', height: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 'var(--radius-md, 8px)' }">
          <span style="color:var(--color-white,#fff);font-size:18px;font-weight:600;">{{ item.label }}</span>
        </div>
      </ng-template>
      <ng-template #thumbnail let-item>
        <div [style]="{ background: item.color, width: '60px', height: '40px', borderRadius: 'var(--radius-sm, 4px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }">
          <span style="color:var(--color-white,#fff);font-size:10px;font-weight:600;">{{ item.short }}</span>
        </div>
      </ng-template>
    </p-galleria>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { images: [{ type: i0.Input, args: [{ isSignal: true, alias: "images", required: false }] }], numVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "numVisible", required: false }] }], showThumbnails: [{ type: i0.Input, args: [{ isSignal: true, alias: "showThumbnails", required: false }] }], showIndicators: [{ type: i0.Input, args: [{ isSignal: true, alias: "showIndicators", required: false }] }], circular: [{ type: i0.Input, args: [{ isSignal: true, alias: "circular", required: false }] }] } });

class SkImageComponent {
    src = input('https://placehold.co/320x200/22c55e/ffffff?text=sk-image', ...(ngDevMode ? [{ debugName: "src" }] : /* istanbul ignore next */ []));
    alt = input('Imagen de ejemplo', ...(ngDevMode ? [{ debugName: "alt" }] : /* istanbul ignore next */ []));
    width = input('320', ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    preview = input(true, ...(ngDevMode ? [{ debugName: "preview" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkImageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkImageComponent, isStandalone: true, selector: "sk-image", inputs: { src: { classPropertyName: "src", publicName: "src", isSignal: true, isRequired: false, transformFunction: null }, alt: { classPropertyName: "alt", publicName: "alt", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, preview: { classPropertyName: "preview", publicName: "preview", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-image
      [src]="src()"
      [alt]="alt()"
      [width]="width()"
      [preview]="preview()"
      [imageStyle]="{ borderRadius: '8px', objectFit: 'cover' }"
    />
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Image, selector: "p-image", inputs: ["imageClass", "imageStyle", "styleClass", "src", "srcSet", "sizes", "previewImageSrc", "previewImageSrcSet", "previewImageSizes", "alt", "width", "height", "loading", "preview", "showTransitionOptions", "hideTransitionOptions", "modalEnterAnimation", "modalLeaveAnimation", "appendTo", "maskMotionOptions", "motionOptions"], outputs: ["onShow", "onHide", "onImageError"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkImageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-image', standalone: true, imports: [Image], template: `
    <p-image
      [src]="src()"
      [alt]="alt()"
      [width]="width()"
      [preview]="preview()"
      [imageStyle]="{ borderRadius: '8px', objectFit: 'cover' }"
    />
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { src: [{ type: i0.Input, args: [{ isSignal: true, alias: "src", required: false }] }], alt: [{ type: i0.Input, args: [{ isSignal: true, alias: "alt", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], preview: [{ type: i0.Input, args: [{ isSignal: true, alias: "preview", required: false }] }] } });

class SkImageCompareComponent {
    leftSrc = input('https://placehold.co/500x300/22c55e/ffffff?text=Antes', ...(ngDevMode ? [{ debugName: "leftSrc" }] : /* istanbul ignore next */ []));
    rightSrc = input('https://placehold.co/500x300/16a34a/ffffff?text=Despues', ...(ngDevMode ? [{ debugName: "rightSrc" }] : /* istanbul ignore next */ []));
    leftAlt = input('Antes', ...(ngDevMode ? [{ debugName: "leftAlt" }] : /* istanbul ignore next */ []));
    rightAlt = input('Después', ...(ngDevMode ? [{ debugName: "rightAlt" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkImageCompareComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkImageCompareComponent, isStandalone: true, selector: "sk-imagecompare", inputs: { leftSrc: { classPropertyName: "leftSrc", publicName: "leftSrc", isSignal: true, isRequired: false, transformFunction: null }, rightSrc: { classPropertyName: "rightSrc", publicName: "rightSrc", isSignal: true, isRequired: false, transformFunction: null }, leftAlt: { classPropertyName: "leftAlt", publicName: "leftAlt", isSignal: true, isRequired: false, transformFunction: null }, rightAlt: { classPropertyName: "rightAlt", publicName: "rightAlt", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-imagecompare>
      <ng-template #left>
        <img [src]="leftSrc()" [alt]="leftAlt()" style="width:100%;display:block;border-radius:8px 0 0 8px;" />
      </ng-template>
      <ng-template #right>
        <img [src]="rightSrc()" [alt]="rightAlt()" style="width:100%;display:block;border-radius:0 8px 8px 0;" />
      </ng-template>
    </p-imagecompare>
  `, isInline: true, styles: [":host{display:block;max-width:500px}\n"], dependencies: [{ kind: "component", type: ImageCompare, selector: "p-imageCompare, p-imagecompare, p-image-compare", inputs: ["tabindex", "ariaLabelledby", "ariaLabel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkImageCompareComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-imagecompare', standalone: true, imports: [ImageCompare], template: `
    <p-imagecompare>
      <ng-template #left>
        <img [src]="leftSrc()" [alt]="leftAlt()" style="width:100%;display:block;border-radius:8px 0 0 8px;" />
      </ng-template>
      <ng-template #right>
        <img [src]="rightSrc()" [alt]="rightAlt()" style="width:100%;display:block;border-radius:0 8px 8px 0;" />
      </ng-template>
    </p-imagecompare>
  `, styles: [":host{display:block;max-width:500px}\n"] }]
        }], propDecorators: { leftSrc: [{ type: i0.Input, args: [{ isSignal: true, alias: "leftSrc", required: false }] }], rightSrc: [{ type: i0.Input, args: [{ isSignal: true, alias: "rightSrc", required: false }] }], leftAlt: [{ type: i0.Input, args: [{ isSignal: true, alias: "leftAlt", required: false }] }], rightAlt: [{ type: i0.Input, args: [{ isSignal: true, alias: "rightAlt", required: false }] }] } });

class SkInplaceComponent {
    display = input('Haz clic para ver el contenido', ...(ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []));
    content = input('Este es el contenido inline revelado tras hacer clic en el display.', ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    closable = input(true, ...(ngDevMode ? [{ debugName: "closable" }] : /* istanbul ignore next */ []));
    active = false;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkInplaceComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkInplaceComponent, isStandalone: true, selector: "sk-inplace", inputs: { display: { classPropertyName: "display", publicName: "display", isSignal: true, isRequired: false, transformFunction: null }, content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: false, transformFunction: null }, closable: { classPropertyName: "closable", publicName: "closable", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-inplace [active]="active" [closable]="closable()" (onActivate)="active = true" (onDeactivate)="active = false">
      <ng-template #displayTpl>
        <span style="font-size:14px;color:var(--p-primary-color,#22c55e);cursor:pointer;text-decoration:underline;text-underline-offset:2px;">
          <i class="pi pi-pencil" style="margin-right:6px;font-size:13px;"></i>{{ display() }}
        </span>
      </ng-template>
      <ng-template #contentTpl>
        <span style="font-size:14px;color:var(--p-surface-700,#374151);">{{ content() }}</span>
      </ng-template>
    </p-inplace>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Inplace, selector: "p-inplace", inputs: ["active", "closable", "disabled", "preventClick", "styleClass", "closeIcon", "closeAriaLabel"], outputs: ["onActivate", "onDeactivate"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkInplaceComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-inplace', standalone: true, imports: [Inplace], template: `
    <p-inplace [active]="active" [closable]="closable()" (onActivate)="active = true" (onDeactivate)="active = false">
      <ng-template #displayTpl>
        <span style="font-size:14px;color:var(--p-primary-color,#22c55e);cursor:pointer;text-decoration:underline;text-underline-offset:2px;">
          <i class="pi pi-pencil" style="margin-right:6px;font-size:13px;"></i>{{ display() }}
        </span>
      </ng-template>
      <ng-template #contentTpl>
        <span style="font-size:14px;color:var(--p-surface-700,#374151);">{{ content() }}</span>
      </ng-template>
    </p-inplace>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { display: [{ type: i0.Input, args: [{ isSignal: true, alias: "display", required: false }] }], content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: false }] }], closable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closable", required: false }] }] } });

let _inputUid = 0;
class SkInputComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    type = input('text', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    helpText = input('', ...(ngDevMode ? [{ debugName: "helpText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    iconLeft = input('', ...(ngDevMode ? [{ debugName: "iconLeft" }] : /* istanbul ignore next */ []));
    iconRight = input('', ...(ngDevMode ? [{ debugName: "iconRight" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    inputId = `sk-input-${_inputUid++}`;
    _value = signal('', ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    normalizedIconLeft = computed(() => this.normalizeIcon(this.iconLeft()), ...(ngDevMode ? [{ debugName: "normalizedIconLeft" }] : /* istanbul ignore next */ []));
    normalizedIconRight = computed(() => this.normalizeIcon(this.iconRight()), ...(ngDevMode ? [{ debugName: "normalizedIconRight" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    _onTouched = () => { };
    handleInput(val) {
        const v = val ?? '';
        this._value.set(v);
        this._onChange(v);
        this.valueChange.emit(v);
    }
    handleBlur() { this._onTouched(); }
    writeValue(val) { this._value.set(val ?? ''); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this._onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    normalizeIcon(icon) {
        if (!icon?.trim())
            return '';
        const n = icon.trim();
        if (n.startsWith('pi '))
            return n;
        if (n.startsWith('pi-'))
            return `pi ${n}`;
        return `pi pi-${n}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkInputComponent, isStandalone: true, selector: "sk-input", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, iconLeft: { classPropertyName: "iconLeft", publicName: "iconLeft", isSignal: true, isRequired: false, transformFunction: null }, iconRight: { classPropertyName: "iconRight", publicName: "iconRight", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SkInputComponent),
                multi: true,
            },
        ], ngImport: i0, template: "<div\r\n  class=\"sk-input\"\r\n  [class.sk-input--fluid]=\"fluid()\"\r\n  [class.sk-input--invalid]=\"invalid()\"\r\n  [class.sk-input--disabled]=\"_isDisabled()\"\r\n>\r\n  <div class=\"sk-input__box\">\r\n    <p-floatlabel variant=\"in\">\r\n      <p-iconfield>\r\n        @if (normalizedIconLeft()) {\r\n          <p-inputicon>\r\n            <i [class]=\"normalizedIconLeft()\" aria-hidden=\"true\"></i>\r\n          </p-inputicon>\r\n        }\r\n        <input\r\n          pInputText\r\n          [id]=\"inputId\"\r\n          [type]=\"type()\"\r\n          [ngModel]=\"_value()\"\r\n          (ngModelChange)=\"handleInput($event)\"\r\n          [disabled]=\"_isDisabled()\"\r\n          [invalid]=\"invalid()\"\r\n          [attr.placeholder]=\"placeholder() || null\"\r\n          (blur)=\"handleBlur()\"\r\n          class=\"sk-input__field\"\r\n        />\r\n        @if (normalizedIconRight()) {\r\n          <p-inputicon>\r\n            <i [class]=\"normalizedIconRight()\" aria-hidden=\"true\"></i>\r\n          </p-inputicon>\r\n        }\r\n      </p-iconfield>\r\n      <label [for]=\"inputId\">{{ label() }}</label>\r\n    </p-floatlabel>\r\n  </div>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-input__help sk-input__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-input__help\" [class.sk-input__help--error]=\"invalid()\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-input{display:flex;flex-direction:column;gap:4px}.sk-input--fluid{width:100%}.sk-input__box{border:1px solid var(--stroke-grey-light, #dddddd);border-radius:var(--bordes-s, 8px);background:var(--background-principal, #ffffff);width:100%;min-height:var(--size-048, 48px);transition:border-color .15s ease}::ng-deep .sk-input__box p-floatlabel,::ng-deep .sk-input__box .p-floatlabel{display:block!important;width:100%!important;border:none!important;background:transparent!important;box-shadow:none!important}::ng-deep .sk-input__box .p-iconfield{width:100%}.sk-input__field{width:100%;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline:12px;border:none!important;background:transparent!important;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);color:var(--texts-dark, #404040);box-sizing:border-box;box-shadow:none!important;outline:none}::ng-deep .sk-input__box label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;color:var(--texts-medium, #666666)}.sk-input:not(.sk-input--disabled):not(.sk-input--invalid):focus-within .sk-input__box{border-color:var(--stroke-brand, #00c73d)}.sk-input--invalid .sk-input__box{border-color:var(--color-error, #e03430)}.sk-input--disabled .sk-input__box{background:var(--background-grey-light, #f7f7f7);border-color:var(--stroke-grey-light, #dddddd)}.sk-input--disabled .sk-input__field{color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-input__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-input__help--error{color:var(--color-error, #e03430)}\n"], dependencies: [{ kind: "directive", type: InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "component", type: IconField, selector: "p-iconfield, p-iconField, p-icon-field", inputs: ["hostName", "iconPosition", "styleClass"] }, { kind: "component", type: InputIcon, selector: "p-inputicon, p-inputIcon", inputs: ["hostName", "styleClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-input', standalone: true, imports: [InputText, FloatLabel, IconField, InputIcon, FormsModule], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SkInputComponent),
                            multi: true,
                        },
                    ], template: "<div\r\n  class=\"sk-input\"\r\n  [class.sk-input--fluid]=\"fluid()\"\r\n  [class.sk-input--invalid]=\"invalid()\"\r\n  [class.sk-input--disabled]=\"_isDisabled()\"\r\n>\r\n  <div class=\"sk-input__box\">\r\n    <p-floatlabel variant=\"in\">\r\n      <p-iconfield>\r\n        @if (normalizedIconLeft()) {\r\n          <p-inputicon>\r\n            <i [class]=\"normalizedIconLeft()\" aria-hidden=\"true\"></i>\r\n          </p-inputicon>\r\n        }\r\n        <input\r\n          pInputText\r\n          [id]=\"inputId\"\r\n          [type]=\"type()\"\r\n          [ngModel]=\"_value()\"\r\n          (ngModelChange)=\"handleInput($event)\"\r\n          [disabled]=\"_isDisabled()\"\r\n          [invalid]=\"invalid()\"\r\n          [attr.placeholder]=\"placeholder() || null\"\r\n          (blur)=\"handleBlur()\"\r\n          class=\"sk-input__field\"\r\n        />\r\n        @if (normalizedIconRight()) {\r\n          <p-inputicon>\r\n            <i [class]=\"normalizedIconRight()\" aria-hidden=\"true\"></i>\r\n          </p-inputicon>\r\n        }\r\n      </p-iconfield>\r\n      <label [for]=\"inputId\">{{ label() }}</label>\r\n    </p-floatlabel>\r\n  </div>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-input__help sk-input__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-input__help\" [class.sk-input__help--error]=\"invalid()\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-input{display:flex;flex-direction:column;gap:4px}.sk-input--fluid{width:100%}.sk-input__box{border:1px solid var(--stroke-grey-light, #dddddd);border-radius:var(--bordes-s, 8px);background:var(--background-principal, #ffffff);width:100%;min-height:var(--size-048, 48px);transition:border-color .15s ease}::ng-deep .sk-input__box p-floatlabel,::ng-deep .sk-input__box .p-floatlabel{display:block!important;width:100%!important;border:none!important;background:transparent!important;box-shadow:none!important}::ng-deep .sk-input__box .p-iconfield{width:100%}.sk-input__field{width:100%;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline:12px;border:none!important;background:transparent!important;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);color:var(--texts-dark, #404040);box-sizing:border-box;box-shadow:none!important;outline:none}::ng-deep .sk-input__box label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;color:var(--texts-medium, #666666)}.sk-input:not(.sk-input--disabled):not(.sk-input--invalid):focus-within .sk-input__box{border-color:var(--stroke-brand, #00c73d)}.sk-input--invalid .sk-input__box{border-color:var(--color-error, #e03430)}.sk-input--disabled .sk-input__box{background:var(--background-grey-light, #f7f7f7);border-color:var(--stroke-grey-light, #dddddd)}.sk-input--disabled .sk-input__field{color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-input__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-input__help--error{color:var(--color-error, #e03430)}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], helpText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helpText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], iconLeft: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconLeft", required: false }] }], iconRight: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconRight", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

let _inputmaskUid = 0;
class SkInputMaskComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    mask = input('(999) 999-9999', ...(ngDevMode ? [{ debugName: "mask" }] : /* istanbul ignore next */ []));
    slotChar = input('_', ...(ngDevMode ? [{ debugName: "slotChar" }] : /* istanbul ignore next */ []));
    helpText = input('', ...(ngDevMode ? [{ debugName: "helpText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    completed = output();
    inputId = `sk-inputmask-${_inputmaskUid++}`;
    _value = signal('', ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    _onTouched = () => { };
    handleInput(val) {
        const v = val ?? '';
        this._value.set(v);
        this._onChange(v);
    }
    handleBlur() { this._onTouched(); }
    writeValue(val) { this._value.set(val ?? ''); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this._onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkInputMaskComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkInputMaskComponent, isStandalone: true, selector: "sk-inputmask", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, mask: { classPropertyName: "mask", publicName: "mask", isSignal: true, isRequired: false, transformFunction: null }, slotChar: { classPropertyName: "slotChar", publicName: "slotChar", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { completed: "completed" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkInputMaskComponent), multi: true }], ngImport: i0, template: "<div\r\n  class=\"sk-inputmask\"\r\n  [class.sk-inputmask--fluid]=\"fluid()\"\r\n  [class.sk-inputmask--invalid]=\"invalid()\"\r\n  [class.sk-inputmask--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-inputmask__floatlabel\">\r\n    <p-inputmask\r\n      [inputId]=\"inputId\"\r\n      [ngModel]=\"_value()\"\r\n      (ngModelChange)=\"handleInput($event)\"\r\n      [mask]=\"mask()\"\r\n      [slotChar]=\"slotChar()\"\r\n      [disabled]=\"_isDisabled()\"\r\n      [invalid]=\"invalid()\"\r\n      [fluid]=\"fluid()\"\r\n      (onBlur)=\"handleBlur()\"\r\n      (onComplete)=\"completed.emit($event)\"\r\n      class=\"sk-inputmask__field\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-inputmask__help sk-inputmask__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-inputmask__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-inputmask{display:flex;flex-direction:column;gap:4px}.sk-inputmask--fluid,.sk-inputmask--fluid .sk-inputmask__floatlabel,.sk-inputmask--fluid .sk-inputmask__field{width:100%}::ng-deep .sk-inputmask__field input{width:100%;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline:12px;border-radius:var(--bordes-s, 4px);border:1px solid var(--stroke-grey-light, #dddddd);background:var(--background-principal, #ffffff);font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-dark, #404040);box-sizing:border-box;box-shadow:none;outline:none;transition:border-color .15s ease}::ng-deep .sk-inputmask__floatlabel label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;color:var(--texts-medium, #666666)}.sk-inputmask:not(.sk-inputmask--disabled):not(.sk-inputmask--invalid):hover ::ng-deep .sk-inputmask__field input{border-color:var(--stroke-grey-medium, #c5c5c5)}.sk-inputmask:not(.sk-inputmask--disabled):not(.sk-inputmask--invalid):focus-within ::ng-deep .sk-inputmask__field input{border-color:var(--stroke-brand, #00c73d)}::ng-deep .sk-inputmask--invalid .sk-inputmask__field input{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-inputmask--disabled .sk-inputmask__field input{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-inputmask__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-inputmask__help--error{color:var(--color-error, #e03430)}\n"], dependencies: [{ kind: "component", type: InputMask, selector: "p-inputmask, p-inputMask, p-input-mask", inputs: ["type", "slotChar", "autoClear", "showClear", "style", "inputId", "styleClass", "placeholder", "tabindex", "title", "ariaLabel", "ariaLabelledBy", "ariaRequired", "readonly", "unmask", "characterPattern", "autofocus", "autocomplete", "keepBuffer", "mask"], outputs: ["onComplete", "onFocus", "onBlur", "onInput", "onKeydown", "onClear"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkInputMaskComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-inputmask', standalone: true, imports: [InputMask, FloatLabel, FormsModule], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkInputMaskComponent), multi: true }], template: "<div\r\n  class=\"sk-inputmask\"\r\n  [class.sk-inputmask--fluid]=\"fluid()\"\r\n  [class.sk-inputmask--invalid]=\"invalid()\"\r\n  [class.sk-inputmask--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-inputmask__floatlabel\">\r\n    <p-inputmask\r\n      [inputId]=\"inputId\"\r\n      [ngModel]=\"_value()\"\r\n      (ngModelChange)=\"handleInput($event)\"\r\n      [mask]=\"mask()\"\r\n      [slotChar]=\"slotChar()\"\r\n      [disabled]=\"_isDisabled()\"\r\n      [invalid]=\"invalid()\"\r\n      [fluid]=\"fluid()\"\r\n      (onBlur)=\"handleBlur()\"\r\n      (onComplete)=\"completed.emit($event)\"\r\n      class=\"sk-inputmask__field\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-inputmask__help sk-inputmask__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-inputmask__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-inputmask{display:flex;flex-direction:column;gap:4px}.sk-inputmask--fluid,.sk-inputmask--fluid .sk-inputmask__floatlabel,.sk-inputmask--fluid .sk-inputmask__field{width:100%}::ng-deep .sk-inputmask__field input{width:100%;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline:12px;border-radius:var(--bordes-s, 4px);border:1px solid var(--stroke-grey-light, #dddddd);background:var(--background-principal, #ffffff);font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-dark, #404040);box-sizing:border-box;box-shadow:none;outline:none;transition:border-color .15s ease}::ng-deep .sk-inputmask__floatlabel label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;color:var(--texts-medium, #666666)}.sk-inputmask:not(.sk-inputmask--disabled):not(.sk-inputmask--invalid):hover ::ng-deep .sk-inputmask__field input{border-color:var(--stroke-grey-medium, #c5c5c5)}.sk-inputmask:not(.sk-inputmask--disabled):not(.sk-inputmask--invalid):focus-within ::ng-deep .sk-inputmask__field input{border-color:var(--stroke-brand, #00c73d)}::ng-deep .sk-inputmask--invalid .sk-inputmask__field input{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-inputmask--disabled .sk-inputmask__field input{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-inputmask__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-inputmask__help--error{color:var(--color-error, #e03430)}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], mask: [{ type: i0.Input, args: [{ isSignal: true, alias: "mask", required: false }] }], slotChar: [{ type: i0.Input, args: [{ isSignal: true, alias: "slotChar", required: false }] }], helpText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helpText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], completed: [{ type: i0.Output, args: ["completed"] }] } });

let _inputnumberUid = 0;
class SkInputNumberComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    min = input(0, ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    max = input(100, ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    step = input(1, ...(ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []));
    prefix = input('', ...(ngDevMode ? [{ debugName: "prefix" }] : /* istanbul ignore next */ []));
    suffix = input('', ...(ngDevMode ? [{ debugName: "suffix" }] : /* istanbul ignore next */ []));
    helpText = input('', ...(ngDevMode ? [{ debugName: "helpText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    showButtons = input(false, { ...(ngDevMode ? { debugName: "showButtons" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    mode = input('decimal', ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    inputId = `sk-inputnumber-${_inputnumberUid++}`;
    _value = signal(null, ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    _onTouched = () => { };
    handleInput(val) {
        this._value.set(val);
        this._onChange(val);
        this.valueChange.emit(val);
    }
    handleBlur() { this._onTouched(); }
    writeValue(val) { this._value.set(val ?? null); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this._onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkInputNumberComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkInputNumberComponent, isStandalone: true, selector: "sk-inputnumber", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, prefix: { classPropertyName: "prefix", publicName: "prefix", isSignal: true, isRequired: false, transformFunction: null }, suffix: { classPropertyName: "suffix", publicName: "suffix", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, showButtons: { classPropertyName: "showButtons", publicName: "showButtons", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkInputNumberComponent), multi: true }], ngImport: i0, template: "<div\r\n  class=\"sk-inputnumber\"\r\n  [class.sk-inputnumber--fluid]=\"fluid()\"\r\n  [class.sk-inputnumber--invalid]=\"invalid()\"\r\n  [class.sk-inputnumber--disabled]=\"_isDisabled()\"\r\n>\r\n  <div class=\"sk-inputnumber__box\">\r\n    <p-floatlabel variant=\"in\">\r\n      <p-inputnumber\r\n        [inputId]=\"inputId\"\r\n        [ngModel]=\"_value()\"\r\n        (ngModelChange)=\"handleInput($event)\"\r\n        [min]=\"min()\"\r\n        [max]=\"max()\"\r\n        [step]=\"step()\"\r\n        [prefix]=\"prefix()\"\r\n        [suffix]=\"suffix()\"\r\n        [showButtons]=\"showButtons()\"\r\n        [mode]=\"mode()\"\r\n        [disabled]=\"_isDisabled()\"\r\n        [invalid]=\"invalid()\"\r\n        [fluid]=\"true\"\r\n        (onBlur)=\"handleBlur()\"\r\n        class=\"sk-inputnumber__field\"\r\n      />\r\n      <label [for]=\"inputId\">{{ label() }}</label>\r\n    </p-floatlabel>\r\n  </div>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-inputnumber__help sk-inputnumber__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-inputnumber__help\" [class.sk-inputnumber__help--error]=\"invalid()\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-inputnumber{display:flex;flex-direction:column;gap:4px;width:100%}.sk-inputnumber__box{border:1px solid var(--stroke-grey-light, #dddddd);border-radius:var(--bordes-s, 8px);background:var(--background-principal, #ffffff);width:100%;min-height:var(--size-048, 48px);transition:border-color .15s ease}::ng-deep .sk-inputnumber__box p-floatlabel,::ng-deep .sk-inputnumber__box .p-floatlabel{display:block!important;width:100%!important;border:none!important;background:transparent!important;box-shadow:none!important}::ng-deep .sk-inputnumber__box .p-inputnumber{width:100%}::ng-deep .sk-inputnumber__box .p-inputnumber-input{width:100%;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline:12px;border:none!important;background:transparent!important;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-dark, #404040);box-sizing:border-box;box-shadow:none!important;outline:none}::ng-deep .sk-inputnumber__box label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;color:var(--texts-medium, #666666)}.sk-inputnumber:not(.sk-inputnumber--disabled):not(.sk-inputnumber--invalid):hover .sk-inputnumber__box{border-color:var(--stroke-grey-medium, #c5c5c5)}.sk-inputnumber:not(.sk-inputnumber--disabled):not(.sk-inputnumber--invalid):focus-within .sk-inputnumber__box{border-color:var(--stroke-brand, #00c73d)}.sk-inputnumber--invalid .sk-inputnumber__box{border-color:var(--color-error, #e03430)}.sk-inputnumber--disabled .sk-inputnumber__box{background:var(--background-grey-light, #f7f7f7);border-color:var(--stroke-grey-light, #dddddd)}::ng-deep .sk-inputnumber--disabled .sk-inputnumber__box .p-inputnumber-input{color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-inputnumber__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-inputnumber__help--error{color:var(--color-error, #e03430)}\n"], dependencies: [{ kind: "component", type: InputNumber, selector: "p-inputNumber, p-inputnumber, p-input-number", inputs: ["showButtons", "format", "buttonLayout", "inputId", "styleClass", "placeholder", "tabindex", "title", "ariaLabelledBy", "ariaDescribedBy", "ariaLabel", "ariaRequired", "autocomplete", "incrementButtonClass", "decrementButtonClass", "incrementButtonIcon", "decrementButtonIcon", "readonly", "allowEmpty", "locale", "localeMatcher", "mode", "currency", "currencyDisplay", "useGrouping", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "inputStyle", "inputStyleClass", "showClear", "autofocus"], outputs: ["onInput", "onFocus", "onBlur", "onKeyDown", "onClear"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkInputNumberComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-inputnumber', standalone: true, imports: [InputNumber, FloatLabel, FormsModule], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkInputNumberComponent), multi: true }], template: "<div\r\n  class=\"sk-inputnumber\"\r\n  [class.sk-inputnumber--fluid]=\"fluid()\"\r\n  [class.sk-inputnumber--invalid]=\"invalid()\"\r\n  [class.sk-inputnumber--disabled]=\"_isDisabled()\"\r\n>\r\n  <div class=\"sk-inputnumber__box\">\r\n    <p-floatlabel variant=\"in\">\r\n      <p-inputnumber\r\n        [inputId]=\"inputId\"\r\n        [ngModel]=\"_value()\"\r\n        (ngModelChange)=\"handleInput($event)\"\r\n        [min]=\"min()\"\r\n        [max]=\"max()\"\r\n        [step]=\"step()\"\r\n        [prefix]=\"prefix()\"\r\n        [suffix]=\"suffix()\"\r\n        [showButtons]=\"showButtons()\"\r\n        [mode]=\"mode()\"\r\n        [disabled]=\"_isDisabled()\"\r\n        [invalid]=\"invalid()\"\r\n        [fluid]=\"true\"\r\n        (onBlur)=\"handleBlur()\"\r\n        class=\"sk-inputnumber__field\"\r\n      />\r\n      <label [for]=\"inputId\">{{ label() }}</label>\r\n    </p-floatlabel>\r\n  </div>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-inputnumber__help sk-inputnumber__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-inputnumber__help\" [class.sk-inputnumber__help--error]=\"invalid()\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-inputnumber{display:flex;flex-direction:column;gap:4px;width:100%}.sk-inputnumber__box{border:1px solid var(--stroke-grey-light, #dddddd);border-radius:var(--bordes-s, 8px);background:var(--background-principal, #ffffff);width:100%;min-height:var(--size-048, 48px);transition:border-color .15s ease}::ng-deep .sk-inputnumber__box p-floatlabel,::ng-deep .sk-inputnumber__box .p-floatlabel{display:block!important;width:100%!important;border:none!important;background:transparent!important;box-shadow:none!important}::ng-deep .sk-inputnumber__box .p-inputnumber{width:100%}::ng-deep .sk-inputnumber__box .p-inputnumber-input{width:100%;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline:12px;border:none!important;background:transparent!important;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-dark, #404040);box-sizing:border-box;box-shadow:none!important;outline:none}::ng-deep .sk-inputnumber__box label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;color:var(--texts-medium, #666666)}.sk-inputnumber:not(.sk-inputnumber--disabled):not(.sk-inputnumber--invalid):hover .sk-inputnumber__box{border-color:var(--stroke-grey-medium, #c5c5c5)}.sk-inputnumber:not(.sk-inputnumber--disabled):not(.sk-inputnumber--invalid):focus-within .sk-inputnumber__box{border-color:var(--stroke-brand, #00c73d)}.sk-inputnumber--invalid .sk-inputnumber__box{border-color:var(--color-error, #e03430)}.sk-inputnumber--disabled .sk-inputnumber__box{background:var(--background-grey-light, #f7f7f7);border-color:var(--stroke-grey-light, #dddddd)}::ng-deep .sk-inputnumber--disabled .sk-inputnumber__box .p-inputnumber-input{color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-inputnumber__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-inputnumber__help--error{color:var(--color-error, #e03430)}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], step: [{ type: i0.Input, args: [{ isSignal: true, alias: "step", required: false }] }], prefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefix", required: false }] }], suffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffix", required: false }] }], helpText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helpText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], showButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "showButtons", required: false }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkInputOtpComponent {
    length = input(6, ...(ngDevMode ? [{ debugName: "length" }] : /* istanbul ignore next */ []));
    integerOnly = input(false, { ...(ngDevMode ? { debugName: "integerOnly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    value = '';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkInputOtpComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkInputOtpComponent, isStandalone: true, selector: "sk-inputotp", inputs: { length: { classPropertyName: "length", publicName: "length", isSignal: true, isRequired: false, transformFunction: null }, integerOnly: { classPropertyName: "integerOnly", publicName: "integerOnly", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <p-inputotp
      [(ngModel)]="value"
      [length]="length()"
      [integerOnly]="integerOnly()"
      [disabled]="disabled()"
      (onChange)="valueChange.emit($event)"
    />
  `, isInline: true, styles: [":host{display:flex;justify-content:center}::ng-deep .p-inputotp-input{border-radius:var(--bordes-s, 4px);transition:border-color .15s ease}::ng-deep .p-inputotp-input:hover:not(:disabled){border-color:var(--stroke-grey-medium, #c5c5c5)}\n"], dependencies: [{ kind: "component", type: InputOtp, selector: "p-inputOtp, p-inputotp, p-input-otp", inputs: ["readonly", "tabindex", "length", "styleClass", "mask", "integerOnly", "autofocus", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkInputOtpComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-inputotp', standalone: true, imports: [InputOtp, FormsModule], template: `
    <p-inputotp
      [(ngModel)]="value"
      [length]="length()"
      [integerOnly]="integerOnly()"
      [disabled]="disabled()"
      (onChange)="valueChange.emit($event)"
    />
  `, styles: [":host{display:flex;justify-content:center}::ng-deep .p-inputotp-input{border-radius:var(--bordes-s, 4px);transition:border-color .15s ease}::ng-deep .p-inputotp-input:hover:not(:disabled){border-color:var(--stroke-grey-medium, #c5c5c5)}\n"] }]
        }], propDecorators: { length: [{ type: i0.Input, args: [{ isSignal: true, alias: "length", required: false }] }], integerOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "integerOnly", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkKnobComponent {
    min = input(0, ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    max = input(100, ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    step = input(1, ...(ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showValue = input(true, { ...(ngDevMode ? { debugName: "showValue" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    size = input(100, ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    valueChange = output();
    value = 50;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkKnobComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkKnobComponent, isStandalone: true, selector: "sk-knob", inputs: { min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, showValue: { classPropertyName: "showValue", publicName: "showValue", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <p-knob
      [(ngModel)]="value"
      [min]="min()"
      [max]="max()"
      [step]="step()"
      [disabled]="disabled()"
      [readonly]="readonly()"
      [showValue]="showValue()"
      [size]="size()"
      (onChange)="valueChange.emit($event)"
    />
  `, isInline: true, styles: [":host{display:flex;justify-content:center}\n"], dependencies: [{ kind: "component", type: Knob, selector: "p-knob", inputs: ["styleClass", "ariaLabel", "ariaLabelledBy", "tabindex", "valueColor", "rangeColor", "textColor", "valueTemplate", "size", "min", "max", "step", "strokeWidth", "showValue", "readonly"], outputs: ["onChange"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkKnobComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-knob', standalone: true, imports: [Knob, FormsModule], template: `
    <p-knob
      [(ngModel)]="value"
      [min]="min()"
      [max]="max()"
      [step]="step()"
      [disabled]="disabled()"
      [readonly]="readonly()"
      [showValue]="showValue()"
      [size]="size()"
      (onChange)="valueChange.emit($event)"
    />
  `, styles: [":host{display:flex;justify-content:center}\n"] }]
        }], propDecorators: { min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], step: [{ type: i0.Input, args: [{ isSignal: true, alias: "step", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], showValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "showValue", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

const DEMO_CHECK = [
    { label: 'Opción', value: 'a' },
    { label: 'Opción', value: 'b' },
    { label: 'Opción', value: 'c' },
];
const DEMO_TEXT = [
    { label: 'Opción', value: 'a' },
    { label: 'Opción', value: 'b' },
    { label: 'Opción', value: 'c' },
];
const DEMO_ICON = [
    { label: 'Opción', value: 'a', icon: 'pi pi-home' },
    { label: 'Opción', value: 'b', icon: 'pi pi-home' },
    { label: 'Opción', value: 'c', icon: 'pi pi-home' },
];
const DEMO_DESC = [
    { label: 'Opción', value: 'a', icon: 'pi pi-home', description: 'Opción' },
    { label: 'Opción', value: 'b', icon: 'pi pi-home', description: 'Opción' },
    { label: 'Opción', value: 'c', icon: 'pi pi-home', description: 'Opción' },
];
class SkListComponent {
    DEMO_CHECK = DEMO_CHECK;
    DEMO_TEXT = DEMO_TEXT;
    DEMO_ICON = DEMO_ICON;
    DEMO_DESC = DEMO_DESC;
    items = input([
        { label: 'Bogotá', value: 'bog', icon: 'pi pi-home', description: 'Capital del país' },
        { label: 'Medellín', value: 'med', icon: 'pi pi-star', description: 'Ciudad de la eterna primavera' },
        { label: 'Cali', value: 'cal', icon: 'pi pi-heart', description: 'Capital de la salsa' },
        { label: 'Barranquilla', value: 'bar', icon: 'pi pi-globe', description: 'Puerta de oro de Colombia' },
        { label: 'Cartagena', value: 'cta', icon: 'pi pi-map-marker', description: 'Ciudad amurallada', disabled: true },
    ], ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    multiple = input(false, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showStates = input(false, { ...(ngDevMode ? { debugName: "showStates" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    selected = output();
    value = 'bog';
    resolvedStyle = computed(() => {
        const first = this.items().find(i => !i.disabled) ?? this.items()[0];
        if (!first)
            return 'text';
        if (first.description)
            return 'description';
        if (first.icon)
            return 'icon';
        if (this.multiple())
            return 'check';
        return 'text';
    }, ...(ngDevMode ? [{ debugName: "resolvedStyle" }] : /* istanbul ignore next */ []));
    isSelected(item) {
        const v = item.value ?? item.label;
        if (this.multiple()) {
            return Array.isArray(this.value) && this.value.includes(v);
        }
        return this.value === v;
    }
    handleSelect(item) {
        if (item.disabled)
            return;
        const v = item.value ?? item.label;
        if (this.multiple()) {
            const current = Array.isArray(this.value) ? [...this.value] : [];
            const idx = current.indexOf(v);
            idx >= 0 ? current.splice(idx, 1) : current.push(v);
            this.value = current;
        }
        else {
            this.value = this.value === v ? null : v;
        }
        this.valueChange.emit(this.value);
        this.selected.emit(this.value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkListComponent, isStandalone: true, selector: "sk-list", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, showStates: { classPropertyName: "showStates", publicName: "showStates", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange", selected: "selected" }, ngImport: i0, template: "@if (showStates()) {\r\n      <!-- \u2500\u2500 States demo grid \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\r\n      <div class=\"sk-list-demo\">\r\n        <div class=\"sk-list-demo__col\">\r\n          <span class=\"sk-list-demo__title\">Check</span>\r\n          <ul class=\"sk-list\" role=\"listbox\">\r\n            @for (item of DEMO_CHECK; track item.value; let i = $index) {\r\n              <li class=\"sk-list__item\"\r\n                [class.sk-list__item--selected]=\"i === 1\"\r\n                [class.sk-list__item--disabled]=\"i === 2\"\r\n                [tabindex]=\"i === 2 ? -1 : 0\" role=\"option\">\r\n                <span class=\"sk-list__checkbox\"\r\n                  [class.sk-list__checkbox--checked]=\"i === 1\"\r\n                  [class.sk-list__checkbox--disabled]=\"i === 2\"\r\n                  aria-hidden=\"true\">\r\n                  @if (i === 1) { <i class=\"pi pi-check sk-list__checkbox-icon\"></i> }\r\n                  @if (i === 2) { <i class=\"pi pi-check sk-list__checkbox-icon\"></i> }\r\n                </span>\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </div>\r\n\r\n        <div class=\"sk-list-demo__col\">\r\n          <span class=\"sk-list-demo__title\">Text</span>\r\n          <ul class=\"sk-list\" role=\"listbox\">\r\n            @for (item of DEMO_TEXT; track item.value; let i = $index) {\r\n              <li class=\"sk-list__item\"\r\n                [class.sk-list__item--selected]=\"i === 1\"\r\n                [class.sk-list__item--disabled]=\"i === 2\"\r\n                [tabindex]=\"i === 2 ? -1 : 0\" role=\"option\">\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </div>\r\n\r\n        <div class=\"sk-list-demo__col\">\r\n          <span class=\"sk-list-demo__title\">Icon</span>\r\n          <ul class=\"sk-list\" role=\"listbox\">\r\n            @for (item of DEMO_ICON; track item.value; let i = $index) {\r\n              <li class=\"sk-list__item\"\r\n                [class.sk-list__item--selected]=\"i === 1\"\r\n                [class.sk-list__item--disabled]=\"i === 2\"\r\n                [tabindex]=\"i === 2 ? -1 : 0\" role=\"option\">\r\n                <i [class]=\"(item.icon ?? 'pi pi-circle') + ' sk-list__icon'\" aria-hidden=\"true\"></i>\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </div>\r\n\r\n        <div class=\"sk-list-demo__col\">\r\n          <span class=\"sk-list-demo__title\">Description</span>\r\n          <ul class=\"sk-list\" role=\"listbox\">\r\n            @for (item of DEMO_DESC; track item.value; let i = $index) {\r\n              <li class=\"sk-list__item sk-list__item--align-top\"\r\n                [class.sk-list__item--selected]=\"i === 1\"\r\n                [class.sk-list__item--disabled]=\"i === 2\"\r\n                [tabindex]=\"i === 2 ? -1 : 0\" role=\"option\">\r\n                <i [class]=\"(item.icon ?? 'pi pi-circle') + ' sk-list__icon sk-list__icon--top'\" aria-hidden=\"true\"></i>\r\n                <div class=\"sk-list__body\">\r\n                  <span class=\"sk-list__label sk-list__label--bold\">{{ item.label }}</span>\r\n                  <span class=\"sk-list__description\">{{ item.description }}</span>\r\n                </div>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </div>\r\n      </div>\r\n    } @else {\r\n      <!-- \u2500\u2500 Normal list \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\r\n      <ul class=\"sk-list\" role=\"listbox\" [attr.aria-multiselectable]=\"multiple() || null\">\r\n        @for (item of items(); track item.value ?? item.label) {\r\n          <li\r\n            class=\"sk-list__item\"\r\n            [class.sk-list__item--selected]=\"isSelected(item)\"\r\n            [class.sk-list__item--disabled]=\"item.disabled\"\r\n            [class.sk-list__item--align-top]=\"resolvedStyle() === 'description'\"\r\n            role=\"option\"\r\n            [attr.aria-selected]=\"isSelected(item)\"\r\n            [attr.aria-disabled]=\"item.disabled || null\"\r\n            [tabindex]=\"item.disabled ? -1 : 0\"\r\n            (click)=\"handleSelect(item)\"\r\n            (keydown.enter)=\"handleSelect(item)\"\r\n            (keydown.space)=\"handleSelect(item); $event.preventDefault()\"\r\n          >\r\n            @switch (resolvedStyle()) {\r\n              @case ('check') {\r\n                <span\r\n                  class=\"sk-list__checkbox\"\r\n                  [class.sk-list__checkbox--checked]=\"isSelected(item)\"\r\n                  [class.sk-list__checkbox--disabled]=\"item.disabled\"\r\n                  aria-hidden=\"true\"\r\n                >\r\n                  @if (isSelected(item)) {\r\n                    <i class=\"pi pi-check sk-list__checkbox-icon\"></i>\r\n                  }\r\n                </span>\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              }\r\n              @case ('icon') {\r\n                <i [class]=\"(item.icon ?? 'pi pi-circle') + ' sk-list__icon'\" aria-hidden=\"true\"></i>\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              }\r\n              @case ('description') {\r\n                <i [class]=\"(item.icon ?? 'pi pi-circle') + ' sk-list__icon sk-list__icon--top'\" aria-hidden=\"true\"></i>\r\n                <div class=\"sk-list__body\">\r\n                  <span class=\"sk-list__label sk-list__label--bold\">{{ item.label }}</span>\r\n                  <span class=\"sk-list__description\">{{ item.description }}</span>\r\n                </div>\r\n              }\r\n              @default {\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              }\r\n            }\r\n          </li>\r\n        }\r\n      </ul>\r\n    }\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-list-demo{display:flex;gap:16px;align-items:flex-start}.sk-list-demo__col{display:flex;flex-direction:column;gap:8px;flex:1}.sk-list-demo__title{font-family:Open Sans,system-ui,sans-serif;font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--texts-medium, #666666);padding:0 4px}.sk-list{list-style:none;margin:0;padding:8px;display:flex;flex-direction:column;gap:2px;border:1px solid var(--stroke-grey-light, #d4d4d4);border-radius:8px;background:#fff}.sk-list__item{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;cursor:pointer;font-family:Open Sans,system-ui,sans-serif;font-size:14px;font-weight:400;line-height:20px;color:var(--texts-dark, #404040);background:transparent;outline:none;-webkit-user-select:none;user-select:none;transition:background .12s ease,color .12s ease}.sk-list__item--align-top{align-items:flex-start}.sk-list__item:not(.sk-list__item--disabled):hover{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 92%)}.sk-list__item:not(.sk-list__item--disabled):active{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 86%)}.sk-list__item:not(.sk-list__item--disabled):focus-visible{outline:2px solid var(--background-brand, #00c73d);outline-offset:-2px}.sk-list__item--selected:not(.sk-list__item--disabled){background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 88%);color:color-mix(in srgb,var(--background-brand, #00c73d),#000 30%)}.sk-list__item--selected:not(.sk-list__item--disabled):hover{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 84%)}.sk-list__item--disabled{cursor:not-allowed;color:var(--texts-light, #a5a5a5);pointer-events:none}.sk-list__checkbox{display:flex;align-items:center;justify-content:center;width:18px;height:18px;min-width:18px;border-radius:4px;border:1.5px solid var(--stroke-default, #a5a5a5);background:#fff;flex-shrink:0;transition:background .12s ease,border-color .12s ease}.sk-list__item:not(.sk-list__item--disabled):hover .sk-list__checkbox:not(.sk-list__checkbox--checked){border-color:var(--background-brand, #00c73d)}.sk-list__checkbox--checked{background:var(--background-brand, #00c73d)!important;border-color:var(--background-brand, #00c73d)!important}.sk-list__checkbox--disabled{border-color:var(--stroke-grey-light, #d4d4d4)!important;background:#f5f5f5!important}.sk-list__checkbox--checked.sk-list__checkbox--disabled{background:var(--background-grey-medium, #b7b7b7)!important;border-color:var(--background-grey-medium, #b7b7b7)!important}.sk-list__checkbox-icon{font-size:10px;color:#fff}.sk-list__icon{font-size:16px;flex-shrink:0;color:inherit}.sk-list__icon--top{margin-top:2px}.sk-list__item--disabled .sk-list__icon{color:var(--texts-light, #a5a5a5)}.sk-list__body{display:flex;flex-direction:column;gap:2px}.sk-list__label{font-size:14px;font-family:Open Sans,system-ui,sans-serif;line-height:20px;color:inherit}.sk-list__label--bold{font-weight:700}.sk-list__description{font-size:12px;font-family:Open Sans,system-ui,sans-serif;line-height:16px;color:var(--texts-medium, #666666)}.sk-list__item--selected .sk-list__description{color:color-mix(in srgb,var(--background-brand, #00c73d),#666666 60%)}.sk-list__item--disabled .sk-list__description{color:var(--texts-light, #a5a5a5)}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-list', standalone: true, template: "@if (showStates()) {\r\n      <!-- \u2500\u2500 States demo grid \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\r\n      <div class=\"sk-list-demo\">\r\n        <div class=\"sk-list-demo__col\">\r\n          <span class=\"sk-list-demo__title\">Check</span>\r\n          <ul class=\"sk-list\" role=\"listbox\">\r\n            @for (item of DEMO_CHECK; track item.value; let i = $index) {\r\n              <li class=\"sk-list__item\"\r\n                [class.sk-list__item--selected]=\"i === 1\"\r\n                [class.sk-list__item--disabled]=\"i === 2\"\r\n                [tabindex]=\"i === 2 ? -1 : 0\" role=\"option\">\r\n                <span class=\"sk-list__checkbox\"\r\n                  [class.sk-list__checkbox--checked]=\"i === 1\"\r\n                  [class.sk-list__checkbox--disabled]=\"i === 2\"\r\n                  aria-hidden=\"true\">\r\n                  @if (i === 1) { <i class=\"pi pi-check sk-list__checkbox-icon\"></i> }\r\n                  @if (i === 2) { <i class=\"pi pi-check sk-list__checkbox-icon\"></i> }\r\n                </span>\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </div>\r\n\r\n        <div class=\"sk-list-demo__col\">\r\n          <span class=\"sk-list-demo__title\">Text</span>\r\n          <ul class=\"sk-list\" role=\"listbox\">\r\n            @for (item of DEMO_TEXT; track item.value; let i = $index) {\r\n              <li class=\"sk-list__item\"\r\n                [class.sk-list__item--selected]=\"i === 1\"\r\n                [class.sk-list__item--disabled]=\"i === 2\"\r\n                [tabindex]=\"i === 2 ? -1 : 0\" role=\"option\">\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </div>\r\n\r\n        <div class=\"sk-list-demo__col\">\r\n          <span class=\"sk-list-demo__title\">Icon</span>\r\n          <ul class=\"sk-list\" role=\"listbox\">\r\n            @for (item of DEMO_ICON; track item.value; let i = $index) {\r\n              <li class=\"sk-list__item\"\r\n                [class.sk-list__item--selected]=\"i === 1\"\r\n                [class.sk-list__item--disabled]=\"i === 2\"\r\n                [tabindex]=\"i === 2 ? -1 : 0\" role=\"option\">\r\n                <i [class]=\"(item.icon ?? 'pi pi-circle') + ' sk-list__icon'\" aria-hidden=\"true\"></i>\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </div>\r\n\r\n        <div class=\"sk-list-demo__col\">\r\n          <span class=\"sk-list-demo__title\">Description</span>\r\n          <ul class=\"sk-list\" role=\"listbox\">\r\n            @for (item of DEMO_DESC; track item.value; let i = $index) {\r\n              <li class=\"sk-list__item sk-list__item--align-top\"\r\n                [class.sk-list__item--selected]=\"i === 1\"\r\n                [class.sk-list__item--disabled]=\"i === 2\"\r\n                [tabindex]=\"i === 2 ? -1 : 0\" role=\"option\">\r\n                <i [class]=\"(item.icon ?? 'pi pi-circle') + ' sk-list__icon sk-list__icon--top'\" aria-hidden=\"true\"></i>\r\n                <div class=\"sk-list__body\">\r\n                  <span class=\"sk-list__label sk-list__label--bold\">{{ item.label }}</span>\r\n                  <span class=\"sk-list__description\">{{ item.description }}</span>\r\n                </div>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </div>\r\n      </div>\r\n    } @else {\r\n      <!-- \u2500\u2500 Normal list \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\r\n      <ul class=\"sk-list\" role=\"listbox\" [attr.aria-multiselectable]=\"multiple() || null\">\r\n        @for (item of items(); track item.value ?? item.label) {\r\n          <li\r\n            class=\"sk-list__item\"\r\n            [class.sk-list__item--selected]=\"isSelected(item)\"\r\n            [class.sk-list__item--disabled]=\"item.disabled\"\r\n            [class.sk-list__item--align-top]=\"resolvedStyle() === 'description'\"\r\n            role=\"option\"\r\n            [attr.aria-selected]=\"isSelected(item)\"\r\n            [attr.aria-disabled]=\"item.disabled || null\"\r\n            [tabindex]=\"item.disabled ? -1 : 0\"\r\n            (click)=\"handleSelect(item)\"\r\n            (keydown.enter)=\"handleSelect(item)\"\r\n            (keydown.space)=\"handleSelect(item); $event.preventDefault()\"\r\n          >\r\n            @switch (resolvedStyle()) {\r\n              @case ('check') {\r\n                <span\r\n                  class=\"sk-list__checkbox\"\r\n                  [class.sk-list__checkbox--checked]=\"isSelected(item)\"\r\n                  [class.sk-list__checkbox--disabled]=\"item.disabled\"\r\n                  aria-hidden=\"true\"\r\n                >\r\n                  @if (isSelected(item)) {\r\n                    <i class=\"pi pi-check sk-list__checkbox-icon\"></i>\r\n                  }\r\n                </span>\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              }\r\n              @case ('icon') {\r\n                <i [class]=\"(item.icon ?? 'pi pi-circle') + ' sk-list__icon'\" aria-hidden=\"true\"></i>\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              }\r\n              @case ('description') {\r\n                <i [class]=\"(item.icon ?? 'pi pi-circle') + ' sk-list__icon sk-list__icon--top'\" aria-hidden=\"true\"></i>\r\n                <div class=\"sk-list__body\">\r\n                  <span class=\"sk-list__label sk-list__label--bold\">{{ item.label }}</span>\r\n                  <span class=\"sk-list__description\">{{ item.description }}</span>\r\n                </div>\r\n              }\r\n              @default {\r\n                <span class=\"sk-list__label\">{{ item.label }}</span>\r\n              }\r\n            }\r\n          </li>\r\n        }\r\n      </ul>\r\n    }\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-list-demo{display:flex;gap:16px;align-items:flex-start}.sk-list-demo__col{display:flex;flex-direction:column;gap:8px;flex:1}.sk-list-demo__title{font-family:Open Sans,system-ui,sans-serif;font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--texts-medium, #666666);padding:0 4px}.sk-list{list-style:none;margin:0;padding:8px;display:flex;flex-direction:column;gap:2px;border:1px solid var(--stroke-grey-light, #d4d4d4);border-radius:8px;background:#fff}.sk-list__item{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;cursor:pointer;font-family:Open Sans,system-ui,sans-serif;font-size:14px;font-weight:400;line-height:20px;color:var(--texts-dark, #404040);background:transparent;outline:none;-webkit-user-select:none;user-select:none;transition:background .12s ease,color .12s ease}.sk-list__item--align-top{align-items:flex-start}.sk-list__item:not(.sk-list__item--disabled):hover{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 92%)}.sk-list__item:not(.sk-list__item--disabled):active{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 86%)}.sk-list__item:not(.sk-list__item--disabled):focus-visible{outline:2px solid var(--background-brand, #00c73d);outline-offset:-2px}.sk-list__item--selected:not(.sk-list__item--disabled){background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 88%);color:color-mix(in srgb,var(--background-brand, #00c73d),#000 30%)}.sk-list__item--selected:not(.sk-list__item--disabled):hover{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 84%)}.sk-list__item--disabled{cursor:not-allowed;color:var(--texts-light, #a5a5a5);pointer-events:none}.sk-list__checkbox{display:flex;align-items:center;justify-content:center;width:18px;height:18px;min-width:18px;border-radius:4px;border:1.5px solid var(--stroke-default, #a5a5a5);background:#fff;flex-shrink:0;transition:background .12s ease,border-color .12s ease}.sk-list__item:not(.sk-list__item--disabled):hover .sk-list__checkbox:not(.sk-list__checkbox--checked){border-color:var(--background-brand, #00c73d)}.sk-list__checkbox--checked{background:var(--background-brand, #00c73d)!important;border-color:var(--background-brand, #00c73d)!important}.sk-list__checkbox--disabled{border-color:var(--stroke-grey-light, #d4d4d4)!important;background:#f5f5f5!important}.sk-list__checkbox--checked.sk-list__checkbox--disabled{background:var(--background-grey-medium, #b7b7b7)!important;border-color:var(--background-grey-medium, #b7b7b7)!important}.sk-list__checkbox-icon{font-size:10px;color:#fff}.sk-list__icon{font-size:16px;flex-shrink:0;color:inherit}.sk-list__icon--top{margin-top:2px}.sk-list__item--disabled .sk-list__icon{color:var(--texts-light, #a5a5a5)}.sk-list__body{display:flex;flex-direction:column;gap:2px}.sk-list__label{font-size:14px;font-family:Open Sans,system-ui,sans-serif;line-height:20px;color:inherit}.sk-list__label--bold{font-weight:700}.sk-list__description{font-size:12px;font-family:Open Sans,system-ui,sans-serif;line-height:16px;color:var(--texts-medium, #666666)}.sk-list__item--selected .sk-list__description{color:color-mix(in srgb,var(--background-brand, #00c73d),#666666 60%)}.sk-list__item--disabled .sk-list__description{color:var(--texts-light, #a5a5a5)}\n"] }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], showStates: [{ type: i0.Input, args: [{ isSignal: true, alias: "showStates", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], selected: [{ type: i0.Output, args: ["selected"] }] } });

class SkListboxComponent {
    options = input([
        { label: 'Bogotá', value: 'bog', icon: 'pi pi-home', description: 'Capital del país' },
        { label: 'Medellín', value: 'med', icon: 'pi pi-star', description: 'Ciudad de la eterna primavera' },
        { label: 'Cali', value: 'cal', icon: 'pi pi-heart', description: 'Capital de la salsa' },
        { label: 'Barranquilla', value: 'bar', icon: 'pi pi-globe', description: 'Puerta de oro de Colombia' },
        { label: 'Cartagena', value: 'cta', icon: 'pi pi-map-marker', description: 'Ciudad amurallada', disabled: true },
    ], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    optionLabel = input('label', ...(ngDevMode ? [{ debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    optionValue = input('value', ...(ngDevMode ? [{ debugName: "optionValue" }] : /* istanbul ignore next */ []));
    listStyle = input('text', ...(ngDevMode ? [{ debugName: "listStyle" }] : /* istanbul ignore next */ []));
    height = input('200px', ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    filter = input(false, { ...(ngDevMode ? { debugName: "filter" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    filterPlaceholder = input('Buscar', ...(ngDevMode ? [{ debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []));
    group = input(false, { ...(ngDevMode ? { debugName: "group" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    optionGroupLabel = input('label', ...(ngDevMode ? [{ debugName: "optionGroupLabel" }] : /* istanbul ignore next */ []));
    optionGroupChildren = input('items', ...(ngDevMode ? [{ debugName: "optionGroupChildren" }] : /* istanbul ignore next */ []));
    emptyIcon = input('pi pi-search', ...(ngDevMode ? [{ debugName: "emptyIcon" }] : /* istanbul ignore next */ []));
    emptyTitle = input('¡Ups! lo sentimos', ...(ngDevMode ? [{ debugName: "emptyTitle" }] : /* istanbul ignore next */ []));
    emptyMessage = input('no coincide con ningún resultado', ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    valueChange = output();
    value = null;
    resolvedListStyle = computed(() => this.listStyle(), ...(ngDevMode ? [{ debugName: "resolvedListStyle" }] : /* istanbul ignore next */ []));
    effectiveOptions = computed(() => this.listStyle() === 'empty' ? [] : this.options(), ...(ngDevMode ? [{ debugName: "effectiveOptions" }] : /* istanbul ignore next */ []));
    isCheckStyle = computed(() => this.listStyle() === 'check', ...(ngDevMode ? [{ debugName: "isCheckStyle" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkListboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkListboxComponent, isStandalone: true, selector: "sk-listbox", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, listStyle: { classPropertyName: "listStyle", publicName: "listStyle", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceholder: { classPropertyName: "filterPlaceholder", publicName: "filterPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, group: { classPropertyName: "group", publicName: "group", isSignal: true, isRequired: false, transformFunction: null }, optionGroupLabel: { classPropertyName: "optionGroupLabel", publicName: "optionGroupLabel", isSignal: true, isRequired: false, transformFunction: null }, optionGroupChildren: { classPropertyName: "optionGroupChildren", publicName: "optionGroupChildren", isSignal: true, isRequired: false, transformFunction: null }, emptyIcon: { classPropertyName: "emptyIcon", publicName: "emptyIcon", isSignal: true, isRequired: false, transformFunction: null }, emptyTitle: { classPropertyName: "emptyTitle", publicName: "emptyTitle", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, host: { properties: { "style.max-height": "height" } }, ngImport: i0, template: "<p-listbox\r\n      [(ngModel)]=\"value\"\r\n      [options]=\"effectiveOptions()\"\r\n      [optionLabel]=\"optionLabel()\"\r\n      [optionValue]=\"optionValue()\"\r\n      [optionDisabled]=\"'disabled'\"\r\n      [multiple]=\"isCheckStyle()\"\r\n      [checkbox]=\"isCheckStyle()\"\r\n      [showToggleAll]=\"false\"\r\n      [focusOnHover]=\"false\"\r\n      [filter]=\"filter()\"\r\n      [filterPlaceHolder]=\"filterPlaceholder()\"\r\n      [group]=\"group()\"\r\n      [optionGroupLabel]=\"optionGroupLabel()\"\r\n      [optionGroupChildren]=\"optionGroupChildren()\"\r\n      [highlightOnSelect]=\"true\"\r\n      (onChange)=\"valueChange.emit($event)\"\r\n    >\r\n      <ng-template pTemplate=\"item\" let-option>\r\n        @switch (resolvedListStyle()) {\r\n          @case ('check') {\r\n            <span class=\"sk-lbox__label\">{{ option.label }}</span>\r\n          }\r\n          @case ('icon') {\r\n            <i [class]=\"(option.icon ?? 'pi pi-circle') + ' sk-lbox__icon'\" aria-hidden=\"true\"></i>\r\n            <span class=\"sk-lbox__label\">{{ option.label }}</span>\r\n          }\r\n          @case ('description') {\r\n            <i [class]=\"(option.icon ?? 'pi pi-circle') + ' sk-lbox__icon sk-lbox__icon--top'\" aria-hidden=\"true\"></i>\r\n            <div class=\"sk-lbox__body\">\r\n              <span class=\"sk-lbox__label sk-lbox__label--bold\">{{ option.label }}</span>\r\n              <span class=\"sk-lbox__description\">{{ option.description }}</span>\r\n            </div>\r\n          }\r\n          @default {\r\n            <span class=\"sk-lbox__label\">{{ option.label }}</span>\r\n          }\r\n        }\r\n      </ng-template>\r\n\r\n      <ng-template pTemplate=\"group\" let-group>\r\n        <span class=\"sk-lbox__group-label\">{{ group.label }}</span>\r\n      </ng-template>\r\n\r\n      <ng-template pTemplate=\"emptyfilter\">\r\n        <div class=\"sk-lbox__empty\">\r\n          <i [class]=\"emptyIcon() + ' sk-lbox__empty-icon'\" aria-hidden=\"true\"></i>\r\n          <p class=\"sk-lbox__empty-title\">{{ emptyTitle() }}</p>\r\n          <p class=\"sk-lbox__empty-msg\">\"{{ emptyMessage() }}\"</p>\r\n        </div>\r\n      </ng-template>\r\n\r\n      <ng-template pTemplate=\"empty\">\r\n        <div class=\"sk-lbox__empty\">\r\n          <i [class]=\"emptyIcon() + ' sk-lbox__empty-icon'\" aria-hidden=\"true\"></i>\r\n          <p class=\"sk-lbox__empty-title\">{{ emptyTitle() }}</p>\r\n          <p class=\"sk-lbox__empty-msg\">{{ emptyMessage() }}</p>\r\n        </div>\r\n      </ng-template>\r\n    </p-listbox>\r\n", styles: ["@charset \"UTF-8\";:host{display:flex;flex-direction:column}:host ::ng-deep .p-listbox{display:flex;flex-direction:column;max-height:100%;overflow:hidden;border:1px solid var(--stroke-grey-light, #d4d4d4);border-radius:8px;background:#fff;padding:0;box-shadow:none}:host ::ng-deep .p-listbox-header{padding:8px 8px 4px;border-bottom:none;background:transparent;flex-shrink:0}:host ::ng-deep .p-listbox-header input{width:100%!important;height:32px!important;border-radius:8px!important;border:1px solid var(--stroke-grey-light, #d4d4d4)!important;padding:0 36px 0 12px!important;font-size:12px!important;font-weight:500!important;line-height:16px!important;color:var(--texts-light, #a5a5a5)!important;background:#fff!important;outline:none!important;box-shadow:none!important;transition:border-color .15s ease!important}:host ::ng-deep .p-listbox-header input:focus{border-color:var(--background-brand, #00c73d)!important}:host ::ng-deep .p-listbox-header input::placeholder{color:var(--texts-light, #a5a5a5)}:host ::ng-deep .p-listbox-header .p-inputicon{color:var(--icon-disable, #a5a5a5)!important;font-size:12px!important}:host ::ng-deep .p-listbox-list-container{flex:1;min-height:0;max-height:none!important;overflow-y:scroll;overflow-x:hidden;padding:8px;margin-right:8px}:host ::ng-deep .p-listbox-list-container::-webkit-scrollbar{width:8px}:host ::ng-deep .p-listbox-list-container::-webkit-scrollbar-track{background:transparent;border-radius:9999px;margin-top:8px;transition:background .2s ease}:host ::ng-deep .p-listbox-list-container::-webkit-scrollbar-thumb{background:transparent;border-radius:9999px;transition:background .2s ease}:host ::ng-deep .p-listbox:hover .p-listbox-list-container::-webkit-scrollbar-track{background:var(--background-grey-light, #f7f7f7)}:host ::ng-deep .p-listbox:hover .p-listbox-list-container::-webkit-scrollbar-thumb{background:var(--background-grey-medium, #b7b7b7)}:host ::ng-deep .p-listbox:hover .p-listbox-list-container::-webkit-scrollbar-thumb:hover{background:var(--icon-neutral-2, #666666)}:host ::ng-deep .p-listbox-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2px}:host ::ng-deep .p-listbox-option{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;cursor:pointer;font-family:Open Sans,system-ui,sans-serif;font-size:14px;font-weight:400;line-height:20px;color:var(--texts-dark, #404040);background:transparent;outline:none;-webkit-user-select:none;user-select:none;transition:background .12s ease,color .12s ease}:host ::ng-deep .p-listbox-option:not([data-p-disabled=true]):hover{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 92%)}:host ::ng-deep .p-listbox-option:not([data-p-disabled=true]):active{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 86%)}:host ::ng-deep .p-listbox:has(.p-listbox-list:focus-visible) .p-listbox-option[data-p-focused=true]:not([data-p-disabled=true]){outline:2px solid var(--background-brand, #00c73d);outline-offset:-2px}:host ::ng-deep .p-listbox-option[data-p-selected=true],:host ::ng-deep .p-listbox-option.p-listbox-option-selected{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 88%);color:color-mix(in srgb,var(--background-brand, #00c73d),#000 30%)}:host ::ng-deep .p-listbox-option[data-p-selected=true]:not([data-p-disabled=true]):hover{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 84%)}:host ::ng-deep .p-listbox-option[data-p-disabled=true]{cursor:not-allowed;color:var(--texts-light, #a5a5a5);pointer-events:none}:host ::ng-deep .p-listbox-option .p-checkbox{pointer-events:none;flex-shrink:0}:host ::ng-deep .p-listbox-option .p-checkbox-box{width:18px!important;height:18px!important;border-radius:4px!important;border:1.5px solid var(--stroke-default, #a5a5a5)!important;background:#fff!important;box-shadow:none!important;transition:background .12s ease,border-color .12s ease!important}:host ::ng-deep .p-listbox-option:not([data-p-disabled=true]):hover .p-checkbox-box{border-color:var(--background-brand, #00c73d)!important}:host ::ng-deep .p-listbox-option[data-p-selected=true] .p-checkbox-box,:host ::ng-deep .p-listbox-option.p-listbox-option-selected .p-checkbox-box{background:var(--background-brand, #00c73d)!important;border-color:var(--background-brand, #00c73d)!important}:host ::ng-deep .p-listbox-option .p-checkbox-icon{color:#fff!important;width:11px!important;height:11px!important}:host ::ng-deep .p-listbox-option[data-p-disabled=true] .p-checkbox-box{border-color:var(--stroke-grey-light, #d4d4d4)!important;background:#f5f5f5!important}:host ::ng-deep .p-listbox-option-group{padding:8px 12px 4px;cursor:default}.sk-lbox__group-label{font-family:Open Sans,system-ui,sans-serif;font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--texts-medium, #666666)}.sk-lbox__icon{font-size:16px;flex-shrink:0;color:inherit}.sk-lbox__icon--top{margin-top:2px;align-self:flex-start}:host ::ng-deep .p-listbox-option[data-p-disabled=true] .sk-lbox__icon{color:var(--texts-light, #a5a5a5)}.sk-lbox__body{display:flex;flex-direction:column;gap:2px}.sk-lbox__label{font-family:Open Sans,system-ui,sans-serif;font-size:14px;line-height:20px;color:inherit}.sk-lbox__label--bold{font-weight:700}.sk-lbox__description{font-family:Open Sans,system-ui,sans-serif;font-size:12px;line-height:16px;color:var(--texts-medium, #666666)}:host ::ng-deep .p-listbox-option[data-p-selected=true] .sk-lbox__description{color:color-mix(in srgb,var(--background-brand, #00c73d),#666666 60%)}:host ::ng-deep .p-listbox-option[data-p-disabled=true] .sk-lbox__description{color:var(--texts-light, #a5a5a5)}:host ::ng-deep .p-listbox-option:has(.sk-lbox__body){align-items:flex-start}.sk-lbox__empty{display:flex;flex-direction:column;align-items:center;padding:24px 16px;text-align:center;gap:4px}.sk-lbox__empty-icon{font-size:24px;color:var(--texts-light, #a5a5a5);margin-bottom:8px}.sk-lbox__empty-title{margin:0;font-family:Open Sans,system-ui,sans-serif;font-size:14px;font-weight:700;color:var(--texts-dark, #404040)}.sk-lbox__empty-msg{margin:0;font-family:Open Sans,system-ui,sans-serif;font-size:12px;color:var(--texts-medium, #666666)}\n"], dependencies: [{ kind: "component", type: Listbox, selector: "p-listbox, p-listBox, p-list-box", inputs: ["hostName", "id", "searchMessage", "emptySelectionMessage", "selectionMessage", "autoOptionFocus", "ariaLabel", "selectOnFocus", "searchLocale", "focusOnHover", "filterMessage", "filterFields", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "scrollHeight", "tabindex", "multiple", "styleClass", "listStyle", "listStyleClass", "readonly", "checkbox", "filter", "filterBy", "filterMatchMode", "filterLocale", "metaKeySelection", "dataKey", "showToggleAll", "optionLabel", "optionValue", "optionGroupChildren", "optionGroupLabel", "optionDisabled", "ariaFilterLabel", "filterPlaceHolder", "emptyFilterMessage", "emptyMessage", "group", "options", "filterValue", "selectAll", "striped", "highlightOnSelect", "checkmark", "dragdrop", "dropListData", "fluid"], outputs: ["onChange", "onClick", "onDblClick", "onFilter", "onFocus", "onBlur", "onSelectAllChange", "onLazyLoad", "onDrop"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: i2.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkListboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-listbox', standalone: true, imports: [Listbox, FormsModule, SharedModule], host: { '[style.max-height]': 'height' }, template: "<p-listbox\r\n      [(ngModel)]=\"value\"\r\n      [options]=\"effectiveOptions()\"\r\n      [optionLabel]=\"optionLabel()\"\r\n      [optionValue]=\"optionValue()\"\r\n      [optionDisabled]=\"'disabled'\"\r\n      [multiple]=\"isCheckStyle()\"\r\n      [checkbox]=\"isCheckStyle()\"\r\n      [showToggleAll]=\"false\"\r\n      [focusOnHover]=\"false\"\r\n      [filter]=\"filter()\"\r\n      [filterPlaceHolder]=\"filterPlaceholder()\"\r\n      [group]=\"group()\"\r\n      [optionGroupLabel]=\"optionGroupLabel()\"\r\n      [optionGroupChildren]=\"optionGroupChildren()\"\r\n      [highlightOnSelect]=\"true\"\r\n      (onChange)=\"valueChange.emit($event)\"\r\n    >\r\n      <ng-template pTemplate=\"item\" let-option>\r\n        @switch (resolvedListStyle()) {\r\n          @case ('check') {\r\n            <span class=\"sk-lbox__label\">{{ option.label }}</span>\r\n          }\r\n          @case ('icon') {\r\n            <i [class]=\"(option.icon ?? 'pi pi-circle') + ' sk-lbox__icon'\" aria-hidden=\"true\"></i>\r\n            <span class=\"sk-lbox__label\">{{ option.label }}</span>\r\n          }\r\n          @case ('description') {\r\n            <i [class]=\"(option.icon ?? 'pi pi-circle') + ' sk-lbox__icon sk-lbox__icon--top'\" aria-hidden=\"true\"></i>\r\n            <div class=\"sk-lbox__body\">\r\n              <span class=\"sk-lbox__label sk-lbox__label--bold\">{{ option.label }}</span>\r\n              <span class=\"sk-lbox__description\">{{ option.description }}</span>\r\n            </div>\r\n          }\r\n          @default {\r\n            <span class=\"sk-lbox__label\">{{ option.label }}</span>\r\n          }\r\n        }\r\n      </ng-template>\r\n\r\n      <ng-template pTemplate=\"group\" let-group>\r\n        <span class=\"sk-lbox__group-label\">{{ group.label }}</span>\r\n      </ng-template>\r\n\r\n      <ng-template pTemplate=\"emptyfilter\">\r\n        <div class=\"sk-lbox__empty\">\r\n          <i [class]=\"emptyIcon() + ' sk-lbox__empty-icon'\" aria-hidden=\"true\"></i>\r\n          <p class=\"sk-lbox__empty-title\">{{ emptyTitle() }}</p>\r\n          <p class=\"sk-lbox__empty-msg\">\"{{ emptyMessage() }}\"</p>\r\n        </div>\r\n      </ng-template>\r\n\r\n      <ng-template pTemplate=\"empty\">\r\n        <div class=\"sk-lbox__empty\">\r\n          <i [class]=\"emptyIcon() + ' sk-lbox__empty-icon'\" aria-hidden=\"true\"></i>\r\n          <p class=\"sk-lbox__empty-title\">{{ emptyTitle() }}</p>\r\n          <p class=\"sk-lbox__empty-msg\">{{ emptyMessage() }}</p>\r\n        </div>\r\n      </ng-template>\r\n    </p-listbox>\r\n", styles: ["@charset \"UTF-8\";:host{display:flex;flex-direction:column}:host ::ng-deep .p-listbox{display:flex;flex-direction:column;max-height:100%;overflow:hidden;border:1px solid var(--stroke-grey-light, #d4d4d4);border-radius:8px;background:#fff;padding:0;box-shadow:none}:host ::ng-deep .p-listbox-header{padding:8px 8px 4px;border-bottom:none;background:transparent;flex-shrink:0}:host ::ng-deep .p-listbox-header input{width:100%!important;height:32px!important;border-radius:8px!important;border:1px solid var(--stroke-grey-light, #d4d4d4)!important;padding:0 36px 0 12px!important;font-size:12px!important;font-weight:500!important;line-height:16px!important;color:var(--texts-light, #a5a5a5)!important;background:#fff!important;outline:none!important;box-shadow:none!important;transition:border-color .15s ease!important}:host ::ng-deep .p-listbox-header input:focus{border-color:var(--background-brand, #00c73d)!important}:host ::ng-deep .p-listbox-header input::placeholder{color:var(--texts-light, #a5a5a5)}:host ::ng-deep .p-listbox-header .p-inputicon{color:var(--icon-disable, #a5a5a5)!important;font-size:12px!important}:host ::ng-deep .p-listbox-list-container{flex:1;min-height:0;max-height:none!important;overflow-y:scroll;overflow-x:hidden;padding:8px;margin-right:8px}:host ::ng-deep .p-listbox-list-container::-webkit-scrollbar{width:8px}:host ::ng-deep .p-listbox-list-container::-webkit-scrollbar-track{background:transparent;border-radius:9999px;margin-top:8px;transition:background .2s ease}:host ::ng-deep .p-listbox-list-container::-webkit-scrollbar-thumb{background:transparent;border-radius:9999px;transition:background .2s ease}:host ::ng-deep .p-listbox:hover .p-listbox-list-container::-webkit-scrollbar-track{background:var(--background-grey-light, #f7f7f7)}:host ::ng-deep .p-listbox:hover .p-listbox-list-container::-webkit-scrollbar-thumb{background:var(--background-grey-medium, #b7b7b7)}:host ::ng-deep .p-listbox:hover .p-listbox-list-container::-webkit-scrollbar-thumb:hover{background:var(--icon-neutral-2, #666666)}:host ::ng-deep .p-listbox-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2px}:host ::ng-deep .p-listbox-option{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;cursor:pointer;font-family:Open Sans,system-ui,sans-serif;font-size:14px;font-weight:400;line-height:20px;color:var(--texts-dark, #404040);background:transparent;outline:none;-webkit-user-select:none;user-select:none;transition:background .12s ease,color .12s ease}:host ::ng-deep .p-listbox-option:not([data-p-disabled=true]):hover{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 92%)}:host ::ng-deep .p-listbox-option:not([data-p-disabled=true]):active{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 86%)}:host ::ng-deep .p-listbox:has(.p-listbox-list:focus-visible) .p-listbox-option[data-p-focused=true]:not([data-p-disabled=true]){outline:2px solid var(--background-brand, #00c73d);outline-offset:-2px}:host ::ng-deep .p-listbox-option[data-p-selected=true],:host ::ng-deep .p-listbox-option.p-listbox-option-selected{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 88%);color:color-mix(in srgb,var(--background-brand, #00c73d),#000 30%)}:host ::ng-deep .p-listbox-option[data-p-selected=true]:not([data-p-disabled=true]):hover{background:color-mix(in srgb,var(--background-brand, #00c73d),transparent 84%)}:host ::ng-deep .p-listbox-option[data-p-disabled=true]{cursor:not-allowed;color:var(--texts-light, #a5a5a5);pointer-events:none}:host ::ng-deep .p-listbox-option .p-checkbox{pointer-events:none;flex-shrink:0}:host ::ng-deep .p-listbox-option .p-checkbox-box{width:18px!important;height:18px!important;border-radius:4px!important;border:1.5px solid var(--stroke-default, #a5a5a5)!important;background:#fff!important;box-shadow:none!important;transition:background .12s ease,border-color .12s ease!important}:host ::ng-deep .p-listbox-option:not([data-p-disabled=true]):hover .p-checkbox-box{border-color:var(--background-brand, #00c73d)!important}:host ::ng-deep .p-listbox-option[data-p-selected=true] .p-checkbox-box,:host ::ng-deep .p-listbox-option.p-listbox-option-selected .p-checkbox-box{background:var(--background-brand, #00c73d)!important;border-color:var(--background-brand, #00c73d)!important}:host ::ng-deep .p-listbox-option .p-checkbox-icon{color:#fff!important;width:11px!important;height:11px!important}:host ::ng-deep .p-listbox-option[data-p-disabled=true] .p-checkbox-box{border-color:var(--stroke-grey-light, #d4d4d4)!important;background:#f5f5f5!important}:host ::ng-deep .p-listbox-option-group{padding:8px 12px 4px;cursor:default}.sk-lbox__group-label{font-family:Open Sans,system-ui,sans-serif;font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--texts-medium, #666666)}.sk-lbox__icon{font-size:16px;flex-shrink:0;color:inherit}.sk-lbox__icon--top{margin-top:2px;align-self:flex-start}:host ::ng-deep .p-listbox-option[data-p-disabled=true] .sk-lbox__icon{color:var(--texts-light, #a5a5a5)}.sk-lbox__body{display:flex;flex-direction:column;gap:2px}.sk-lbox__label{font-family:Open Sans,system-ui,sans-serif;font-size:14px;line-height:20px;color:inherit}.sk-lbox__label--bold{font-weight:700}.sk-lbox__description{font-family:Open Sans,system-ui,sans-serif;font-size:12px;line-height:16px;color:var(--texts-medium, #666666)}:host ::ng-deep .p-listbox-option[data-p-selected=true] .sk-lbox__description{color:color-mix(in srgb,var(--background-brand, #00c73d),#666666 60%)}:host ::ng-deep .p-listbox-option[data-p-disabled=true] .sk-lbox__description{color:var(--texts-light, #a5a5a5)}:host ::ng-deep .p-listbox-option:has(.sk-lbox__body){align-items:flex-start}.sk-lbox__empty{display:flex;flex-direction:column;align-items:center;padding:24px 16px;text-align:center;gap:4px}.sk-lbox__empty-icon{font-size:24px;color:var(--texts-light, #a5a5a5);margin-bottom:8px}.sk-lbox__empty-title{margin:0;font-family:Open Sans,system-ui,sans-serif;font-size:14px;font-weight:700;color:var(--texts-dark, #404040)}.sk-lbox__empty-msg{margin:0;font-family:Open Sans,system-ui,sans-serif;font-size:12px;color:var(--texts-medium, #666666)}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], listStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "listStyle", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], filterPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceholder", required: false }] }], group: [{ type: i0.Input, args: [{ isSignal: true, alias: "group", required: false }] }], optionGroupLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupLabel", required: false }] }], optionGroupChildren: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupChildren", required: false }] }], emptyIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyIcon", required: false }] }], emptyTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyTitle", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkMegaMenuComponent {
    orientation = input('horizontal', ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    model = input([
        {
            label: 'Componentes',
            icon: 'pi pi-box',
            items: [
                [
                    { label: 'Form', items: [{ label: 'Input' }, { label: 'Select' }, { label: 'Checkbox' }] },
                    { label: 'Data', items: [{ label: 'Table' }, { label: 'Tree' }, { label: 'Chart' }] },
                ],
                [
                    { label: 'Panel', items: [{ label: 'Card' }, { label: 'Accordion' }, { label: 'Tabs' }] },
                    { label: 'Overlay', items: [{ label: 'Dialog' }, { label: 'Drawer' }, { label: 'Tooltip' }] },
                ],
            ],
        },
        {
            label: 'Documentación',
            icon: 'pi pi-book',
            items: [[
                    { label: 'Guías', items: [{ label: 'Inicio rápido' }, { label: 'Instalación' }] },
                    { label: 'API', items: [{ label: 'Referencia' }, { label: 'Ejemplos' }] },
                ]],
        },
    ], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkMegaMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkMegaMenuComponent, isStandalone: true, selector: "sk-megamenu", inputs: { orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<p-megamenu [model]="model()" [orientation]="orientation()" />`, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: MegaMenu, selector: "p-megaMenu, p-megamenu, p-mega-menu", inputs: ["model", "styleClass", "orientation", "id", "ariaLabel", "ariaLabelledBy", "breakpoint", "scrollHeight", "disabled", "tabindex"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkMegaMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-megamenu', standalone: true, imports: [MegaMenu], template: `<p-megamenu [model]="model()" [orientation]="orientation()" />`, styles: [":host{display:block}\n"] }]
        }], propDecorators: { orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }] } });

class SkMenuComponent {
    model = input([
        { label: 'Archivo', items: [
                { label: 'Nuevo', icon: 'pi pi-plus' },
                { label: 'Abrir', icon: 'pi pi-folder-open' },
                { label: 'Guardar', icon: 'pi pi-save' },
            ] },
        { separator: true },
        { label: 'Editar', items: [
                { label: 'Copiar', icon: 'pi pi-copy' },
                { label: 'Pegar', icon: 'pi pi-file-import' },
            ] },
        { separator: true },
        { label: 'Salir', icon: 'pi pi-sign-out' },
    ], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkMenuComponent, isStandalone: true, selector: "sk-menu", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<p-menu [model]="model()" [popup]="false" />`, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Menu, selector: "p-menu", inputs: ["model", "popup", "style", "styleClass", "autoZIndex", "baseZIndex", "showTransitionOptions", "hideTransitionOptions", "ariaLabel", "ariaLabelledBy", "id", "tabindex", "appendTo", "motionOptions"], outputs: ["onShow", "onHide", "onBlur", "onFocus"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-menu', standalone: true, imports: [Menu], template: `<p-menu [model]="model()" [popup]="false" />`, styles: [":host{display:block}\n"] }]
        }], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }] } });

class SkMenubarComponent {
    model = input([
        { label: 'Inicio', icon: 'pi pi-home' },
        {
            label: 'Mi portafolio', icon: 'pi pi-chart-line',
            items: [
                { label: 'Resumen', icon: 'pi pi-eye' },
                { label: 'Movimientos', icon: 'pi pi-list' },
                { separator: true },
                { label: 'Rentabilidad', icon: 'pi pi-chart-bar' },
            ],
        },
        {
            label: 'Seguros', icon: 'pi pi-shield',
            items: [
                { label: 'Mis pólizas', icon: 'pi pi-file' },
                { label: 'Nueva solicitud', icon: 'pi pi-plus' },
            ],
        },
        { label: 'Soporte', icon: 'pi pi-headphones' },
    ], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkMenubarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkMenubarComponent, isStandalone: true, selector: "sk-menubar", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<p-menubar styleClass="sk-menubar" [model]="model()" />`, isInline: true, styles: [":host{display:block}:host ::ng-deep .sk-menubar.p-menubar{background:var(--background-white, #fff);border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);padding:4px 8px}:host ::ng-deep .sk-menubar .p-menubar-item-link{color:var(--texts-dark, #404040);font-size:14px;font-weight:500;padding:7px 12px;border-radius:var(--bordes-s, 4px);transition:background .15s,color .15s;gap:6px}:host ::ng-deep .sk-menubar .p-menubar-item-link:hover,:host ::ng-deep .sk-menubar .p-menubar-item.p-menubar-item-active>.p-menubar-item-content>.p-menubar-item-link{background:color-mix(in srgb,var(--color-primary, #00c73d),white 90%);color:var(--color-primary, #00c73d)}:host ::ng-deep .sk-menubar .p-menubar-item-icon{color:var(--texts-medium, #888);font-size:14px}:host ::ng-deep .sk-menubar .p-menubar-item-link:hover .p-menubar-item-icon{color:var(--color-primary, #00c73d)}:host ::ng-deep .sk-menubar .p-menubar-submenu-icon{color:var(--texts-medium, #aaa);font-size:11px}:host ::ng-deep .sk-menubar .p-menubar-submenu{background:var(--background-white, #fff);border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);box-shadow:0 4px 16px #0000001a;padding:4px;min-width:168px}:host ::ng-deep .sk-menubar .p-menubar-submenu .p-menubar-item-link{padding:7px 14px;font-size:13px}:host ::ng-deep .sk-menubar .p-menubar-separator{border-top:1px solid var(--stroke-grey-light, #e5e7eb);margin:4px 8px}:host ::ng-deep .sk-menubar .p-menubar-mobile-button{color:var(--texts-dark, #404040);border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);padding:6px 10px}\n"], dependencies: [{ kind: "component", type: Menubar, selector: "p-menubar", inputs: ["model", "styleClass", "autoZIndex", "baseZIndex", "autoDisplay", "autoHide", "breakpoint", "autoHideDelay", "id", "ariaLabel", "ariaLabelledBy"], outputs: ["onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkMenubarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-menubar', standalone: true, imports: [Menubar], template: `<p-menubar styleClass="sk-menubar" [model]="model()" />`, styles: [":host{display:block}:host ::ng-deep .sk-menubar.p-menubar{background:var(--background-white, #fff);border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);padding:4px 8px}:host ::ng-deep .sk-menubar .p-menubar-item-link{color:var(--texts-dark, #404040);font-size:14px;font-weight:500;padding:7px 12px;border-radius:var(--bordes-s, 4px);transition:background .15s,color .15s;gap:6px}:host ::ng-deep .sk-menubar .p-menubar-item-link:hover,:host ::ng-deep .sk-menubar .p-menubar-item.p-menubar-item-active>.p-menubar-item-content>.p-menubar-item-link{background:color-mix(in srgb,var(--color-primary, #00c73d),white 90%);color:var(--color-primary, #00c73d)}:host ::ng-deep .sk-menubar .p-menubar-item-icon{color:var(--texts-medium, #888);font-size:14px}:host ::ng-deep .sk-menubar .p-menubar-item-link:hover .p-menubar-item-icon{color:var(--color-primary, #00c73d)}:host ::ng-deep .sk-menubar .p-menubar-submenu-icon{color:var(--texts-medium, #aaa);font-size:11px}:host ::ng-deep .sk-menubar .p-menubar-submenu{background:var(--background-white, #fff);border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);box-shadow:0 4px 16px #0000001a;padding:4px;min-width:168px}:host ::ng-deep .sk-menubar .p-menubar-submenu .p-menubar-item-link{padding:7px 14px;font-size:13px}:host ::ng-deep .sk-menubar .p-menubar-separator{border-top:1px solid var(--stroke-grey-light, #e5e7eb);margin:4px 8px}:host ::ng-deep .sk-menubar .p-menubar-mobile-button{color:var(--texts-dark, #404040);border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);padding:6px 10px}\n"] }]
        }], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }] } });

class SkMeterGroupComponent {
    value = input([
        { label: 'Primario', value: 35, color: 'var(--accent-1)' },
        { label: 'Informacion', value: 30, color: 'var(--accent-2)' },
        { label: 'Exito', value: 20, color: 'var(--accent-3)' },
        { label: 'Neutro', value: 15, color: 'var(--color-medium)' },
    ], ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    min = input(0, ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    max = input(100, ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkMeterGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkMeterGroupComponent, isStandalone: true, selector: "sk-metergroup", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-metergroup [value]="value()" [min]="min()" [max]="max()" />
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: MeterGroup, selector: "p-meterGroup, p-metergroup, p-meter-group", inputs: ["value", "min", "max", "orientation", "labelPosition", "labelOrientation", "styleClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkMeterGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-metergroup', standalone: true, imports: [MeterGroup], template: `
    <p-metergroup [value]="value()" [min]="min()" [max]="max()" />
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }] } });

let _multiselectUid = 0;
class SkMultiSelectComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    options = input([
        { label: 'Opción A', value: 'a' },
        { label: 'Opción B', value: 'b' },
        { label: 'Opción C', value: 'c' },
        { label: 'Opción D', value: 'd' },
    ], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    optionLabel = input('label', ...(ngDevMode ? [{ debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    optionValue = input('value', ...(ngDevMode ? [{ debugName: "optionValue" }] : /* istanbul ignore next */ []));
    helpText = input('', ...(ngDevMode ? [{ debugName: "helpText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showClear = input(false, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    filter = input(true, { ...(ngDevMode ? { debugName: "filter" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    display = input('comma', ...(ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []));
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    inputId = `sk-multiselect-${_multiselectUid++}`;
    innerControl = new FormControl([], { nonNullable: true });
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    onTouched = () => { };
    sub;
    constructor() {
        this.sub = this.innerControl.valueChanges.subscribe(val => {
            this._onChange(val);
            this.valueChange.emit(val);
        });
        effect(() => {
            this._isDisabled()
                ? this.innerControl.disable({ emitEvent: false })
                : this.innerControl.enable({ emitEvent: false });
        });
    }
    writeValue(val) { this.innerControl.setValue(val ?? [], { emitEvent: false }); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    ngOnDestroy() { this.sub.unsubscribe(); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkMultiSelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkMultiSelectComponent, isStandalone: true, selector: "sk-multiselect", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, display: { classPropertyName: "display", publicName: "display", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkMultiSelectComponent), multi: true }], ngImport: i0, template: "<div\r\n  class=\"sk-multiselect\"\r\n  [class.sk-multiselect--fluid]=\"fluid()\"\r\n  [class.sk-multiselect--invalid]=\"invalid()\"\r\n  [class.sk-multiselect--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-multiselect__floatlabel\">\r\n    <p-multiselect\r\n      [inputId]=\"inputId\"\r\n      [formControl]=\"innerControl\"\r\n      [options]=\"options()\"\r\n      [optionLabel]=\"optionLabel()\"\r\n      [optionValue]=\"optionValue()\"\r\n      [showClear]=\"showClear()\"\r\n      [filter]=\"filter()\"\r\n      [display]=\"display()\"\r\n      [invalid]=\"invalid()\"\r\n      [fluid]=\"fluid()\"\r\n      (onHide)=\"onTouched()\"\r\n      class=\"sk-multiselect__field\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-multiselect__help sk-multiselect__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-multiselect__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-multiselect{display:flex;flex-direction:column;gap:4px}.sk-multiselect__floatlabel,.sk-multiselect--fluid,.sk-multiselect--fluid .sk-multiselect__floatlabel,.sk-multiselect--fluid .sk-multiselect__field{width:100%}::ng-deep .sk-multiselect__field.p-multiselect{width:100%;min-height:var(--size-048, 48px);padding-inline:12px;border-radius:8px}::ng-deep .sk-multiselect__field.p-multiselect .p-multiselect-label{padding-block-start:20px;padding-block-end:6px;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px)}::ng-deep .sk-multiselect__floatlabel label{font-size:14px}::ng-deep .sk-multiselect--invalid .sk-multiselect__field.p-multiselect{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-multiselect--disabled .sk-multiselect__field.p-multiselect{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;cursor:not-allowed}.sk-multiselect__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-multiselect__help--error{color:var(--color-error, #e03430)}\n"], dependencies: [{ kind: "component", type: MultiSelect, selector: "p-multiSelect, p-multiselect, p-multi-select", inputs: ["id", "ariaLabel", "styleClass", "panelStyle", "panelStyleClass", "inputId", "readonly", "group", "filter", "filterPlaceHolder", "filterLocale", "overlayVisible", "tabindex", "dataKey", "ariaLabelledBy", "displaySelectedLabel", "maxSelectedLabels", "selectionLimit", "selectedItemsLabel", "showToggleAll", "emptyFilterMessage", "emptyMessage", "resetFilterOnHide", "dropdownIcon", "chipIcon", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "showHeader", "filterBy", "scrollHeight", "lazy", "virtualScroll", "loading", "virtualScrollItemSize", "loadingIcon", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "autofocusFilter", "display", "autocomplete", "showClear", "autofocus", "placeholder", "options", "filterValue", "selectAll", "focusOnHover", "filterFields", "selectOnFocus", "autoOptionFocus", "highlightOnSelect", "size", "variant", "fluid", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onClear", "onPanelShow", "onPanelHide", "onLazyLoad", "onRemove", "onSelectAllChange"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkMultiSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-multiselect', standalone: true, imports: [MultiSelect, FloatLabel, ReactiveFormsModule], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkMultiSelectComponent), multi: true }], template: "<div\r\n  class=\"sk-multiselect\"\r\n  [class.sk-multiselect--fluid]=\"fluid()\"\r\n  [class.sk-multiselect--invalid]=\"invalid()\"\r\n  [class.sk-multiselect--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-multiselect__floatlabel\">\r\n    <p-multiselect\r\n      [inputId]=\"inputId\"\r\n      [formControl]=\"innerControl\"\r\n      [options]=\"options()\"\r\n      [optionLabel]=\"optionLabel()\"\r\n      [optionValue]=\"optionValue()\"\r\n      [showClear]=\"showClear()\"\r\n      [filter]=\"filter()\"\r\n      [display]=\"display()\"\r\n      [invalid]=\"invalid()\"\r\n      [fluid]=\"fluid()\"\r\n      (onHide)=\"onTouched()\"\r\n      class=\"sk-multiselect__field\"\r\n    />\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-multiselect__help sk-multiselect__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-multiselect__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-multiselect{display:flex;flex-direction:column;gap:4px}.sk-multiselect__floatlabel,.sk-multiselect--fluid,.sk-multiselect--fluid .sk-multiselect__floatlabel,.sk-multiselect--fluid .sk-multiselect__field{width:100%}::ng-deep .sk-multiselect__field.p-multiselect{width:100%;min-height:var(--size-048, 48px);padding-inline:12px;border-radius:8px}::ng-deep .sk-multiselect__field.p-multiselect .p-multiselect-label{padding-block-start:20px;padding-block-end:6px;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px)}::ng-deep .sk-multiselect__floatlabel label{font-size:14px}::ng-deep .sk-multiselect--invalid .sk-multiselect__field.p-multiselect{border-color:var(--color-error, #e03430)!important}::ng-deep .sk-multiselect--disabled .sk-multiselect__field.p-multiselect{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;cursor:not-allowed}.sk-multiselect__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-multiselect__help--error{color:var(--color-error, #e03430)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], helpText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helpText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], display: [{ type: i0.Input, args: [{ isSignal: true, alias: "display", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkOrderListComponent {
    header = input('Prioridades', ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    items = input([
        { name: 'Autenticación', category: 'Seguridad' },
        { name: 'Dashboard', category: 'UI' },
        { name: 'Reportes', category: 'Analytics' },
        { name: 'Notificaciones', category: 'UX' },
        { name: 'Exportar PDF', category: 'Utilidad' },
    ], ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkOrderListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkOrderListComponent, isStandalone: true, selector: "sk-orderlist", inputs: { header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-orderlist [value]="items()" [header]="header()" dataKey="name">
      <ng-template #item let-item>
        <div style="display:flex;align-items:center;gap:8px;padding:4px 0;">
          <i class="pi pi-tag" style="color:var(--p-primary-color,#22c55e);"></i>
          <span style="font-size:14px;font-weight:500;">{{ item.name }}</span>
          <span style="font-size:12px;color:var(--p-surface-500,#6b7280);margin-left:auto;">{{ item.category }}</span>
        </div>
      </ng-template>
    </p-orderlist>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: OrderList, selector: "p-orderList, p-orderlist, p-order-list", inputs: ["header", "styleClass", "tabindex", "ariaLabel", "ariaLabelledBy", "listStyle", "responsive", "filterBy", "filterPlaceholder", "filterLocale", "metaKeySelection", "dragdrop", "controlsPosition", "ariaFilterLabel", "filterMatchMode", "breakpoint", "stripedRows", "disabled", "trackBy", "scrollHeight", "autoOptionFocus", "dataKey", "selection", "value", "buttonProps", "moveUpButtonProps", "moveTopButtonProps", "moveDownButtonProps", "moveBottomButtonProps"], outputs: ["selectionChange", "onReorder", "onSelectionChange", "onFilterEvent", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkOrderListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-orderlist', standalone: true, imports: [OrderList], template: `
    <p-orderlist [value]="items()" [header]="header()" dataKey="name">
      <ng-template #item let-item>
        <div style="display:flex;align-items:center;gap:8px;padding:4px 0;">
          <i class="pi pi-tag" style="color:var(--p-primary-color,#22c55e);"></i>
          <span style="font-size:14px;font-weight:500;">{{ item.name }}</span>
          <span style="font-size:12px;color:var(--p-surface-500,#6b7280);margin-left:auto;">{{ item.category }}</span>
        </div>
      </ng-template>
    </p-orderlist>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }] } });

class SkOrgChartComponent {
    collapsible = input(true, ...(ngDevMode ? [{ debugName: "collapsible" }] : /* istanbul ignore next */ []));
    nodes = input([
        { label: 'CEO', data: { role: 'Dirección' }, expanded: true, children: [
                { label: 'CTO', data: { role: 'Tecnología' }, expanded: true, children: [
                        { label: 'Dev Lead', data: { role: 'Desarrollo' } },
                        { label: 'QA Lead', data: { role: 'Calidad' } },
                    ] },
                { label: 'CFO', data: { role: 'Finanzas' }, children: [
                        { label: 'Contabilidad', data: { role: 'Gestión' } },
                    ] },
            ] },
    ], ...(ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkOrgChartComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkOrgChartComponent, isStandalone: true, selector: "sk-orgchart", inputs: { collapsible: { classPropertyName: "collapsible", publicName: "collapsible", isSignal: true, isRequired: false, transformFunction: null }, nodes: { classPropertyName: "nodes", publicName: "nodes", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-organizationchart [value]="nodes()" [collapsible]="collapsible()">
      <ng-template #default let-node>
        <div style="padding:6px 12px;text-align:center;">
          <div style="font-weight:600;font-size:13px;">{{ node.label }}</div>
          @if (node.data?.role) {
            <div style="font-size:11px;color:var(--p-surface-500,#6b7280);">{{ node.data.role }}</div>
          }
        </div>
      </ng-template>
    </p-organizationchart>
  `, isInline: true, styles: [":host{display:block;overflow-x:auto}\n"], dependencies: [{ kind: "component", type: OrganizationChart, selector: "p-organizationChart, p-organization-chart, p-organizationchart", inputs: ["value", "styleClass", "selectionMode", "collapsible", "preserveSpace", "selection"], outputs: ["selectionChange", "onNodeSelect", "onNodeUnselect", "onNodeExpand", "onNodeCollapse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkOrgChartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-orgchart', standalone: true, imports: [OrganizationChart], template: `
    <p-organizationchart [value]="nodes()" [collapsible]="collapsible()">
      <ng-template #default let-node>
        <div style="padding:6px 12px;text-align:center;">
          <div style="font-weight:600;font-size:13px;">{{ node.label }}</div>
          @if (node.data?.role) {
            <div style="font-size:11px;color:var(--p-surface-500,#6b7280);">{{ node.data.role }}</div>
          }
        </div>
      </ng-template>
    </p-organizationchart>
  `, styles: [":host{display:block;overflow-x:auto}\n"] }]
        }], propDecorators: { collapsible: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsible", required: false }] }], nodes: [{ type: i0.Input, args: [{ isSignal: true, alias: "nodes", required: false }] }] } });

class SkOverlayBadgeComponent {
    value = input('', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    severity = input('danger', ...(ngDevMode ? [{ debugName: "severity" }] : /* istanbul ignore next */ []));
    badgeSize = input('large', ...(ngDevMode ? [{ debugName: "badgeSize" }] : /* istanbul ignore next */ []));
    badgeDisabled = input(false, { ...(ngDevMode ? { debugName: "badgeDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    icon = input('bell', ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkOverlayBadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkOverlayBadgeComponent, isStandalone: true, selector: "sk-overlaybadge", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, severity: { classPropertyName: "severity", publicName: "severity", isSignal: true, isRequired: false, transformFunction: null }, badgeSize: { classPropertyName: "badgeSize", publicName: "badgeSize", isSignal: true, isRequired: false, transformFunction: null }, badgeDisabled: { classPropertyName: "badgeDisabled", publicName: "badgeDisabled", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-overlaybadge
      [value]="value()"
      [severity]="severity()"
      [badgeSize]="badgeSize()"
      [badgeDisabled]="badgeDisabled()"
    >
      @if (icon()) {
        <i [class]="'pi pi-' + icon()" style="font-size:2rem;color:var(--texts-medium,#666)"></i>
      }
      <ng-content />
    </p-overlaybadge>
  `, isInline: true, styles: [":host{display:inline-flex;align-items:center;justify-content:center}\n"], dependencies: [{ kind: "component", type: OverlayBadge, selector: "p-overlayBadge, p-overlay-badge, p-overlaybadge", inputs: ["styleClass", "style", "badgeSize", "severity", "value", "badgeDisabled", "size"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkOverlayBadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-overlaybadge', standalone: true, imports: [OverlayBadge], template: `
    <p-overlaybadge
      [value]="value()"
      [severity]="severity()"
      [badgeSize]="badgeSize()"
      [badgeDisabled]="badgeDisabled()"
    >
      @if (icon()) {
        <i [class]="'pi pi-' + icon()" style="font-size:2rem;color:var(--texts-medium,#666)"></i>
      }
      <ng-content />
    </p-overlaybadge>
  `, styles: [":host{display:inline-flex;align-items:center;justify-content:center}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], severity: [{ type: i0.Input, args: [{ isSignal: true, alias: "severity", required: false }] }], badgeSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "badgeSize", required: false }] }], badgeDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "badgeDisabled", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }] } });

class SkPaginatorComponent {
    first = input(0, ...(ngDevMode ? [{ debugName: "first" }] : /* istanbul ignore next */ []));
    rows = input(10, ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    totalRecords = input(120, ...(ngDevMode ? [{ debugName: "totalRecords" }] : /* istanbul ignore next */ []));
    rowsPerPageOptions = input([5, 10, 25, 50], ...(ngDevMode ? [{ debugName: "rowsPerPageOptions" }] : /* istanbul ignore next */ []));
    showFirstLastIcon = input(true, { ...(ngDevMode ? { debugName: "showFirstLastIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showCurrentPageReport = input(true, { ...(ngDevMode ? { debugName: "showCurrentPageReport" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    pageChange = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPaginatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkPaginatorComponent, isStandalone: true, selector: "sk-paginator", inputs: { first: { classPropertyName: "first", publicName: "first", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, totalRecords: { classPropertyName: "totalRecords", publicName: "totalRecords", isSignal: true, isRequired: false, transformFunction: null }, rowsPerPageOptions: { classPropertyName: "rowsPerPageOptions", publicName: "rowsPerPageOptions", isSignal: true, isRequired: false, transformFunction: null }, showFirstLastIcon: { classPropertyName: "showFirstLastIcon", publicName: "showFirstLastIcon", isSignal: true, isRequired: false, transformFunction: null }, showCurrentPageReport: { classPropertyName: "showCurrentPageReport", publicName: "showCurrentPageReport", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pageChange: "pageChange" }, ngImport: i0, template: `
    <p-paginator
      [first]="first()"
      [rows]="rows()"
      [totalRecords]="totalRecords()"
      [rowsPerPageOptions]="rowsPerPageOptions()"
      [showFirstLastIcon]="showFirstLastIcon()"
      [showCurrentPageReport]="showCurrentPageReport()"
      (onPageChange)="pageChange.emit($event)"
    />
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Paginator, selector: "p-paginator", inputs: ["pageLinkSize", "styleClass", "alwaysShow", "dropdownAppendTo", "templateLeft", "templateRight", "dropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showFirstLastIcon", "totalRecords", "rows", "rowsPerPageOptions", "showJumpToPageDropdown", "showJumpToPageInput", "jumpToPageItemTemplate", "showPageLinks", "locale", "dropdownItemTemplate", "first", "appendTo"], outputs: ["onPageChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPaginatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-paginator', standalone: true, imports: [Paginator], template: `
    <p-paginator
      [first]="first()"
      [rows]="rows()"
      [totalRecords]="totalRecords()"
      [rowsPerPageOptions]="rowsPerPageOptions()"
      [showFirstLastIcon]="showFirstLastIcon()"
      [showCurrentPageReport]="showCurrentPageReport()"
      (onPageChange)="pageChange.emit($event)"
    />
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { first: [{ type: i0.Input, args: [{ isSignal: true, alias: "first", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], totalRecords: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalRecords", required: false }] }], rowsPerPageOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowsPerPageOptions", required: false }] }], showFirstLastIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFirstLastIcon", required: false }] }], showCurrentPageReport: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCurrentPageReport", required: false }] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }] } });

class SkPanelComponent {
    header = input('', ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    content = input('', ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    toggleable = input(false, { ...(ngDevMode ? { debugName: "toggleable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    collapsed = input(false, { ...(ngDevMode ? { debugName: "collapsed" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    beforeToggle = output();
    afterToggle = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkPanelComponent, isStandalone: true, selector: "sk-panel", inputs: { header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: false, transformFunction: null }, toggleable: { classPropertyName: "toggleable", publicName: "toggleable", isSignal: true, isRequired: false, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { beforeToggle: "beforeToggle", afterToggle: "afterToggle" }, ngImport: i0, template: `
    <p-panel
      styleClass="sk-panel"
      [header]="header()"
      [toggleable]="toggleable()"
      [collapsed]="collapsed()"
      (onBeforeToggle)="beforeToggle.emit($event)"
      (onAfterToggle)="afterToggle.emit($event)"
    >
      @if (content()) {
        <p class="sk-panel__text">{{ content() }}</p>
      }
      <ng-content />
    </p-panel>
  `, isInline: true, styles: [":host{display:block}:host ::ng-deep .sk-panel.p-panel{border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);overflow:hidden}:host ::ng-deep .sk-panel .p-panel-header{background:var(--background-grey-light, #f7f7f7);border-bottom:1px solid var(--stroke-grey-light, #e5e7eb);padding:13px 16px}:host ::ng-deep .sk-panel .p-panel-title{font-size:14px;font-weight:600;color:var(--texts-dark, #404040)}:host ::ng-deep .sk-panel .p-panel-toggle-button{color:var(--color-primary, #00c73d);width:28px;height:28px;border-radius:50%;transition:background .15s}:host ::ng-deep .sk-panel .p-panel-toggle-button:hover{background:color-mix(in srgb,var(--color-primary, #00c73d),white 88%)}:host ::ng-deep .sk-panel .p-panel-content{padding:14px 16px}.sk-panel__text{margin:0;font-size:14px;color:var(--texts-medium, #666);line-height:1.6}\n"], dependencies: [{ kind: "component", type: Panel, selector: "p-panel", inputs: ["id", "toggleable", "header", "collapsed", "styleClass", "iconPos", "showHeader", "toggler", "transitionOptions", "toggleButtonProps", "motionOptions"], outputs: ["collapsedChange", "onBeforeToggle", "onAfterToggle"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-panel', standalone: true, imports: [Panel], template: `
    <p-panel
      styleClass="sk-panel"
      [header]="header()"
      [toggleable]="toggleable()"
      [collapsed]="collapsed()"
      (onBeforeToggle)="beforeToggle.emit($event)"
      (onAfterToggle)="afterToggle.emit($event)"
    >
      @if (content()) {
        <p class="sk-panel__text">{{ content() }}</p>
      }
      <ng-content />
    </p-panel>
  `, styles: [":host{display:block}:host ::ng-deep .sk-panel.p-panel{border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);overflow:hidden}:host ::ng-deep .sk-panel .p-panel-header{background:var(--background-grey-light, #f7f7f7);border-bottom:1px solid var(--stroke-grey-light, #e5e7eb);padding:13px 16px}:host ::ng-deep .sk-panel .p-panel-title{font-size:14px;font-weight:600;color:var(--texts-dark, #404040)}:host ::ng-deep .sk-panel .p-panel-toggle-button{color:var(--color-primary, #00c73d);width:28px;height:28px;border-radius:50%;transition:background .15s}:host ::ng-deep .sk-panel .p-panel-toggle-button:hover{background:color-mix(in srgb,var(--color-primary, #00c73d),white 88%)}:host ::ng-deep .sk-panel .p-panel-content{padding:14px 16px}.sk-panel__text{margin:0;font-size:14px;color:var(--texts-medium, #666);line-height:1.6}\n"] }]
        }], propDecorators: { header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: false }] }], toggleable: [{ type: i0.Input, args: [{ isSignal: true, alias: "toggleable", required: false }] }], collapsed: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsed", required: false }] }], beforeToggle: [{ type: i0.Output, args: ["beforeToggle"] }], afterToggle: [{ type: i0.Output, args: ["afterToggle"] }] } });

class SkPanelMenuComponent {
    multiple = input(false, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    model = input([
        { label: 'Gestión', icon: 'pi pi-cog', expanded: true, items: [
                { label: 'Usuarios', icon: 'pi pi-users' },
                { label: 'Roles', icon: 'pi pi-shield' },
                { label: 'Permisos', icon: 'pi pi-lock' },
            ] },
        { label: 'Reportes', icon: 'pi pi-chart-bar', items: [
                { label: 'Ventas', icon: 'pi pi-dollar' },
                { label: 'Actividad', icon: 'pi pi-clock' },
                { label: 'Exportar', icon: 'pi pi-download' },
            ] },
        { label: 'Configuración', icon: 'pi pi-sliders-v', items: [
                { label: 'General', icon: 'pi pi-home' },
                { label: 'Seguridad', icon: 'pi pi-shield' },
            ] },
    ], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPanelMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkPanelMenuComponent, isStandalone: true, selector: "sk-panelmenu", inputs: { multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<p-panelmenu [model]="model()" [multiple]="multiple()" />`, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: PanelMenu, selector: "p-panelMenu, p-panelmenu, p-panel-menu", inputs: ["model", "styleClass", "multiple", "transitionOptions", "motionOptions", "id", "tabindex"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPanelMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-panelmenu', standalone: true, imports: [PanelMenu], template: `<p-panelmenu [model]="model()" [multiple]="multiple()" />`, styles: [":host{display:block}\n"] }]
        }], propDecorators: { multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }] } });

let _passwordUid = 0;
class SkPasswordComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    value = input('', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    helpText = input('', ...(ngDevMode ? [{ debugName: "helpText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    feedback = input(true, { ...(ngDevMode ? { debugName: "feedback" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    toggleMask = input(true, { ...(ngDevMode ? { debugName: "toggleMask" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    inputId = `sk-password-${_passwordUid++}`;
    _value = signal('', ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    constructor() {
        effect(() => this._value.set(this.value()));
    }
    _onTouched = () => { };
    handleInput(val) {
        const v = val ?? '';
        this._value.set(v);
        this._onChange(v);
        this.valueChange.emit(v);
    }
    handleBlur() { this._onTouched(); }
    writeValue(val) { this._value.set(val ?? ''); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this._onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPasswordComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkPasswordComponent, isStandalone: true, selector: "sk-password", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, feedback: { classPropertyName: "feedback", publicName: "feedback", isSignal: true, isRequired: false, transformFunction: null }, toggleMask: { classPropertyName: "toggleMask", publicName: "toggleMask", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkPasswordComponent), multi: true }], ngImport: i0, template: "<div\r\n  class=\"sk-password\"\r\n  [class.sk-password--fluid]=\"fluid()\"\r\n  [class.sk-password--invalid]=\"invalid()\"\r\n  [class.sk-password--disabled]=\"_isDisabled()\"\r\n>\r\n  <div class=\"sk-password__box\">\r\n    <p-floatlabel variant=\"in\">\r\n      <p-password\r\n        [inputId]=\"inputId\"\r\n        [ngModel]=\"_value()\"\r\n        (ngModelChange)=\"handleInput($event)\"\r\n        [feedback]=\"feedback()\"\r\n        [toggleMask]=\"toggleMask()\"\r\n        [disabled]=\"_isDisabled()\"\r\n        [invalid]=\"invalid()\"\r\n        [fluid]=\"fluid()\"\r\n        [attr.placeholder]=\"placeholder() || null\"\r\n        (onBlur)=\"handleBlur()\"\r\n        class=\"sk-password__field\"\r\n      />\r\n      <label [for]=\"inputId\">{{ label() }}</label>\r\n    </p-floatlabel>\r\n  </div>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-password__help sk-password__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-password__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-password{display:flex;flex-direction:column;gap:4px}.sk-password--fluid{width:100%}.sk-password__box{border:1px solid var(--stroke-grey-light, #dddddd);border-radius:8px;background:var(--background-principal, #ffffff);width:100%;min-height:var(--size-048, 48px);transition:border-color .15s ease}::ng-deep .sk-password__box p-floatlabel,::ng-deep .sk-password__box .p-floatlabel{display:block!important;width:100%!important;border:none!important;background:transparent!important;box-shadow:none!important}::ng-deep .sk-password__box .p-password{width:100%;display:flex}::ng-deep .sk-password__box .p-password-input{width:100%;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline:12px;border:none!important;background:transparent!important;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-dark, #404040);box-sizing:border-box;box-shadow:none!important;outline:none}::ng-deep .sk-password__box label{font-size:14px}.sk-password:not(.sk-password--disabled):not(.sk-password--invalid):hover .sk-password__box{border-color:var(--texts-dark, #404040)}.sk-password:not(.sk-password--disabled):not(.sk-password--invalid):focus-within .sk-password__box{border-color:var(--stroke-brand, #00c73d)}.sk-password--invalid .sk-password__box{border-color:var(--color-error, #e03430)}.sk-password--disabled .sk-password__box{background:var(--background-grey-light, #f7f7f7);border-color:var(--stroke-grey-light, #dddddd)}::ng-deep .sk-password--disabled .sk-password__box .p-password-input{color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-password__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-password__help--error{color:var(--color-error, #e03430)}\n"], dependencies: [{ kind: "component", type: Password, selector: "p-password", inputs: ["ariaLabel", "ariaLabelledBy", "label", "promptLabel", "mediumRegex", "strongRegex", "weakLabel", "mediumLabel", "maxLength", "strongLabel", "inputId", "feedback", "toggleMask", "inputStyleClass", "styleClass", "inputStyle", "showTransitionOptions", "hideTransitionOptions", "autocomplete", "placeholder", "showClear", "autofocus", "tabindex", "appendTo", "motionOptions", "overlayOptions"], outputs: ["onFocus", "onBlur", "onClear"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPasswordComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-password', standalone: true, imports: [Password, FloatLabel, FormsModule], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkPasswordComponent), multi: true }], template: "<div\r\n  class=\"sk-password\"\r\n  [class.sk-password--fluid]=\"fluid()\"\r\n  [class.sk-password--invalid]=\"invalid()\"\r\n  [class.sk-password--disabled]=\"_isDisabled()\"\r\n>\r\n  <div class=\"sk-password__box\">\r\n    <p-floatlabel variant=\"in\">\r\n      <p-password\r\n        [inputId]=\"inputId\"\r\n        [ngModel]=\"_value()\"\r\n        (ngModelChange)=\"handleInput($event)\"\r\n        [feedback]=\"feedback()\"\r\n        [toggleMask]=\"toggleMask()\"\r\n        [disabled]=\"_isDisabled()\"\r\n        [invalid]=\"invalid()\"\r\n        [fluid]=\"fluid()\"\r\n        [attr.placeholder]=\"placeholder() || null\"\r\n        (onBlur)=\"handleBlur()\"\r\n        class=\"sk-password__field\"\r\n      />\r\n      <label [for]=\"inputId\">{{ label() }}</label>\r\n    </p-floatlabel>\r\n  </div>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-password__help sk-password__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-password__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-password{display:flex;flex-direction:column;gap:4px}.sk-password--fluid{width:100%}.sk-password__box{border:1px solid var(--stroke-grey-light, #dddddd);border-radius:8px;background:var(--background-principal, #ffffff);width:100%;min-height:var(--size-048, 48px);transition:border-color .15s ease}::ng-deep .sk-password__box p-floatlabel,::ng-deep .sk-password__box .p-floatlabel{display:block!important;width:100%!important;border:none!important;background:transparent!important;box-shadow:none!important}::ng-deep .sk-password__box .p-password{width:100%;display:flex}::ng-deep .sk-password__box .p-password-input{width:100%;min-height:var(--size-048, 48px);padding-block-start:20px!important;padding-block-end:6px!important;padding-inline:12px;border:none!important;background:transparent!important;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-dark, #404040);box-sizing:border-box;box-shadow:none!important;outline:none}::ng-deep .sk-password__box label{font-size:14px}.sk-password:not(.sk-password--disabled):not(.sk-password--invalid):hover .sk-password__box{border-color:var(--texts-dark, #404040)}.sk-password:not(.sk-password--disabled):not(.sk-password--invalid):focus-within .sk-password__box{border-color:var(--stroke-brand, #00c73d)}.sk-password--invalid .sk-password__box{border-color:var(--color-error, #e03430)}.sk-password--disabled .sk-password__box{background:var(--background-grey-light, #f7f7f7);border-color:var(--stroke-grey-light, #dddddd)}::ng-deep .sk-password--disabled .sk-password__box .p-password-input{color:var(--texts-medium, #666666)!important;cursor:not-allowed}.sk-password__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-password__help--error{color:var(--color-error, #e03430)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], helpText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helpText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], feedback: [{ type: i0.Input, args: [{ isSignal: true, alias: "feedback", required: false }] }], toggleMask: [{ type: i0.Input, args: [{ isSignal: true, alias: "toggleMask", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkPickListComponent {
    sourceHeader = input('Disponibles', ...(ngDevMode ? [{ debugName: "sourceHeader" }] : /* istanbul ignore next */ []));
    targetHeader = input('Seleccionadas', ...(ngDevMode ? [{ debugName: "targetHeader" }] : /* istanbul ignore next */ []));
    source = input([
        { name: 'Bogotá' },
        { name: 'Medellín' },
        { name: 'Cali' },
        { name: 'Barranquilla' },
        { name: 'Cartagena' },
    ], ...(ngDevMode ? [{ debugName: "source" }] : /* istanbul ignore next */ []));
    target = input([], ...(ngDevMode ? [{ debugName: "target" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPickListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkPickListComponent, isStandalone: true, selector: "sk-picklist", inputs: { sourceHeader: { classPropertyName: "sourceHeader", publicName: "sourceHeader", isSignal: true, isRequired: false, transformFunction: null }, targetHeader: { classPropertyName: "targetHeader", publicName: "targetHeader", isSignal: true, isRequired: false, transformFunction: null }, source: { classPropertyName: "source", publicName: "source", isSignal: true, isRequired: false, transformFunction: null }, target: { classPropertyName: "target", publicName: "target", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-picklist [source]="source()" [target]="target()" [sourceHeader]="sourceHeader()" [targetHeader]="targetHeader()" breakpoint="768px">
      <ng-template #item let-item>
        <div style="display:flex;align-items:center;gap:8px;padding:4px 0;">
          <i class="pi pi-map-marker" style="color:var(--p-primary-color,#22c55e);"></i>
          <span style="font-size:14px;font-weight:500;">{{ item.name }}</span>
        </div>
      </ng-template>
    </p-picklist>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: PickList, selector: "p-pickList, p-picklist, p-pick-list", inputs: ["hostName", "source", "target", "dataKey", "sourceHeader", "tabindex", "rightButtonAriaLabel", "leftButtonAriaLabel", "allRightButtonAriaLabel", "allLeftButtonAriaLabel", "upButtonAriaLabel", "downButtonAriaLabel", "topButtonAriaLabel", "bottomButtonAriaLabel", "sourceAriaLabel", "targetAriaLabel", "targetHeader", "responsive", "filterBy", "filterLocale", "trackBy", "sourceTrackBy", "targetTrackBy", "showSourceFilter", "showTargetFilter", "metaKeySelection", "dragdrop", "style", "styleClass", "sourceStyle", "targetStyle", "showSourceControls", "showTargetControls", "sourceFilterPlaceholder", "targetFilterPlaceholder", "disabled", "sourceOptionDisabled", "targetOptionDisabled", "ariaSourceFilterLabel", "ariaTargetFilterLabel", "filterMatchMode", "stripedRows", "keepSelection", "scrollHeight", "autoOptionFocus", "buttonProps", "moveUpButtonProps", "moveTopButtonProps", "moveDownButtonProps", "moveBottomButtonProps", "moveToTargetProps", "moveAllToTargetProps", "moveToSourceProps", "moveAllToSourceProps", "breakpoint"], outputs: ["sourceChange", "targetChange", "onMoveToSource", "onMoveAllToSource", "onMoveAllToTarget", "onMoveToTarget", "onSourceReorder", "onTargetReorder", "onSourceSelect", "onTargetSelect", "onSourceFilter", "onTargetFilter", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPickListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-picklist', standalone: true, imports: [PickList], template: `
    <p-picklist [source]="source()" [target]="target()" [sourceHeader]="sourceHeader()" [targetHeader]="targetHeader()" breakpoint="768px">
      <ng-template #item let-item>
        <div style="display:flex;align-items:center;gap:8px;padding:4px 0;">
          <i class="pi pi-map-marker" style="color:var(--p-primary-color,#22c55e);"></i>
          <span style="font-size:14px;font-weight:500;">{{ item.name }}</span>
        </div>
      </ng-template>
    </p-picklist>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { sourceHeader: [{ type: i0.Input, args: [{ isSignal: true, alias: "sourceHeader", required: false }] }], targetHeader: [{ type: i0.Input, args: [{ isSignal: true, alias: "targetHeader", required: false }] }], source: [{ type: i0.Input, args: [{ isSignal: true, alias: "source", required: false }] }], target: [{ type: i0.Input, args: [{ isSignal: true, alias: "target", required: false }] }] } });

class SkPopoverComponent {
    op;
    triggerLabel = input('Más información', ...(ngDevMode ? [{ debugName: "triggerLabel" }] : /* istanbul ignore next */ []));
    triggerIcon = input('info-circle', ...(ngDevMode ? [{ debugName: "triggerIcon" }] : /* istanbul ignore next */ []));
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    content = input('Información contextual adicional sobre el elemento seleccionado.', ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    dismissable = input(true, { ...(ngDevMode ? { debugName: "dismissable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    shown = output();
    hidden = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPopoverComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkPopoverComponent, isStandalone: true, selector: "sk-popover", inputs: { triggerLabel: { classPropertyName: "triggerLabel", publicName: "triggerLabel", isSignal: true, isRequired: false, transformFunction: null }, triggerIcon: { classPropertyName: "triggerIcon", publicName: "triggerIcon", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: false, transformFunction: null }, dismissable: { classPropertyName: "dismissable", publicName: "dismissable", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { shown: "shown", hidden: "hidden" }, viewQueries: [{ propertyName: "op", first: true, predicate: ["op"], descendants: true }], ngImport: i0, template: `
    <p-button
      [label]="triggerLabel()"
      [icon]="triggerIcon() ? 'pi pi-' + triggerIcon() : ''"
      severity="secondary"
      (onClick)="op.toggle($event)"
    />
    <p-popover #op [dismissable]="dismissable()" (onShow)="shown.emit()" (onHide)="hidden.emit()">
      <div class="sk-popover__body">
        @if (title()) {
          <p class="sk-popover__title">{{ title() }}</p>
        }
        @if (content()) {
          <p class="sk-popover__text">{{ content() }}</p>
        }
        <ng-content />
      </div>
    </p-popover>
  `, isInline: true, styles: [":host{display:inline-block}.sk-popover__body{padding:4px 2px;max-width:280px}.sk-popover__title{margin:0 0 6px;font-weight:600;font-size:13px;color:var(--texts-dark, #404040)}.sk-popover__text{margin:0;font-size:13px;line-height:1.5;color:var(--texts-medium, #666)}\n"], dependencies: [{ kind: "component", type: Popover, selector: "p-popover", inputs: ["ariaLabel", "ariaLabelledBy", "dismissable", "style", "styleClass", "appendTo", "autoZIndex", "ariaCloseLabel", "baseZIndex", "focusOnShow", "showTransitionOptions", "hideTransitionOptions", "motionOptions"], outputs: ["onShow", "onHide"] }, { kind: "component", type: Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkPopoverComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-popover', standalone: true, imports: [Popover, Button], template: `
    <p-button
      [label]="triggerLabel()"
      [icon]="triggerIcon() ? 'pi pi-' + triggerIcon() : ''"
      severity="secondary"
      (onClick)="op.toggle($event)"
    />
    <p-popover #op [dismissable]="dismissable()" (onShow)="shown.emit()" (onHide)="hidden.emit()">
      <div class="sk-popover__body">
        @if (title()) {
          <p class="sk-popover__title">{{ title() }}</p>
        }
        @if (content()) {
          <p class="sk-popover__text">{{ content() }}</p>
        }
        <ng-content />
      </div>
    </p-popover>
  `, styles: [":host{display:inline-block}.sk-popover__body{padding:4px 2px;max-width:280px}.sk-popover__title{margin:0 0 6px;font-weight:600;font-size:13px;color:var(--texts-dark, #404040)}.sk-popover__text{margin:0;font-size:13px;line-height:1.5;color:var(--texts-medium, #666)}\n"] }]
        }], propDecorators: { op: [{
                type: ViewChild,
                args: ['op']
            }], triggerLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "triggerLabel", required: false }] }], triggerIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "triggerIcon", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: false }] }], dismissable: [{ type: i0.Input, args: [{ isSignal: true, alias: "dismissable", required: false }] }], shown: [{ type: i0.Output, args: ["shown"] }], hidden: [{ type: i0.Output, args: ["hidden"] }] } });

class SkProgressBarComponent {
    value = input(70, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    mode = input('determinate', ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    showValue = input(true, { ...(ngDevMode ? { debugName: "showValue" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    labelLeft = input('', ...(ngDevMode ? [{ debugName: "labelLeft" }] : /* istanbul ignore next */ []));
    labelRight = input('', ...(ngDevMode ? [{ debugName: "labelRight" }] : /* istanbul ignore next */ []));
    dynamic = input(false, { ...(ngDevMode ? { debugName: "dynamic" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _dynValue = signal(0, ...(ngDevMode ? [{ debugName: "_dynValue" }] : /* istanbul ignore next */ []));
    _timer;
    displayValue = computed(() => this.dynamic() ? this._dynValue() : this.value(), ...(ngDevMode ? [{ debugName: "displayValue" }] : /* istanbul ignore next */ []));
    constructor() {
        inject(DestroyRef).onDestroy(() => this._stop());
        effect(() => {
            if (this.dynamic()) {
                this._start();
            }
            else {
                this._stop();
            }
        });
    }
    _start() {
        this._stop();
        this._dynValue.set(0);
        this._timer = setInterval(() => {
            const v = this._dynValue();
            if (v >= 100) {
                this._stop();
            }
            else {
                this._dynValue.set(v + 1);
            }
        }, 80);
    }
    _stop() {
        if (this._timer != null) {
            clearInterval(this._timer);
            this._timer = undefined;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkProgressBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkProgressBarComponent, isStandalone: true, selector: "sk-progressbar", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, showValue: { classPropertyName: "showValue", publicName: "showValue", isSignal: true, isRequired: false, transformFunction: null }, labelLeft: { classPropertyName: "labelLeft", publicName: "labelLeft", isSignal: true, isRequired: false, transformFunction: null }, labelRight: { classPropertyName: "labelRight", publicName: "labelRight", isSignal: true, isRequired: false, transformFunction: null }, dynamic: { classPropertyName: "dynamic", publicName: "dynamic", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.sk-pb--slim": "!showValue()" } }, ngImport: i0, template: `
    <p-progressbar
      [value]="displayValue()"
      [mode]="mode()"
      [showValue]="showValue()"
    />
    @if (labelLeft() || labelRight()) {
      <div class="sk-pb__footer">
        <span class="sk-pb__label">{{ labelLeft() }}</span>
        <span class="sk-pb__label">{{ labelRight() }}</span>
      </div>
    }
  `, isInline: true, styles: [":host{display:block;min-width:404px}.sk-pb__footer{display:flex;justify-content:space-between;align-items:center;margin-top:4px}.sk-pb__label{font-family:var(--body, \"Open Sans\", sans-serif);font-size:var(--label-medium-size, .875rem);font-weight:var(--weight-medium, 500);color:var(--texts-dark, #404040);line-height:1.375rem}:host ::ng-deep .p-progressbar{height:16px!important;border-radius:var(--radius-full, 9999px)!important;background:var(--background-grey-light, #f7f7f7)!important}:host.sk-pb--slim ::ng-deep .p-progressbar{height:8px!important}:host ::ng-deep .p-progressbar .p-progressbar-value{background:var(--estilos-degrade)!important;border-radius:var(--radius-full, 9999px)!important;transition:width .3s ease!important}:host ::ng-deep .p-progressbar .p-progressbar-label{font-family:var(--caption-body-3-bold-font, var(--body, \"Open Sans\", sans-serif))!important;font-size:var(--caption-body-3-bold-size, var(--size-s, .75rem))!important;font-weight:var(--caption-body-3-bold-weight, var(--weight-bold, 700))!important;line-height:16px!important;color:var(--texts-white, #ffffff)!important}\n"], dependencies: [{ kind: "component", type: ProgressBar, selector: "p-progressBar, p-progressbar, p-progress-bar", inputs: ["value", "showValue", "styleClass", "valueStyleClass", "unit", "mode", "color"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkProgressBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-progressbar', standalone: true, imports: [ProgressBar], host: { '[class.sk-pb--slim]': '!showValue()' }, template: `
    <p-progressbar
      [value]="displayValue()"
      [mode]="mode()"
      [showValue]="showValue()"
    />
    @if (labelLeft() || labelRight()) {
      <div class="sk-pb__footer">
        <span class="sk-pb__label">{{ labelLeft() }}</span>
        <span class="sk-pb__label">{{ labelRight() }}</span>
      </div>
    }
  `, styles: [":host{display:block;min-width:404px}.sk-pb__footer{display:flex;justify-content:space-between;align-items:center;margin-top:4px}.sk-pb__label{font-family:var(--body, \"Open Sans\", sans-serif);font-size:var(--label-medium-size, .875rem);font-weight:var(--weight-medium, 500);color:var(--texts-dark, #404040);line-height:1.375rem}:host ::ng-deep .p-progressbar{height:16px!important;border-radius:var(--radius-full, 9999px)!important;background:var(--background-grey-light, #f7f7f7)!important}:host.sk-pb--slim ::ng-deep .p-progressbar{height:8px!important}:host ::ng-deep .p-progressbar .p-progressbar-value{background:var(--estilos-degrade)!important;border-radius:var(--radius-full, 9999px)!important;transition:width .3s ease!important}:host ::ng-deep .p-progressbar .p-progressbar-label{font-family:var(--caption-body-3-bold-font, var(--body, \"Open Sans\", sans-serif))!important;font-size:var(--caption-body-3-bold-size, var(--size-s, .75rem))!important;font-weight:var(--caption-body-3-bold-weight, var(--weight-bold, 700))!important;line-height:16px!important;color:var(--texts-white, #ffffff)!important}\n"] }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], showValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "showValue", required: false }] }], labelLeft: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelLeft", required: false }] }], labelRight: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelRight", required: false }] }], dynamic: [{ type: i0.Input, args: [{ isSignal: true, alias: "dynamic", required: false }] }] } });

class SkProgressSpinnerComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkProgressSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkProgressSpinnerComponent, isStandalone: true, selector: "sk-progressspinner", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <!-- Gradient definition — mismo degradado que --estilos-degrade -->
    <svg width="0" height="0" style="position:absolute;overflow:hidden;">
      <defs>
        <linearGradient id="sk-spinner-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%"   stop-color="var(--primary-00, #00c73d)" />
          <stop offset="100%" stop-color="var(--secondarygreencomplementary-00, #8fe000)" />
        </linearGradient>
      </defs>
    </svg>

    <div class="sk-spinner__wrapper">
      <p-progressspinner
        [style]="{ width: '48px', height: '48px' }"
        strokeWidth="4"
        animationDuration=".8s"
      />
      @if (label()) {
        <span class="sk-spinner__label">{{ label() }}</span>
      }
    </div>
  `, isInline: true, styles: [":host{display:flex;justify-content:center}.sk-spinner__wrapper{display:flex;flex-direction:column;align-items:center;gap:12px}:host ::ng-deep .p-progressspinner-circle{stroke:url(#sk-spinner-gradient)!important}.sk-spinner__label{font-family:var(--body, \"Open Sans\", sans-serif);font-size:var(--caption-body-3-size, var(--size-s, .75rem));font-weight:var(--weight-medium, 500);color:var(--texts-medium, #666666);line-height:1.25rem}\n"], dependencies: [{ kind: "component", type: ProgressSpinner, selector: "p-progressSpinner, p-progress-spinner, p-progressspinner", inputs: ["styleClass", "strokeWidth", "fill", "animationDuration", "ariaLabel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkProgressSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-progressspinner', standalone: true, imports: [ProgressSpinner], template: `
    <!-- Gradient definition — mismo degradado que --estilos-degrade -->
    <svg width="0" height="0" style="position:absolute;overflow:hidden;">
      <defs>
        <linearGradient id="sk-spinner-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%"   stop-color="var(--primary-00, #00c73d)" />
          <stop offset="100%" stop-color="var(--secondarygreencomplementary-00, #8fe000)" />
        </linearGradient>
      </defs>
    </svg>

    <div class="sk-spinner__wrapper">
      <p-progressspinner
        [style]="{ width: '48px', height: '48px' }"
        strokeWidth="4"
        animationDuration=".8s"
      />
      @if (label()) {
        <span class="sk-spinner__label">{{ label() }}</span>
      }
    </div>
  `, styles: [":host{display:flex;justify-content:center}.sk-spinner__wrapper{display:flex;flex-direction:column;align-items:center;gap:12px}:host ::ng-deep .p-progressspinner-circle{stroke:url(#sk-spinner-gradient)!important}.sk-spinner__label{font-family:var(--body, \"Open Sans\", sans-serif);font-size:var(--caption-body-3-size, var(--size-s, .75rem));font-weight:var(--weight-medium, 500);color:var(--texts-medium, #666666);line-height:1.25rem}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

class SkRadioComponent {
    label = input('Opción', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    value = input('', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    name = input('sk-radio', ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showLabel = input(true, { ...(ngDevMode ? { debugName: "showLabel" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _uid = Math.random().toString(36).slice(2, 9);
    valueChange = output();
    _groupValue = signal(null, ...(ngDevMode ? [{ debugName: "_groupValue" }] : /* istanbul ignore next */ []));
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _checked = computed(() => this._groupValue() === this.value(), ...(ngDevMode ? [{ debugName: "_checked" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    onTouched = () => { };
    _onSelect() {
        if (this._isDisabled())
            return;
        this._groupValue.set(this.value());
        this._onChange(this.value());
        this.valueChange.emit(this.value());
        this.onTouched();
    }
    writeValue(val) { this._groupValue.set(val ?? null); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkRadioComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkRadioComponent, isStandalone: true, selector: "sk-radio", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, showLabel: { classPropertyName: "showLabel", publicName: "showLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkRadioComponent), multi: true }], ngImport: i0, template: `
    <div class="sk-radio-item"
      [class.sk-radio--disabled]="_isDisabled()"
      [class.sk-radio--invalid]="invalid()"
    >
      <p-radiobutton
        [inputId]="_uid"
        [name]="name()"
        [value]="value()"
        [ngModel]="_groupValue()"
        (ngModelChange)="_onSelect()"
        [disabled]="_isDisabled()"
      />
      @if (showLabel()) {
        <label class="sk-radio-label" [for]="_uid">{{ label() }}</label>
      }
    </div>
  `, isInline: true, styles: [":host{display:inline-flex}.sk-radio-item{display:flex;align-items:center;gap:8px}.sk-radio-label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;font-weight:500;color:var(--texts-dark, #404040);cursor:pointer}::ng-deep .p-radiobutton{width:18px!important;height:18px!important;align-items:center!important;justify-content:center!important}::ng-deep .p-radiobutton .p-radiobutton-box{display:flex!important;align-items:center!important;justify-content:center!important;position:relative!important;width:18px!important;height:18px!important;border-radius:50%!important;border:1.5px solid var(--stroke-grey-medium, #c5c5c5)!important;background:var(--background-principal, #ffffff)!important;box-shadow:none!important}::ng-deep .p-radiobutton.p-radiobutton-checked .p-radiobutton-box{border-color:var(--stroke-grey-medium, #c5c5c5)!important;background:var(--background-principal, #ffffff)!important}::ng-deep .p-radiobutton .p-radiobutton-icon{width:10px!important;height:10px!important;border-radius:50%!important;background:var(--background-success-dark, #16d727)!important;margin:0!important}::ng-deep .p-radiobutton.p-radiobutton-checked .p-radiobutton-icon{position:absolute!important;top:50%!important;left:50%!important;transform:translate(-50%,-50%)!important}.sk-radio--disabled .sk-radio-label{color:var(--texts-medium, #666666);cursor:not-allowed}.sk-radio--disabled ::ng-deep .p-radiobutton .p-radiobutton-box{background:var(--background-principal, #ffffff)!important;border-color:var(--stroke-grey-medium, #c5c5c5)!important}.sk-radio--disabled ::ng-deep .p-radiobutton .p-radiobutton-icon{background:var(--background-grey-medium, #b7b7b7)!important}.sk-radio--invalid ::ng-deep .p-radiobutton .p-radiobutton-box{background:var(--background-principal, #ffffff)!important;border-color:var(--stroke-error-dark, #e03430)!important}.sk-radio--invalid ::ng-deep .p-radiobutton .p-radiobutton-icon{background:var(--background-error-dark, #e03430)!important}\n"], dependencies: [{ kind: "component", type: RadioButton, selector: "p-radioButton, p-radiobutton, p-radio-button", inputs: ["value", "tabindex", "inputId", "ariaLabelledBy", "ariaLabel", "styleClass", "autofocus", "binary", "variant", "size"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkRadioComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-radio', standalone: true, imports: [RadioButton, FormsModule], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkRadioComponent), multi: true }], template: `
    <div class="sk-radio-item"
      [class.sk-radio--disabled]="_isDisabled()"
      [class.sk-radio--invalid]="invalid()"
    >
      <p-radiobutton
        [inputId]="_uid"
        [name]="name()"
        [value]="value()"
        [ngModel]="_groupValue()"
        (ngModelChange)="_onSelect()"
        [disabled]="_isDisabled()"
      />
      @if (showLabel()) {
        <label class="sk-radio-label" [for]="_uid">{{ label() }}</label>
      }
    </div>
  `, styles: [":host{display:inline-flex}.sk-radio-item{display:flex;align-items:center;gap:8px}.sk-radio-label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;font-weight:500;color:var(--texts-dark, #404040);cursor:pointer}::ng-deep .p-radiobutton{width:18px!important;height:18px!important;align-items:center!important;justify-content:center!important}::ng-deep .p-radiobutton .p-radiobutton-box{display:flex!important;align-items:center!important;justify-content:center!important;position:relative!important;width:18px!important;height:18px!important;border-radius:50%!important;border:1.5px solid var(--stroke-grey-medium, #c5c5c5)!important;background:var(--background-principal, #ffffff)!important;box-shadow:none!important}::ng-deep .p-radiobutton.p-radiobutton-checked .p-radiobutton-box{border-color:var(--stroke-grey-medium, #c5c5c5)!important;background:var(--background-principal, #ffffff)!important}::ng-deep .p-radiobutton .p-radiobutton-icon{width:10px!important;height:10px!important;border-radius:50%!important;background:var(--background-success-dark, #16d727)!important;margin:0!important}::ng-deep .p-radiobutton.p-radiobutton-checked .p-radiobutton-icon{position:absolute!important;top:50%!important;left:50%!important;transform:translate(-50%,-50%)!important}.sk-radio--disabled .sk-radio-label{color:var(--texts-medium, #666666);cursor:not-allowed}.sk-radio--disabled ::ng-deep .p-radiobutton .p-radiobutton-box{background:var(--background-principal, #ffffff)!important;border-color:var(--stroke-grey-medium, #c5c5c5)!important}.sk-radio--disabled ::ng-deep .p-radiobutton .p-radiobutton-icon{background:var(--background-grey-medium, #b7b7b7)!important}.sk-radio--invalid ::ng-deep .p-radiobutton .p-radiobutton-box{background:var(--background-principal, #ffffff)!important;border-color:var(--stroke-error-dark, #e03430)!important}.sk-radio--invalid ::ng-deep .p-radiobutton .p-radiobutton-icon{background:var(--background-error-dark, #e03430)!important}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], showLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "showLabel", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkRadiogroupComponent {
    options = input([], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    name = input('sk-radiogroup', ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    layout = input('vertical', ...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    valueChange = output();
    _uid = Math.random().toString(36).slice(2, 9);
    _selected = signal(null, ...(ngDevMode ? [{ debugName: "_selected" }] : /* istanbul ignore next */ []));
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    onTouched = () => { };
    _onSelect(val) {
        if (this._isDisabled())
            return;
        this._selected.set(val);
        this._onChange(val);
        this.valueChange.emit(val);
        this.onTouched();
    }
    writeValue(val) { this._selected.set(val ?? null); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkRadiogroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkRadiogroupComponent, isStandalone: true, selector: "sk-radiogroup", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [
            { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkRadiogroupComponent), multi: true },
        ], ngImport: i0, template: `
    <div
      class="sk-radiogroup"
      [class.sk-radiogroup--horizontal]="layout() === 'horizontal'"
      [class.sk-radiogroup--invalid]="invalid()"
    >
      @for (opt of options(); track opt.value; let i = $index) {
        <div
          class="sk-radiogroup-item"
          [class.sk-radiogroup-item--disabled]="_isDisabled() || !!opt.disabled"
        >
          <p-radiobutton
            [inputId]="_uid + '-' + i"
            [name]="name()"
            [value]="opt.value"
            [ngModel]="_selected()"
            (ngModelChange)="_onSelect(opt.value)"
            [disabled]="_isDisabled() || !!opt.disabled"
          />
          <label class="sk-radiogroup-label" [for]="_uid + '-' + i">{{ opt.label }}</label>
        </div>
      }
    </div>
  `, isInline: true, styles: [":host{display:block}.sk-radiogroup{display:flex;flex-direction:column;gap:12px}.sk-radiogroup--horizontal{flex-direction:row;flex-wrap:wrap;gap:16px}.sk-radiogroup-item{display:flex;align-items:center;gap:8px}.sk-radiogroup-label{font-family:var(--body, \"Open Sans\", sans-serif);font-size:14px;font-weight:500;color:var(--texts-dark, #404040);cursor:pointer}.sk-radiogroup-item--disabled .sk-radiogroup-label{color:var(--texts-medium, #666666);cursor:not-allowed}::ng-deep .p-radiobutton{width:18px!important;height:18px!important;align-items:center!important;justify-content:center!important}::ng-deep .p-radiobutton .p-radiobutton-box{display:flex!important;align-items:center!important;justify-content:center!important;position:relative!important;width:18px!important;height:18px!important;border-radius:50%!important;border:1.5px solid var(--stroke-grey-medium, #c5c5c5)!important;background:var(--background-principal, #ffffff)!important;box-shadow:none!important}::ng-deep .p-radiobutton.p-radiobutton-checked .p-radiobutton-box{border-color:var(--stroke-grey-medium, #c5c5c5)!important;background:var(--background-principal, #ffffff)!important}::ng-deep .p-radiobutton .p-radiobutton-icon{width:10px!important;height:10px!important;border-radius:50%!important;background:var(--background-success-dark, #16d727)!important;margin:0!important}::ng-deep .p-radiobutton.p-radiobutton-checked .p-radiobutton-icon{position:absolute!important;top:50%!important;left:50%!important;transform:translate(-50%,-50%)!important}.sk-radiogroup-item--disabled ::ng-deep .p-radiobutton .p-radiobutton-icon{background:var(--background-grey-medium, #b7b7b7)!important}.sk-radiogroup--invalid ::ng-deep .p-radiobutton .p-radiobutton-box{border-color:var(--stroke-error-dark, #e03430)!important}.sk-radiogroup--invalid ::ng-deep .p-radiobutton.p-radiobutton-checked .p-radiobutton-icon{background:var(--background-error-dark, #e03430)!important}\n"], dependencies: [{ kind: "component", type: RadioButton, selector: "p-radioButton, p-radiobutton, p-radio-button", inputs: ["value", "tabindex", "inputId", "ariaLabelledBy", "ariaLabel", "styleClass", "autofocus", "binary", "variant", "size"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkRadiogroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-radiogroup', standalone: true, imports: [RadioButton, FormsModule], providers: [
                        { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkRadiogroupComponent), multi: true },
                    ], template: `
    <div
      class="sk-radiogroup"
      [class.sk-radiogroup--horizontal]="layout() === 'horizontal'"
      [class.sk-radiogroup--invalid]="invalid()"
    >
      @for (opt of options(); track opt.value; let i = $index) {
        <div
          class="sk-radiogroup-item"
          [class.sk-radiogroup-item--disabled]="_isDisabled() || !!opt.disabled"
        >
          <p-radiobutton
            [inputId]="_uid + '-' + i"
            [name]="name()"
            [value]="opt.value"
            [ngModel]="_selected()"
            (ngModelChange)="_onSelect(opt.value)"
            [disabled]="_isDisabled() || !!opt.disabled"
          />
          <label class="sk-radiogroup-label" [for]="_uid + '-' + i">{{ opt.label }}</label>
        </div>
      }
    </div>
  `, styles: [":host{display:block}.sk-radiogroup{display:flex;flex-direction:column;gap:12px}.sk-radiogroup--horizontal{flex-direction:row;flex-wrap:wrap;gap:16px}.sk-radiogroup-item{display:flex;align-items:center;gap:8px}.sk-radiogroup-label{font-family:var(--body, \"Open Sans\", sans-serif);font-size:14px;font-weight:500;color:var(--texts-dark, #404040);cursor:pointer}.sk-radiogroup-item--disabled .sk-radiogroup-label{color:var(--texts-medium, #666666);cursor:not-allowed}::ng-deep .p-radiobutton{width:18px!important;height:18px!important;align-items:center!important;justify-content:center!important}::ng-deep .p-radiobutton .p-radiobutton-box{display:flex!important;align-items:center!important;justify-content:center!important;position:relative!important;width:18px!important;height:18px!important;border-radius:50%!important;border:1.5px solid var(--stroke-grey-medium, #c5c5c5)!important;background:var(--background-principal, #ffffff)!important;box-shadow:none!important}::ng-deep .p-radiobutton.p-radiobutton-checked .p-radiobutton-box{border-color:var(--stroke-grey-medium, #c5c5c5)!important;background:var(--background-principal, #ffffff)!important}::ng-deep .p-radiobutton .p-radiobutton-icon{width:10px!important;height:10px!important;border-radius:50%!important;background:var(--background-success-dark, #16d727)!important;margin:0!important}::ng-deep .p-radiobutton.p-radiobutton-checked .p-radiobutton-icon{position:absolute!important;top:50%!important;left:50%!important;transform:translate(-50%,-50%)!important}.sk-radiogroup-item--disabled ::ng-deep .p-radiobutton .p-radiobutton-icon{background:var(--background-grey-medium, #b7b7b7)!important}.sk-radiogroup--invalid ::ng-deep .p-radiobutton .p-radiobutton-box{border-color:var(--stroke-error-dark, #e03430)!important}.sk-radiogroup--invalid ::ng-deep .p-radiobutton.p-radiobutton-checked .p-radiobutton-icon{background:var(--background-error-dark, #e03430)!important}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkRatingComponent {
    value = input(0, { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    stars = input(5, { ...(ngDevMode ? { debugName: "stars" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    showValue = input(false, { ...(ngDevMode ? { debugName: "showValue" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    rated = output();
    _value = 0;
    ngOnChanges(changes) {
        if (changes['value']) {
            this._value = this.value();
        }
    }
    onRate(event) {
        this.rated.emit(event);
        this.valueChange.emit(this._value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkRatingComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkRatingComponent, isStandalone: true, selector: "sk-rating", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, stars: { classPropertyName: "stars", publicName: "stars", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, showValue: { classPropertyName: "showValue", publicName: "showValue", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange", rated: "rated" }, usesOnChanges: true, ngImport: i0, template: `
    <div class="sk-rating" [class.sk-rating--disabled]="disabled()">
      @if (label()) {
        <span class="sk-rating__label">{{ label() }}</span>
      }
      <p-rating
        [(ngModel)]="_value"
        [stars]="stars()"
        [readonly]="readonly() || disabled()"
        (onRate)="onRate($event)"
        styleClass="sk-rating__stars"
      />
      @if (showValue()) {
        <span class="sk-rating__value">{{ _value }} / {{ stars() }}</span>
      }
    </div>
  `, isInline: true, styles: [":host{display:inline-flex}.sk-rating{display:inline-flex;align-items:center;gap:10px}.sk-rating--disabled{opacity:.5;pointer-events:none}.sk-rating__label{font-size:13px;font-weight:600;color:var(--texts-dark, #404040)}.sk-rating__value{font-size:12px;color:var(--texts-medium, #888);min-width:36px}:host ::ng-deep .sk-rating__stars .p-rating-option-active .p-rating-icon{color:var(--color-primary, #00c73d)}:host ::ng-deep .sk-rating__stars .p-rating-option:not(.p-rating-option-active) .p-rating-icon{color:var(--stroke-grey-medium, #cbd5e1)}:host ::ng-deep .sk-rating__stars .p-rating-option:hover .p-rating-icon{color:color-mix(in srgb,var(--color-primary, #00c73d),white 30%)}:host ::ng-deep .sk-rating__stars .p-rating{gap:4px}\n"], dependencies: [{ kind: "component", type: Rating, selector: "p-rating", inputs: ["readonly", "stars", "iconOnClass", "iconOnStyle", "iconOffClass", "iconOffStyle", "autofocus"], outputs: ["onRate", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkRatingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-rating', standalone: true, imports: [Rating, FormsModule], template: `
    <div class="sk-rating" [class.sk-rating--disabled]="disabled()">
      @if (label()) {
        <span class="sk-rating__label">{{ label() }}</span>
      }
      <p-rating
        [(ngModel)]="_value"
        [stars]="stars()"
        [readonly]="readonly() || disabled()"
        (onRate)="onRate($event)"
        styleClass="sk-rating__stars"
      />
      @if (showValue()) {
        <span class="sk-rating__value">{{ _value }} / {{ stars() }}</span>
      }
    </div>
  `, styles: [":host{display:inline-flex}.sk-rating{display:inline-flex;align-items:center;gap:10px}.sk-rating--disabled{opacity:.5;pointer-events:none}.sk-rating__label{font-size:13px;font-weight:600;color:var(--texts-dark, #404040)}.sk-rating__value{font-size:12px;color:var(--texts-medium, #888);min-width:36px}:host ::ng-deep .sk-rating__stars .p-rating-option-active .p-rating-icon{color:var(--color-primary, #00c73d)}:host ::ng-deep .sk-rating__stars .p-rating-option:not(.p-rating-option-active) .p-rating-icon{color:var(--stroke-grey-medium, #cbd5e1)}:host ::ng-deep .sk-rating__stars .p-rating-option:hover .p-rating-icon{color:color-mix(in srgb,var(--color-primary, #00c73d),white 30%)}:host ::ng-deep .sk-rating__stars .p-rating{gap:4px}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], stars: [{ type: i0.Input, args: [{ isSignal: true, alias: "stars", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], showValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "showValue", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], rated: [{ type: i0.Output, args: ["rated"] }] } });

class SkScrollPanelComponent {
    size = input('medium', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    width = input('300px', ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    height = input('200px', ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    step = input(5, ...(ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []));
    demoLines = Array.from({ length: 20 }, (_, i) => i + 1);
    scrollStyleClass = computed(() => `sk-scrollpanel--${this.size()}`, ...(ngDevMode ? [{ debugName: "scrollStyleClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkScrollPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkScrollPanelComponent, isStandalone: true, selector: "sk-scrollpanel", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<p-scrollpanel\r\n      [style]=\"{ width: width(), height: height() }\"\r\n      [styleClass]=\"scrollStyleClass()\"\r\n      [step]=\"step()\"\r\n    >\r\n      @for (i of demoLines; track i) {\r\n        <p class=\"sk-scrollpanel__line\">\r\n          L\u00EDnea {{ i }}: Contenido de ejemplo para visualizar el scroll personalizado de Skandia.\r\n        </p>\r\n      }\r\n    </p-scrollpanel>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-scrollpanel__line{margin:0 0 12px;font-size:13px;color:var(--texts-medium, #666666);white-space:nowrap}:host ::ng-deep .p-scrollpanel-bar{background:var(--background-grey-medium, #b7b7b7)!important;border-radius:9999px!important;opacity:1!important;z-index:2;transition:background .15s ease!important}:host ::ng-deep .p-scrollpanel-bar:hover{background:var(--icon-neutral-2, #666666)!important}:host ::ng-deep p-scrollpanel.sk-scrollpanel--small:before,:host ::ng-deep p-scrollpanel.sk-scrollpanel--medium:before{content:\"\";position:absolute;right:0;top:0;bottom:0;background:var(--background-grey-light, #f7f7f7);border-radius:9999px;pointer-events:none;z-index:1}:host ::ng-deep p-scrollpanel.sk-scrollpanel--small:before{width:4px}:host ::ng-deep p-scrollpanel.sk-scrollpanel--medium:before{width:8px}:host ::ng-deep p-scrollpanel.sk-scrollpanel--small:after,:host ::ng-deep p-scrollpanel.sk-scrollpanel--medium:after{content:\"\";position:absolute;left:0;right:0;bottom:0;background:var(--background-grey-light, #f7f7f7);border-radius:9999px;pointer-events:none;z-index:1}:host ::ng-deep p-scrollpanel.sk-scrollpanel--small:after{height:4px}:host ::ng-deep p-scrollpanel.sk-scrollpanel--medium:after{height:8px}:host ::ng-deep .sk-scrollpanel--small .p-scrollpanel-bar-y{width:4px!important}:host ::ng-deep .sk-scrollpanel--small .p-scrollpanel-bar-x{height:4px!important}:host ::ng-deep .sk-scrollpanel--medium .p-scrollpanel-bar-y{width:8px!important}:host ::ng-deep .sk-scrollpanel--medium .p-scrollpanel-bar-x{height:8px!important}\n"], dependencies: [{ kind: "component", type: ScrollPanel, selector: "p-scroll-panel, p-scrollPanel, p-scrollpanel", inputs: ["styleClass", "step"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkScrollPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-scrollpanel', standalone: true, imports: [ScrollPanel], template: "<p-scrollpanel\r\n      [style]=\"{ width: width(), height: height() }\"\r\n      [styleClass]=\"scrollStyleClass()\"\r\n      [step]=\"step()\"\r\n    >\r\n      @for (i of demoLines; track i) {\r\n        <p class=\"sk-scrollpanel__line\">\r\n          L\u00EDnea {{ i }}: Contenido de ejemplo para visualizar el scroll personalizado de Skandia.\r\n        </p>\r\n      }\r\n    </p-scrollpanel>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-scrollpanel__line{margin:0 0 12px;font-size:13px;color:var(--texts-medium, #666666);white-space:nowrap}:host ::ng-deep .p-scrollpanel-bar{background:var(--background-grey-medium, #b7b7b7)!important;border-radius:9999px!important;opacity:1!important;z-index:2;transition:background .15s ease!important}:host ::ng-deep .p-scrollpanel-bar:hover{background:var(--icon-neutral-2, #666666)!important}:host ::ng-deep p-scrollpanel.sk-scrollpanel--small:before,:host ::ng-deep p-scrollpanel.sk-scrollpanel--medium:before{content:\"\";position:absolute;right:0;top:0;bottom:0;background:var(--background-grey-light, #f7f7f7);border-radius:9999px;pointer-events:none;z-index:1}:host ::ng-deep p-scrollpanel.sk-scrollpanel--small:before{width:4px}:host ::ng-deep p-scrollpanel.sk-scrollpanel--medium:before{width:8px}:host ::ng-deep p-scrollpanel.sk-scrollpanel--small:after,:host ::ng-deep p-scrollpanel.sk-scrollpanel--medium:after{content:\"\";position:absolute;left:0;right:0;bottom:0;background:var(--background-grey-light, #f7f7f7);border-radius:9999px;pointer-events:none;z-index:1}:host ::ng-deep p-scrollpanel.sk-scrollpanel--small:after{height:4px}:host ::ng-deep p-scrollpanel.sk-scrollpanel--medium:after{height:8px}:host ::ng-deep .sk-scrollpanel--small .p-scrollpanel-bar-y{width:4px!important}:host ::ng-deep .sk-scrollpanel--small .p-scrollpanel-bar-x{height:4px!important}:host ::ng-deep .sk-scrollpanel--medium .p-scrollpanel-bar-y{width:8px!important}:host ::ng-deep .sk-scrollpanel--medium .p-scrollpanel-bar-x{height:8px!important}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], step: [{ type: i0.Input, args: [{ isSignal: true, alias: "step", required: false }] }] } });

class SkScrollTopComponent {
    threshold = input(200, ...(ngDevMode ? [{ debugName: "threshold" }] : /* istanbul ignore next */ []));
    behavior = input('smooth', ...(ngDevMode ? [{ debugName: "behavior" }] : /* istanbul ignore next */ []));
    icon = input('pi pi-arrow-up', ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    lines = Array.from({ length: 15 }, (_, i) => i + 1);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkScrollTopComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkScrollTopComponent, isStandalone: true, selector: "sk-scrolltop", inputs: { threshold: { classPropertyName: "threshold", publicName: "threshold", isSignal: true, isRequired: false, transformFunction: null }, behavior: { classPropertyName: "behavior", publicName: "behavior", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div style="position:relative;overflow:auto;height:200px;border:1px solid var(--p-surface-200,#e5e7eb);border-radius:8px;padding:16px;">
      @for (i of lines; track i) {
        <p style="margin:0 0 12px;font-size:13px;color:var(--p-surface-600,#4b5563);">Línea {{ i }}: Haz scroll hacia abajo para ver el botón de volver arriba.</p>
      }
      <p-scrolltop target="parent" [threshold]="threshold()" [behavior]="behavior()" [icon]="icon()" />
    </div>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: ScrollTop, selector: "p-scrollTop, p-scrolltop, p-scroll-top", inputs: ["styleClass", "style", "target", "threshold", "icon", "behavior", "showTransitionOptions", "hideTransitionOptions", "motionOptions", "buttonAriaLabel", "buttonProps"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkScrollTopComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-scrolltop', standalone: true, imports: [ScrollTop], template: `
    <div style="position:relative;overflow:auto;height:200px;border:1px solid var(--p-surface-200,#e5e7eb);border-radius:8px;padding:16px;">
      @for (i of lines; track i) {
        <p style="margin:0 0 12px;font-size:13px;color:var(--p-surface-600,#4b5563);">Línea {{ i }}: Haz scroll hacia abajo para ver el botón de volver arriba.</p>
      }
      <p-scrolltop target="parent" [threshold]="threshold()" [behavior]="behavior()" [icon]="icon()" />
    </div>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { threshold: [{ type: i0.Input, args: [{ isSignal: true, alias: "threshold", required: false }] }], behavior: [{ type: i0.Input, args: [{ isSignal: true, alias: "behavior", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }] } });

class SkSelectButtonComponent {
    options = input([
        { label: 'Diario', value: 'diario' },
        { label: 'Semanal', value: 'semanal' },
        { label: 'Mensual', value: 'mensual' },
    ], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    optionLabel = input('label', ...(ngDevMode ? [{ debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    optionValue = input('value', ...(ngDevMode ? [{ debugName: "optionValue" }] : /* istanbul ignore next */ []));
    multiple = input(false, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    value = 'diario';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSelectButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkSelectButtonComponent, isStandalone: true, selector: "sk-selectbutton", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <p-selectbutton
      [(ngModel)]="value"
      [options]="options()"
      [optionLabel]="optionLabel()"
      [optionValue]="optionValue()"
      [multiple]="multiple()"
      [disabled]="disabled()"
      (onChange)="valueChange.emit($event)"
    />
  `, isInline: true, styles: [":host{display:inline-flex}\n"], dependencies: [{ kind: "component", type: SelectButton, selector: "p-selectButton, p-selectbutton, p-select-button", inputs: ["options", "optionLabel", "optionValue", "optionDisabled", "unselectable", "tabindex", "multiple", "allowEmpty", "styleClass", "ariaLabelledBy", "dataKey", "autofocus", "size", "fluid"], outputs: ["onOptionClick", "onChange"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSelectButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-selectbutton', standalone: true, imports: [SelectButton, FormsModule], template: `
    <p-selectbutton
      [(ngModel)]="value"
      [options]="options()"
      [optionLabel]="optionLabel()"
      [optionValue]="optionValue()"
      [multiple]="multiple()"
      [disabled]="disabled()"
      (onChange)="valueChange.emit($event)"
    />
  `, styles: [":host{display:inline-flex}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkSkeletonComponent {
    shape = input('rectangle', ...(ngDevMode ? [{ debugName: "shape" }] : /* istanbul ignore next */ []));
    width = input('100%', ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    height = input('1rem', ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    borderRadius = input('8px', ...(ngDevMode ? [{ debugName: "borderRadius" }] : /* istanbul ignore next */ []));
    animation = input('wave', ...(ngDevMode ? [{ debugName: "animation" }] : /* istanbul ignore next */ []));
    count = input(1, { ...(ngDevMode ? { debugName: "count" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    _pShape = computed(() => this.shape() === 'circle' ? 'circle' : 'rectangle', ...(ngDevMode ? [{ debugName: "_pShape" }] : /* istanbul ignore next */ []));
    _borderRadius = computed(() => {
        switch (this.shape()) {
            case 'circle': return '50%';
            case 'square': return '0';
            case 'rectangle': return '0';
            case 'rounded': return this.borderRadius();
            default: return this.borderRadius();
        }
    }, ...(ngDevMode ? [{ debugName: "_borderRadius" }] : /* istanbul ignore next */ []));
    _items = computed(() => Array.from({ length: Math.max(1, this.count()) }, (_, i) => i), ...(ngDevMode ? [{ debugName: "_items" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkSkeletonComponent, isStandalone: true, selector: "sk-skeleton", inputs: { shape: { classPropertyName: "shape", publicName: "shape", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, borderRadius: { classPropertyName: "borderRadius", publicName: "borderRadius", isSignal: true, isRequired: false, transformFunction: null }, animation: { classPropertyName: "animation", publicName: "animation", isSignal: true, isRequired: false, transformFunction: null }, count: { classPropertyName: "count", publicName: "count", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div [class.sk-skeleton-stack]="count() > 1">
      @for (i of _items(); track i) {
        <p-skeleton
          [shape]="_pShape()"
          [width]="width()"
          [height]="height()"
          [borderRadius]="_borderRadius()"
          [animation]="animation()"
        />
      }
    </div>
  `, isInline: true, styles: [":host{display:block}.sk-skeleton-stack{display:flex;flex-direction:column;gap:var(--spacing-xs, 8px)}:host ::ng-deep .p-skeleton{background:var(--background-grey-light)!important}\n"], dependencies: [{ kind: "component", type: Skeleton, selector: "p-skeleton", inputs: ["styleClass", "shape", "animation", "borderRadius", "size", "width", "height"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSkeletonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-skeleton', standalone: true, imports: [Skeleton], template: `
    <div [class.sk-skeleton-stack]="count() > 1">
      @for (i of _items(); track i) {
        <p-skeleton
          [shape]="_pShape()"
          [width]="width()"
          [height]="height()"
          [borderRadius]="_borderRadius()"
          [animation]="animation()"
        />
      }
    </div>
  `, styles: [":host{display:block}.sk-skeleton-stack{display:flex;flex-direction:column;gap:var(--spacing-xs, 8px)}:host ::ng-deep .p-skeleton{background:var(--background-grey-light)!important}\n"] }]
        }], propDecorators: { shape: [{ type: i0.Input, args: [{ isSignal: true, alias: "shape", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], borderRadius: [{ type: i0.Input, args: [{ isSignal: true, alias: "borderRadius", required: false }] }], animation: [{ type: i0.Input, args: [{ isSignal: true, alias: "animation", required: false }] }], count: [{ type: i0.Input, args: [{ isSignal: true, alias: "count", required: false }] }] } });

class SkSliderComponent {
    min = input(0, ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    max = input(100, ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    step = input(1, ...(ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    orientation = input('horizontal', ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    range = input(false, { ...(ngDevMode ? { debugName: "range" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    value = 50;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSliderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkSliderComponent, isStandalone: true, selector: "sk-slider", inputs: { min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, range: { classPropertyName: "range", publicName: "range", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <p-slider
      [(ngModel)]="value"
      [min]="min()"
      [max]="max()"
      [step]="step()"
      [disabled]="disabled()"
      [orientation]="orientation()"
      [range]="range()"
      [style]="orientation() === 'vertical' ? { height: '200px' } : {}"
      (onChange)="valueChange.emit($event)"
    />
  `, isInline: true, styles: [":host{display:block;width:100%;padding:0 8px}\n"], dependencies: [{ kind: "component", type: Slider, selector: "p-slider", inputs: ["animate", "min", "max", "orientation", "step", "range", "styleClass", "ariaLabel", "ariaLabelledBy", "tabindex", "autofocus"], outputs: ["onChange", "onSlideEnd"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSliderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-slider', standalone: true, imports: [Slider, FormsModule], template: `
    <p-slider
      [(ngModel)]="value"
      [min]="min()"
      [max]="max()"
      [step]="step()"
      [disabled]="disabled()"
      [orientation]="orientation()"
      [range]="range()"
      [style]="orientation() === 'vertical' ? { height: '200px' } : {}"
      (onChange)="valueChange.emit($event)"
    />
  `, styles: [":host{display:block;width:100%;padding:0 8px}\n"] }]
        }], propDecorators: { min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], step: [{ type: i0.Input, args: [{ isSignal: true, alias: "step", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], range: [{ type: i0.Input, args: [{ isSignal: true, alias: "range", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkSpeedDialComponent {
    model = input([
        { label: 'Agregar', icon: 'pi pi-plus', command: () => { } },
        { label: 'Editar', icon: 'pi pi-pencil', command: () => { } },
        { label: 'Compartir', icon: 'pi pi-share-alt', command: () => { } },
        { label: 'Eliminar', icon: 'pi pi-trash', command: () => { } },
    ], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    direction = input('up', ...(ngDevMode ? [{ debugName: "direction" }] : /* istanbul ignore next */ []));
    type = input('linear', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    radius = input(80, ...(ngDevMode ? [{ debugName: "radius" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSpeedDialComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkSpeedDialComponent, isStandalone: true, selector: "sk-speeddial", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, direction: { classPropertyName: "direction", publicName: "direction", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, radius: { classPropertyName: "radius", publicName: "radius", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div style="position:relative; height:200px; display:flex; align-items:flex-end; justify-content:flex-start; padding:16px;">
      <p-speeddial
        [model]="model()"
        [direction]="direction()"
        [type]="type()"
        [disabled]="disabled()"
        [radius]="radius()"
      />
    </div>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: SpeedDial, selector: "p-speeddial, p-speedDial, p-speed-dial", inputs: ["id", "model", "visible", "style", "className", "direction", "transitionDelay", "type", "radius", "mask", "disabled", "hideOnClickOutside", "buttonStyle", "buttonClassName", "maskStyle", "maskClassName", "showIcon", "hideIcon", "rotateAnimation", "ariaLabel", "ariaLabelledBy", "tooltipOptions", "buttonProps"], outputs: ["onVisibleChange", "visibleChange", "onClick", "onShow", "onHide"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSpeedDialComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-speeddial', standalone: true, imports: [SpeedDial], template: `
    <div style="position:relative; height:200px; display:flex; align-items:flex-end; justify-content:flex-start; padding:16px;">
      <p-speeddial
        [model]="model()"
        [direction]="direction()"
        [type]="type()"
        [disabled]="disabled()"
        [radius]="radius()"
      />
    </div>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], direction: [{ type: i0.Input, args: [{ isSignal: true, alias: "direction", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], radius: [{ type: i0.Input, args: [{ isSignal: true, alias: "radius", required: false }] }] } });

class SkSplitButtonComponent {
    label = input('Guardar', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    icon = input('pi pi-check', ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    model = input([
        { label: 'Guardar como...', icon: 'pi pi-save' },
        { label: 'Editar', icon: 'pi pi-pencil' },
        { separator: true },
        { label: 'Eliminar', icon: 'pi pi-trash' },
    ], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    severity = input(undefined, ...(ngDevMode ? [{ debugName: "severity" }] : /* istanbul ignore next */ []));
    outlined = input(false, ...(ngDevMode ? [{ debugName: "outlined" }] : /* istanbul ignore next */ []));
    raised = input(false, ...(ngDevMode ? [{ debugName: "raised" }] : /* istanbul ignore next */ []));
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    clicked = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSplitButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkSplitButtonComponent, isStandalone: true, selector: "sk-splitbutton", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, severity: { classPropertyName: "severity", publicName: "severity", isSignal: true, isRequired: false, transformFunction: null }, outlined: { classPropertyName: "outlined", publicName: "outlined", isSignal: true, isRequired: false, transformFunction: null }, raised: { classPropertyName: "raised", publicName: "raised", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { clicked: "clicked" }, ngImport: i0, template: `
    <p-splitbutton
      [label]="label()"
      [icon]="icon()"
      [model]="model()"
      [severity]="severity()"
      [outlined]="outlined()"
      [raised]="raised()"
      [disabled]="disabled()"
      (onClick)="clicked.emit($event)"
    />
  `, isInline: true, styles: [":host{display:inline-flex}\n"], dependencies: [{ kind: "component", type: SplitButton, selector: "p-splitbutton, p-splitButton, p-split-button", inputs: ["model", "severity", "raised", "rounded", "text", "outlined", "size", "plain", "icon", "iconPos", "label", "tooltip", "tooltipOptions", "styleClass", "menuStyle", "menuStyleClass", "dropdownIcon", "appendTo", "dir", "expandAriaLabel", "showTransitionOptions", "hideTransitionOptions", "motionOptions", "buttonProps", "menuButtonProps", "autofocus", "disabled", "tabindex", "menuButtonDisabled", "buttonDisabled"], outputs: ["onClick", "onMenuHide", "onMenuShow", "onDropdownClick"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSplitButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-splitbutton', standalone: true, imports: [SplitButton], template: `
    <p-splitbutton
      [label]="label()"
      [icon]="icon()"
      [model]="model()"
      [severity]="severity()"
      [outlined]="outlined()"
      [raised]="raised()"
      [disabled]="disabled()"
      (onClick)="clicked.emit($event)"
    />
  `, styles: [":host{display:inline-flex}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], severity: [{ type: i0.Input, args: [{ isSignal: true, alias: "severity", required: false }] }], outlined: [{ type: i0.Input, args: [{ isSignal: true, alias: "outlined", required: false }] }], raised: [{ type: i0.Input, args: [{ isSignal: true, alias: "raised", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], clicked: [{ type: i0.Output, args: ["clicked"] }] } });

class SkStepperComponent {
    steps = input([
        { value: 'datos', label: 'Datos personales', content: 'Ingresa tu nombre completo, numero de documento y fecha de nacimiento.' },
        { value: 'cuenta', label: 'Cuenta', content: 'Configura tu nombre de usuario y contrasena de acceso al sistema.' },
        { value: 'confirmacion', label: 'Confirmacion', content: 'Revisa todos los datos ingresados antes de confirmar el registro.' },
    ], ...(ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []));
    activeStep = input('datos', ...(ngDevMode ? [{ debugName: "activeStep" }] : /* istanbul ignore next */ []));
    linear = input(false, { ...(ngDevMode ? { debugName: "linear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    stepChange = output();
    _active = signal('', ...(ngDevMode ? [{ debugName: "_active" }] : /* istanbul ignore next */ []));
    resolvedActive = computed(() => this._active() || this.activeStep(), ...(ngDevMode ? [{ debugName: "resolvedActive" }] : /* istanbul ignore next */ []));
    activeIndex = computed(() => this.steps().findIndex(s => s.value === this.resolvedActive()), ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    activeStepData = computed(() => this.steps().find(s => s.value === this.resolvedActive()) ?? null, ...(ngDevMode ? [{ debugName: "activeStepData" }] : /* istanbul ignore next */ []));
    isActive(value) {
        return this.resolvedActive() === value;
    }
    isDone(index) {
        return index < this.activeIndex();
    }
    goTo(value) {
        this._active.set(value);
        this.stepChange.emit(value);
    }
    next() {
        const i = this.activeIndex();
        const next = this.steps()[i + 1];
        if (next)
            this.goTo(next.value);
    }
    prev() {
        const i = this.activeIndex();
        const prev = this.steps()[i - 1];
        if (prev)
            this.goTo(prev.value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkStepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkStepperComponent, isStandalone: true, selector: "sk-stepper", inputs: { steps: { classPropertyName: "steps", publicName: "steps", isSignal: true, isRequired: false, transformFunction: null }, activeStep: { classPropertyName: "activeStep", publicName: "activeStep", isSignal: true, isRequired: false, transformFunction: null }, linear: { classPropertyName: "linear", publicName: "linear", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { stepChange: "stepChange" }, ngImport: i0, template: "<div class=\"sk-stepper\">\r\n\r\n      <!-- Track -->\r\n      <div class=\"sk-stepper__track\">\r\n        @for (step of steps(); track step.value; let i = $index; let last = $last) {\r\n          <div class=\"sk-stepper__step\" [class.sk-stepper__step--active]=\"isActive(step.value)\" [class.sk-stepper__step--done]=\"isDone(i)\">\r\n\r\n            <button\r\n              class=\"sk-stepper__bubble\"\r\n              type=\"button\"\r\n              [attr.aria-current]=\"isActive(step.value) ? 'step' : null\"\r\n              [disabled]=\"linear() && !isDone(i) && !isActive(step.value)\"\r\n              (click)=\"goTo(step.value)\"\r\n            >\r\n              @if (isDone(i)) {\r\n                <svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\">\r\n                  <path d=\"M3 8.5L6.5 12L13 5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n                </svg>\r\n              } @else {\r\n                <span>{{ i + 1 }}</span>\r\n              }\r\n            </button>\r\n\r\n            <span class=\"sk-stepper__label\">{{ step.label }}</span>\r\n\r\n          </div>\r\n\r\n          @if (!last) {\r\n            <div class=\"sk-stepper__line\" [class.sk-stepper__line--done]=\"isDone(i)\"></div>\r\n          }\r\n        }\r\n      </div>\r\n\r\n      <!-- Panel -->\r\n      @if (activeStepData()) {\r\n        <div class=\"sk-stepper__panel\">\r\n          @if (activeStepData()!.content) {\r\n            <p class=\"sk-stepper__content\">{{ activeStepData()!.content }}</p>\r\n          }\r\n\r\n          <div class=\"sk-stepper__actions\">\r\n            <div class=\"sk-stepper__actions-left\">\r\n              @if (activeIndex() > 0) {\r\n                <button class=\"sk-stepper__btn sk-stepper__btn--back\" type=\"button\" (click)=\"prev()\">\r\n                  <i class=\"pi pi-arrow-left\"></i>\r\n                  Anterior\r\n                </button>\r\n              }\r\n            </div>\r\n            <div class=\"sk-stepper__actions-right\">\r\n              @if (activeIndex() < steps().length - 1) {\r\n                <button class=\"sk-stepper__btn sk-stepper__btn--next\" type=\"button\" (click)=\"next()\">\r\n                  Siguiente\r\n                  <i class=\"pi pi-arrow-right\"></i>\r\n                </button>\r\n              } @else {\r\n                <button class=\"sk-stepper__btn sk-stepper__btn--finish\" type=\"button\" (click)=\"stepChange.emit(resolvedActive())\">\r\n                  Finalizar\r\n                  <i class=\"pi pi-check\"></i>\r\n                </button>\r\n              }\r\n            </div>\r\n          </div>\r\n        </div>\r\n      }\r\n\r\n    </div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-stepper{display:flex;flex-direction:column;gap:24px;font-family:var(--body, \"Open Sans\", sans-serif)}.sk-stepper__track{display:flex;align-items:flex-start}.sk-stepper__step{display:flex;flex-direction:column;align-items:center;gap:8px;flex-shrink:0}.sk-stepper__line{flex:1;height:2px;background:var(--stroke-grey-light, #dddddd);margin-top:19px;border-radius:2px;transition:background .25s ease}.sk-stepper__line--done{background:var(--stroke-brand, #00c73d)}.sk-stepper__bubble{width:40px;height:40px;border-radius:50%;border:2px solid var(--stroke-grey-light, #dddddd);background:var(--background-principal, #ffffff);color:var(--texts-medium, #666666);font-family:inherit;font-size:14px;font-weight:700;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:border-color .2s ease,background .2s ease,color .2s ease,box-shadow .2s ease}.sk-stepper__bubble:disabled{cursor:default}.sk-stepper__step--active .sk-stepper__bubble{border-color:var(--stroke-brand, #00c73d);background:var(--background-principal, #ffffff);color:var(--texts-brand, #00c73d);box-shadow:0 0 0 4px color-mix(in srgb,var(--stroke-brand, #00c73d),transparent 82%)}.sk-stepper__step--done .sk-stepper__bubble{border-color:var(--stroke-brand, #00c73d);background:var(--stroke-brand, #00c73d);color:var(--texts-white, #ffffff);box-shadow:none}.sk-stepper__label{font-size:11px;font-weight:600;color:var(--texts-medium, #666666);text-align:center;max-width:80px;line-height:1.3;transition:color .2s ease}.sk-stepper__step--active .sk-stepper__label{color:var(--texts-brand, #00c73d)}.sk-stepper__step--done .sk-stepper__label{color:var(--texts-dark, #404040)}.sk-stepper__panel{border:1px solid var(--stroke-grey-light, #dddddd);border-radius:12px;padding:20px 24px;background:var(--background-principal, #ffffff);display:flex;flex-direction:column;gap:16px}.sk-stepper__content{margin:0;font-size:14px;color:var(--texts-medium, #666666);line-height:1.6}.sk-stepper__actions{display:flex;align-items:center;justify-content:space-between}.sk-stepper__actions-left,.sk-stepper__actions-right{display:flex}.sk-stepper__btn{font-family:inherit;font-size:13px;font-weight:600;padding:9px 18px;border-radius:8px;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:7px;transition:background .15s ease,color .15s ease,border-color .15s ease}.sk-stepper__btn--back{background:transparent;color:var(--texts-dark, #404040);border:1.5px solid var(--stroke-grey-light, #dddddd)}.sk-stepper__btn--back:hover{border-color:var(--texts-dark, #404040)}.sk-stepper__btn--next,.sk-stepper__btn--finish{background:var(--stroke-brand, #00c73d);color:var(--texts-white, #ffffff);border:1.5px solid transparent}.sk-stepper__btn--next:hover,.sk-stepper__btn--finish:hover{background:var(--color-primary-hover, #009e30)}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkStepperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-stepper', standalone: true, template: "<div class=\"sk-stepper\">\r\n\r\n      <!-- Track -->\r\n      <div class=\"sk-stepper__track\">\r\n        @for (step of steps(); track step.value; let i = $index; let last = $last) {\r\n          <div class=\"sk-stepper__step\" [class.sk-stepper__step--active]=\"isActive(step.value)\" [class.sk-stepper__step--done]=\"isDone(i)\">\r\n\r\n            <button\r\n              class=\"sk-stepper__bubble\"\r\n              type=\"button\"\r\n              [attr.aria-current]=\"isActive(step.value) ? 'step' : null\"\r\n              [disabled]=\"linear() && !isDone(i) && !isActive(step.value)\"\r\n              (click)=\"goTo(step.value)\"\r\n            >\r\n              @if (isDone(i)) {\r\n                <svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\">\r\n                  <path d=\"M3 8.5L6.5 12L13 5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\r\n                </svg>\r\n              } @else {\r\n                <span>{{ i + 1 }}</span>\r\n              }\r\n            </button>\r\n\r\n            <span class=\"sk-stepper__label\">{{ step.label }}</span>\r\n\r\n          </div>\r\n\r\n          @if (!last) {\r\n            <div class=\"sk-stepper__line\" [class.sk-stepper__line--done]=\"isDone(i)\"></div>\r\n          }\r\n        }\r\n      </div>\r\n\r\n      <!-- Panel -->\r\n      @if (activeStepData()) {\r\n        <div class=\"sk-stepper__panel\">\r\n          @if (activeStepData()!.content) {\r\n            <p class=\"sk-stepper__content\">{{ activeStepData()!.content }}</p>\r\n          }\r\n\r\n          <div class=\"sk-stepper__actions\">\r\n            <div class=\"sk-stepper__actions-left\">\r\n              @if (activeIndex() > 0) {\r\n                <button class=\"sk-stepper__btn sk-stepper__btn--back\" type=\"button\" (click)=\"prev()\">\r\n                  <i class=\"pi pi-arrow-left\"></i>\r\n                  Anterior\r\n                </button>\r\n              }\r\n            </div>\r\n            <div class=\"sk-stepper__actions-right\">\r\n              @if (activeIndex() < steps().length - 1) {\r\n                <button class=\"sk-stepper__btn sk-stepper__btn--next\" type=\"button\" (click)=\"next()\">\r\n                  Siguiente\r\n                  <i class=\"pi pi-arrow-right\"></i>\r\n                </button>\r\n              } @else {\r\n                <button class=\"sk-stepper__btn sk-stepper__btn--finish\" type=\"button\" (click)=\"stepChange.emit(resolvedActive())\">\r\n                  Finalizar\r\n                  <i class=\"pi pi-check\"></i>\r\n                </button>\r\n              }\r\n            </div>\r\n          </div>\r\n        </div>\r\n      }\r\n\r\n    </div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-stepper{display:flex;flex-direction:column;gap:24px;font-family:var(--body, \"Open Sans\", sans-serif)}.sk-stepper__track{display:flex;align-items:flex-start}.sk-stepper__step{display:flex;flex-direction:column;align-items:center;gap:8px;flex-shrink:0}.sk-stepper__line{flex:1;height:2px;background:var(--stroke-grey-light, #dddddd);margin-top:19px;border-radius:2px;transition:background .25s ease}.sk-stepper__line--done{background:var(--stroke-brand, #00c73d)}.sk-stepper__bubble{width:40px;height:40px;border-radius:50%;border:2px solid var(--stroke-grey-light, #dddddd);background:var(--background-principal, #ffffff);color:var(--texts-medium, #666666);font-family:inherit;font-size:14px;font-weight:700;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:border-color .2s ease,background .2s ease,color .2s ease,box-shadow .2s ease}.sk-stepper__bubble:disabled{cursor:default}.sk-stepper__step--active .sk-stepper__bubble{border-color:var(--stroke-brand, #00c73d);background:var(--background-principal, #ffffff);color:var(--texts-brand, #00c73d);box-shadow:0 0 0 4px color-mix(in srgb,var(--stroke-brand, #00c73d),transparent 82%)}.sk-stepper__step--done .sk-stepper__bubble{border-color:var(--stroke-brand, #00c73d);background:var(--stroke-brand, #00c73d);color:var(--texts-white, #ffffff);box-shadow:none}.sk-stepper__label{font-size:11px;font-weight:600;color:var(--texts-medium, #666666);text-align:center;max-width:80px;line-height:1.3;transition:color .2s ease}.sk-stepper__step--active .sk-stepper__label{color:var(--texts-brand, #00c73d)}.sk-stepper__step--done .sk-stepper__label{color:var(--texts-dark, #404040)}.sk-stepper__panel{border:1px solid var(--stroke-grey-light, #dddddd);border-radius:12px;padding:20px 24px;background:var(--background-principal, #ffffff);display:flex;flex-direction:column;gap:16px}.sk-stepper__content{margin:0;font-size:14px;color:var(--texts-medium, #666666);line-height:1.6}.sk-stepper__actions{display:flex;align-items:center;justify-content:space-between}.sk-stepper__actions-left,.sk-stepper__actions-right{display:flex}.sk-stepper__btn{font-family:inherit;font-size:13px;font-weight:600;padding:9px 18px;border-radius:8px;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:7px;transition:background .15s ease,color .15s ease,border-color .15s ease}.sk-stepper__btn--back{background:transparent;color:var(--texts-dark, #404040);border:1.5px solid var(--stroke-grey-light, #dddddd)}.sk-stepper__btn--back:hover{border-color:var(--texts-dark, #404040)}.sk-stepper__btn--next,.sk-stepper__btn--finish{background:var(--stroke-brand, #00c73d);color:var(--texts-white, #ffffff);border:1.5px solid transparent}.sk-stepper__btn--next:hover,.sk-stepper__btn--finish:hover{background:var(--color-primary-hover, #009e30)}\n"] }]
        }], propDecorators: { steps: [{ type: i0.Input, args: [{ isSignal: true, alias: "steps", required: false }] }], activeStep: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeStep", required: false }] }], linear: [{ type: i0.Input, args: [{ isSignal: true, alias: "linear", required: false }] }], stepChange: [{ type: i0.Output, args: ["stepChange"] }] } });

class SkStepsComponent {
    model = input([], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    activeIndex = input(0, { ...(ngDevMode ? { debugName: "activeIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    exact = input(true, { ...(ngDevMode ? { debugName: "exact" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    activeIndexChange = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkStepsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkStepsComponent, isStandalone: true, selector: "sk-steps", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, activeIndex: { classPropertyName: "activeIndex", publicName: "activeIndex", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, exact: { classPropertyName: "exact", publicName: "exact", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activeIndexChange: "activeIndexChange" }, ngImport: i0, template: `
    <p-steps
      [model]="model()"
      [activeIndex]="activeIndex()"
      [readonly]="readonly()"
      [exact]="exact()"
      (activeIndexChange)="activeIndexChange.emit($event)"
    />
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Steps, selector: "p-steps", inputs: ["activeIndex", "model", "readonly", "style", "styleClass", "exact"], outputs: ["activeIndexChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkStepsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-steps', standalone: true, imports: [Steps], template: `
    <p-steps
      [model]="model()"
      [activeIndex]="activeIndex()"
      [readonly]="readonly()"
      [exact]="exact()"
      (activeIndexChange)="activeIndexChange.emit($event)"
    />
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], activeIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeIndex", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], exact: [{ type: i0.Input, args: [{ isSignal: true, alias: "exact", required: false }] }], activeIndexChange: [{ type: i0.Output, args: ["activeIndexChange"] }] } });

class SkSwitchComponent {
    checked = input(false, { ...(ngDevMode ? { debugName: "checked" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    label = input('Activar opción', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    valueChange = output();
    internalChecked = false;
    ngOnInit() {
        this.internalChecked = this.checked();
    }
    handleChange(event) {
        this.valueChange.emit(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSwitchComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkSwitchComponent, isStandalone: true, selector: "sk-switch", inputs: { checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <div class="sk-switch-wrap">
      <p-toggleswitch
        [(ngModel)]="internalChecked"
        [disabled]="disabled()"
        (onChange)="handleChange($event)"
      />
      @if (label()) { <span class="sk-switch-label">{{ label() }}</span> }
    </div>
  `, isInline: true, styles: [":host{display:inline-flex}.sk-switch-wrap{display:flex;align-items:center;gap:10px}.sk-switch-label{font-size:14px;font-weight:500;color:var(--p-surface-700, #374151)}\n"], dependencies: [{ kind: "component", type: ToggleSwitch, selector: "p-toggleswitch, p-toggleSwitch, p-toggle-switch", inputs: ["styleClass", "tabindex", "inputId", "readonly", "trueValue", "falseValue", "ariaLabel", "size", "ariaLabelledBy", "autofocus"], outputs: ["onChange"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkSwitchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-switch', standalone: true, imports: [ToggleSwitch, FormsModule], template: `
    <div class="sk-switch-wrap">
      <p-toggleswitch
        [(ngModel)]="internalChecked"
        [disabled]="disabled()"
        (onChange)="handleChange($event)"
      />
      @if (label()) { <span class="sk-switch-label">{{ label() }}</span> }
    </div>
  `, styles: [":host{display:inline-flex}.sk-switch-wrap{display:flex;align-items:center;gap:10px}.sk-switch-label{font-size:14px;font-weight:500;color:var(--p-surface-700, #374151)}\n"] }]
        }], propDecorators: { checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "checked", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkTableComponent {
    // --- Inputs ---
    data = input([], ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    columns = input([], ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    filterGroups = input([], ...(ngDevMode ? [{ debugName: "filterGroups" }] : /* istanbul ignore next */ []));
    rowActions = input([], ...(ngDevMode ? [{ debugName: "rowActions" }] : /* istanbul ignore next */ []));
    searchPlaceholder = input('Buscar...', ...(ngDevMode ? [{ debugName: "searchPlaceholder" }] : /* istanbul ignore next */ []));
    rowsPerPageOptions = input([10, 25, 50, 100], ...(ngDevMode ? [{ debugName: "rowsPerPageOptions" }] : /* istanbul ignore next */ []));
    totalRecords = input(null, ...(ngDevMode ? [{ debugName: "totalRecords" }] : /* istanbul ignore next */ []));
    lazy = input(false, { ...(ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    striped = input(false, { ...(ngDevMode ? { debugName: "striped" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    emptyMessage = input('No hay datos disponibles', ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    // --- Outputs ---
    searchChange = output();
    filterChange = output();
    pageChange = output();
    sortChange = output();
    rowActionSelect = output();
    // --- Internal state ---
    _filterPopover = viewChild('filterPopover', ...(ngDevMode ? [{ debugName: "_filterPopover" }] : /* istanbul ignore next */ []));
    _rowMenu = viewChild('rowMenu', ...(ngDevMode ? [{ debugName: "_rowMenu" }] : /* istanbul ignore next */ []));
    _currentMenuRow = signal(null, ...(ngDevMode ? [{ debugName: "_currentMenuRow" }] : /* istanbul ignore next */ []));
    _rows = signal(10, ...(ngDevMode ? [{ debugName: "_rows" }] : /* istanbul ignore next */ []));
    _first = signal(0, ...(ngDevMode ? [{ debugName: "_first" }] : /* istanbul ignore next */ []));
    _searchValue = signal('', ...(ngDevMode ? [{ debugName: "_searchValue" }] : /* istanbul ignore next */ []));
    _filterSelections = signal({}, ...(ngDevMode ? [{ debugName: "_filterSelections" }] : /* istanbul ignore next */ []));
    // --- Computed ---
    activeFilters = computed(() => {
        const selections = this._filterSelections();
        return this.filterGroups().flatMap(group => (selections[group.field] ?? []).map(value => ({
            field: group.field,
            value,
            label: group.options.find(o => o.value === value)?.label ?? value,
            groupLabel: group.label,
        })));
    }, ...(ngDevMode ? [{ debugName: "activeFilters" }] : /* istanbul ignore next */ []));
    displayData = computed(() => {
        if (this.lazy())
            return this.data();
        const search = this._searchValue().toLowerCase().trim();
        const selections = this._filterSelections();
        return this.data().filter(row => {
            if (search && !this.columns().some(col => String(row[col.field] ?? '').toLowerCase().includes(search)))
                return false;
            for (const [field, values] of Object.entries(selections)) {
                if (values.length && !values.includes(String(row[field] ?? '')))
                    return false;
            }
            return true;
        });
    }, ...(ngDevMode ? [{ debugName: "displayData" }] : /* istanbul ignore next */ []));
    effectiveTotalRecords = computed(() => this.lazy() ? (this.totalRecords() ?? 0) : this.displayData().length, ...(ngDevMode ? [{ debugName: "effectiveTotalRecords" }] : /* istanbul ignore next */ []));
    pageData = computed(() => {
        if (this.lazy())
            return this.data();
        const first = this._first();
        return this.displayData().slice(first, first + this._rows());
    }, ...(ngDevMode ? [{ debugName: "pageData" }] : /* istanbul ignore next */ []));
    _menuItems = computed(() => this.rowActions().map(action => ({
        label: action.label,
        icon: action.icon,
        command: () => {
            const row = this._currentMenuRow();
            if (row)
                this.rowActionSelect.emit({ actionId: action.id, row });
        },
    })), ...(ngDevMode ? [{ debugName: "_menuItems" }] : /* istanbul ignore next */ []));
    // --- Methods ---
    onSearch(event) {
        const value = event.target.value;
        this._searchValue.set(value);
        this._first.set(0);
        if (this.lazy())
            this.searchChange.emit(value);
    }
    toggleFilterOption(field, value) {
        this._filterSelections.update(s => {
            const current = s[field] ?? [];
            const idx = current.indexOf(value);
            const next = idx >= 0 ? current.filter(v => v !== value) : [...current, value];
            return { ...s, [field]: next };
        });
        this._first.set(0);
        if (this.lazy())
            this.filterChange.emit(this.activeFilters());
    }
    isOptionSelected(field, value) {
        return this._filterSelections()[field]?.includes(value) ?? false;
    }
    removeFilter(filter) {
        this._filterSelections.update(s => ({
            ...s,
            [filter.field]: (s[filter.field] ?? []).filter(v => v !== filter.value),
        }));
        this._first.set(0);
        if (this.lazy())
            this.filterChange.emit(this.activeFilters());
    }
    onRowsChange(rows) {
        this._rows.set(rows);
        this._first.set(0);
    }
    onPageChange(event) {
        const state = event;
        this._first.set(state.first);
        this._rows.set(state.rows);
        if (this.lazy()) {
            this.pageChange.emit({ page: state.page, rows: state.rows, first: state.first });
        }
    }
    toggleFilterPanel(event) {
        this._filterPopover()?.toggle(event);
    }
    openRowMenu(event, row) {
        this._currentMenuRow.set(row);
        this._rowMenu()?.toggle(event);
    }
    onSort(event) {
        this.sortChange.emit({ field: event.field ?? '', order: event.order ?? 1 });
    }
    getCellValue(row, col) {
        const value = row[col.field];
        return col.format ? col.format(value) : String(value ?? '');
    }
    getBadgeVariant(row, col) {
        const value = row[col.field];
        if (col.badgeSeverity)
            return col.badgeSeverity(value);
        if (col.badgeVariantMap)
            return col.badgeVariantMap[String(value ?? '')] ?? 'info';
        return 'info';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkTableComponent, isStandalone: true, selector: "sk-table", inputs: { data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, filterGroups: { classPropertyName: "filterGroups", publicName: "filterGroups", isSignal: true, isRequired: false, transformFunction: null }, rowActions: { classPropertyName: "rowActions", publicName: "rowActions", isSignal: true, isRequired: false, transformFunction: null }, searchPlaceholder: { classPropertyName: "searchPlaceholder", publicName: "searchPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, rowsPerPageOptions: { classPropertyName: "rowsPerPageOptions", publicName: "rowsPerPageOptions", isSignal: true, isRequired: false, transformFunction: null }, totalRecords: { classPropertyName: "totalRecords", publicName: "totalRecords", isSignal: true, isRequired: false, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, striped: { classPropertyName: "striped", publicName: "striped", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { searchChange: "searchChange", filterChange: "filterChange", pageChange: "pageChange", sortChange: "sortChange", rowActionSelect: "rowActionSelect" }, viewQueries: [{ propertyName: "_filterPopover", first: true, predicate: ["filterPopover"], descendants: true, isSignal: true }, { propertyName: "_rowMenu", first: true, predicate: ["rowMenu"], descendants: true, isSignal: true }], ngImport: i0, template: "<!-- Toolbar -->\r\n<div class=\"sk-table-toolbar\">\r\n  <p-iconfield class=\"sk-table-search\">\r\n    <p-inputicon class=\"pi pi-search\" />\r\n    <input pInputText [placeholder]=\"searchPlaceholder()\" (input)=\"onSearch($event)\" />\r\n  </p-iconfield>\r\n\r\n  @if (filterGroups().length) {\r\n    <button class=\"sk-filter-btn\" (click)=\"toggleFilterPanel($event)\">\r\n      Filtrar <i class=\"pi pi-filter\"></i>\r\n    </button>\r\n  }\r\n</div>\r\n\r\n<!-- Active filter chips -->\r\n@if (activeFilters().length) {\r\n  <div class=\"sk-table-chips\">\r\n    @for (filter of activeFilters(); track filter.field + filter.value) {\r\n      <span class=\"sk-chip\">\r\n        {{ filter.groupLabel }}: {{ filter.label }}\r\n        <button class=\"sk-chip-remove\" (click)=\"removeFilter(filter)\" aria-label=\"Eliminar filtro\">\r\n          <i class=\"pi pi-times-circle\"></i>\r\n        </button>\r\n      </span>\r\n    }\r\n  </div>\r\n}\r\n\r\n<!-- Filter popover -->\r\n<p-popover #filterPopover>\r\n  <div class=\"sk-filter-panel\">\r\n    @for (group of filterGroups(); track group.field) {\r\n      <div class=\"sk-filter-group\">\r\n        <span class=\"sk-filter-group-label\">{{ group.label }}</span>\r\n        @for (option of group.options; track option.value) {\r\n          <div class=\"sk-filter-option\">\r\n            <p-checkbox\r\n              [binary]=\"true\"\r\n              [ngModel]=\"isOptionSelected(group.field, option.value)\"\r\n              (onChange)=\"toggleFilterOption(group.field, option.value)\"\r\n              [inputId]=\"group.field + '_' + option.value\"\r\n            />\r\n            <label [for]=\"group.field + '_' + option.value\">{{ option.label }}</label>\r\n          </div>\r\n        }\r\n      </div>\r\n    }\r\n  </div>\r\n</p-popover>\r\n\r\n<!-- Row actions menu -->\r\n@if (rowActions().length) {\r\n  <p-menu #rowMenu [model]=\"_menuItems()\" [popup]=\"true\" />\r\n}\r\n\r\n<!-- Table -->\r\n<p-table\r\n  [value]=\"pageData()\"\r\n  [lazy]=\"lazy()\"\r\n  [loading]=\"loading()\"\r\n  [stripedRows]=\"striped()\"\r\n  [tableStyle]=\"{ 'min-width': '100%' }\"\r\n  (onSort)=\"onSort($event)\"\r\n>\r\n  <ng-template #header>\r\n    <tr>\r\n      @for (col of columns(); track col.field) {\r\n        @if (col.sortable) {\r\n          <th [pSortableColumn]=\"col.field\" [style.width]=\"col.width\">\r\n            <span class=\"sk-th-content\">\r\n              <h5>{{ col.header }}</h5>\r\n              <p-sortIcon [field]=\"col.field\" />\r\n            </span>\r\n          </th>\r\n        } @else {\r\n          <th [style.width]=\"col.width\"><h5>{{ col.header }}</h5></th>\r\n        }\r\n      }\r\n      @if (rowActions().length) {\r\n        <th class=\"sk-actions-th\"></th>\r\n      }\r\n    </tr>\r\n  </ng-template>\r\n\r\n  <ng-template #body let-row>\r\n    <tr>\r\n      @for (col of columns(); track col.field) {\r\n        <td>\r\n          @if (col.type === 'badge') {\r\n            <span class=\"sk-badge sk-badge--square sk-badge--stroke sk-badge--{{ getBadgeVariant(row, col) }}\">\r\n              <span class=\"sk-badge__label\">{{ getCellValue(row, col) }}</span>\r\n            </span>\r\n          } @else {\r\n            <div [class.sk-cell-multi]=\"col.subfield\">\r\n              <span class=\"sk-cell-main\">{{ getCellValue(row, col) }}</span>\r\n              @if (col.subfield && row[col.subfield]) {\r\n                <span class=\"sk-cell-sub\">{{ row[col.subfield] }}</span>\r\n              }\r\n            </div>\r\n          }\r\n        </td>\r\n      }\r\n      @if (rowActions().length) {\r\n        <td class=\"sk-actions-td\">\r\n          <button class=\"sk-row-menu-btn\" (click)=\"openRowMenu($event, row)\" aria-label=\"Acciones\">\r\n            <i class=\"pi pi-ellipsis-v\"></i>\r\n          </button>\r\n        </td>\r\n      }\r\n    </tr>\r\n  </ng-template>\r\n\r\n  <ng-template #emptymessage>\r\n    <tr>\r\n      <td\r\n        [attr.colspan]=\"columns().length + (rowActions().length ? 1 : 0)\"\r\n        class=\"sk-table-empty\"\r\n      >\r\n        {{ emptyMessage() }}\r\n      </td>\r\n    </tr>\r\n  </ng-template>\r\n</p-table>\r\n\r\n<!-- Paginator -->\r\n<p-paginator\r\n  [first]=\"_first()\"\r\n  [rows]=\"_rows()\"\r\n  [totalRecords]=\"effectiveTotalRecords()\"\r\n  [rowsPerPageOptions]=\"rowsPerPageOptions()\"\r\n  (onPageChange)=\"onPageChange($event)\"\r\n/>\r\n\r\n", styles: [":host{display:block}.sk-table-toolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px}.sk-table-search{flex:1;max-width:400px}.sk-filter-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border:1px solid var(--p-select-border-color, #d1d5db);border-radius:var(--p-border-radius-md, 6px);background:transparent;cursor:pointer;font-size:14px;color:var(--p-text-color, #374151);transition:border-color .2s}.sk-filter-btn:hover{border-color:var(--p-primary-color, #00a859);color:var(--p-primary-color, #00a859)}.sk-table-chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}.sk-chip{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border:1px solid var(--p-content-border-color, #e5e7eb);border-radius:20px;font-size:13px;background:var(--p-content-background, #fff);color:var(--p-text-color, #374151)}.sk-chip-remove{display:inline-flex;align-items:center;background:none;border:none;padding:0;cursor:pointer;color:var(--p-text-muted-color, #6b7280);line-height:1}.sk-chip-remove:hover{color:var(--p-primary-color, #00a859)}.sk-filter-panel{min-width:180px;padding:4px 0}.sk-filter-group{padding:8px 16px}.sk-filter-group-label{display:block;font-size:12px;font-weight:600;color:var(--p-text-muted-color, #6b7280);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px}.sk-filter-option{display:flex;align-items:center;gap:8px;padding:5px 0;cursor:pointer}.sk-filter-option label{cursor:pointer;font-size:14px;color:var(--p-text-color, #374151);-webkit-user-select:none;user-select:none}.sk-th-content{display:inline-flex;align-items:center;gap:4px}:host ::ng-deep .p-datatable-thead>tr>th h5{margin:0;font-family:var(--meta-title-h5-bold-16-px-font, var(--title, \"Montserrat\", sans-serif));font-size:var(--meta-title-h5-bold-16-px-size, 16px)!important;font-weight:var(--meta-title-h5-bold-16-px-weight, 700)!important;line-height:var(--meta-title-h5-bold-16-px-line-height, 24px);letter-spacing:0;color:inherit}.sk-cell-multi{display:flex;flex-direction:column;gap:2px}.sk-cell-main{font-size:14px;color:var(--p-text-color, #374151)}.sk-cell-sub{font-size:12px;color:var(--p-text-muted-color, #6b7280)}.sk-badge{display:inline-flex;align-items:center;justify-content:center;font-family:var(--label-medium-font, \"Open Sans\", sans-serif);font-size:var(--label-medium-size, .875rem);font-weight:var(--label-medium-weight, 500);line-height:var(--label-medium-line-height, 1.375rem);box-sizing:border-box;border:1px solid transparent}.sk-badge--square{min-height:38px;gap:var(--size-xxs, 4px);padding:0 var(--size-xs, 8px);border-radius:6px}.sk-badge--stroke.sk-badge--success{background:var(--background-success-light);border-color:var(--stroke-success);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--warning{background:var(--background-warning-light);border-color:var(--stroke-warning);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--info{background:var(--background-info-light);border-color:var(--stroke-info);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--error{background:var(--background-error-light);border-color:var(--stroke-error-dark);color:var(--background-error-dark)}.sk-badge__label{font-size:inherit;line-height:inherit}.sk-actions-th,.sk-actions-td{width:48px;text-align:center}.sk-row-menu-btn{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;background:none;border:none;border-radius:50%;cursor:pointer;color:var(--p-text-muted-color, #6b7280);transition:background .2s}.sk-row-menu-btn:hover{background:var(--p-content-hover-background, #f3f4f6);color:var(--p-text-color, #374151)}.sk-table-empty{text-align:center;padding:32px 16px;color:var(--p-text-muted-color, #6b7280);font-size:14px}:host ::ng-deep .p-datatable-thead>tr>th{background:var(--p-content-hover-background, #f9fafb)!important;font-weight:600!important;font-size:13px;padding:12px 16px!important;border-bottom:2px solid var(--p-content-border-color, #e5e7eb)!important;white-space:nowrap}:host ::ng-deep .p-datatable-tbody>tr>td{padding:12px 16px!important;border-bottom:1px solid var(--p-content-border-color, #e5e7eb)!important;vertical-align:middle}:host ::ng-deep .p-datatable-tbody>tr:hover{background:var(--p-content-hover-background, #f9fafb)!important}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: TableModule }, { kind: "component", type: i2$1.Table, selector: "p-table", inputs: ["frozenColumns", "frozenValue", "styleClass", "tableStyle", "tableStyleClass", "paginator", "pageLinks", "rowsPerPageOptions", "alwaysShowPaginator", "paginatorPosition", "paginatorStyleClass", "paginatorDropdownAppendTo", "paginatorDropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showFirstLastIcon", "showPageLinks", "defaultSortOrder", "sortMode", "resetPageOnSort", "selectionMode", "selectionPageOnly", "contextMenuSelection", "contextMenuSelectionMode", "dataKey", "metaKeySelection", "rowSelectable", "rowTrackBy", "lazy", "lazyLoadOnInit", "compareSelectionBy", "csvSeparator", "exportFilename", "filters", "globalFilterFields", "filterDelay", "filterLocale", "expandedRowKeys", "editingRowKeys", "rowExpandMode", "scrollable", "rowGroupMode", "scrollHeight", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "virtualScrollDelay", "frozenWidth", "contextMenu", "resizableColumns", "columnResizeMode", "reorderableColumns", "loading", "loadingIcon", "showLoader", "rowHover", "customSort", "showInitialSortBadge", "exportFunction", "exportHeader", "stateKey", "stateStorage", "editMode", "groupRowsBy", "size", "showGridlines", "stripedRows", "groupRowsByOrder", "responsiveLayout", "breakpoint", "paginatorLocale", "value", "columns", "first", "rows", "totalRecords", "sortField", "sortOrder", "multiSortMeta", "selection", "selectAll"], outputs: ["contextMenuSelectionChange", "selectAllChange", "selectionChange", "onRowSelect", "onRowUnselect", "onPage", "onSort", "onFilter", "onLazyLoad", "onRowExpand", "onRowCollapse", "onContextMenuSelect", "onColResize", "onColReorder", "onRowReorder", "onEditInit", "onEditComplete", "onEditCancel", "onHeaderCheckboxToggle", "sortFunction", "firstChange", "rowsChange", "onStateSave", "onStateRestore"] }, { kind: "directive", type: i2$1.SortableColumn, selector: "[pSortableColumn]", inputs: ["pSortableColumn", "pSortableColumnDisabled"] }, { kind: "component", type: i2$1.SortIcon, selector: "p-sortIcon", inputs: ["field"] }, { kind: "ngmodule", type: PopoverModule }, { kind: "component", type: i3.Popover, selector: "p-popover", inputs: ["ariaLabel", "ariaLabelledBy", "dismissable", "style", "styleClass", "appendTo", "autoZIndex", "ariaCloseLabel", "baseZIndex", "focusOnShow", "showTransitionOptions", "hideTransitionOptions", "motionOptions"], outputs: ["onShow", "onHide"] }, { kind: "ngmodule", type: CheckboxModule }, { kind: "component", type: i4.Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: IconFieldModule }, { kind: "component", type: i5.IconField, selector: "p-iconfield, p-iconField, p-icon-field", inputs: ["hostName", "iconPosition", "styleClass"] }, { kind: "ngmodule", type: InputIconModule }, { kind: "component", type: i6.InputIcon, selector: "p-inputicon, p-inputIcon", inputs: ["hostName", "styleClass"] }, { kind: "ngmodule", type: InputTextModule }, { kind: "directive", type: i7.InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "ngmodule", type: MenuModule }, { kind: "component", type: i8.Menu, selector: "p-menu", inputs: ["model", "popup", "style", "styleClass", "autoZIndex", "baseZIndex", "showTransitionOptions", "hideTransitionOptions", "ariaLabel", "ariaLabelledBy", "id", "tabindex", "appendTo", "motionOptions"], outputs: ["onShow", "onHide", "onBlur", "onFocus"] }, { kind: "ngmodule", type: PaginatorModule }, { kind: "component", type: i9.Paginator, selector: "p-paginator", inputs: ["pageLinkSize", "styleClass", "alwaysShow", "dropdownAppendTo", "templateLeft", "templateRight", "dropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showFirstLastIcon", "totalRecords", "rows", "rowsPerPageOptions", "showJumpToPageDropdown", "showJumpToPageInput", "jumpToPageItemTemplate", "showPageLinks", "locale", "dropdownItemTemplate", "first", "appendTo"], outputs: ["onPageChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-table', standalone: true, imports: [
                        FormsModule,
                        TableModule,
                        PopoverModule,
                        CheckboxModule,
                        IconFieldModule,
                        InputIconModule,
                        InputTextModule,
                        MenuModule,
                        PaginatorModule,
                    ], template: "<!-- Toolbar -->\r\n<div class=\"sk-table-toolbar\">\r\n  <p-iconfield class=\"sk-table-search\">\r\n    <p-inputicon class=\"pi pi-search\" />\r\n    <input pInputText [placeholder]=\"searchPlaceholder()\" (input)=\"onSearch($event)\" />\r\n  </p-iconfield>\r\n\r\n  @if (filterGroups().length) {\r\n    <button class=\"sk-filter-btn\" (click)=\"toggleFilterPanel($event)\">\r\n      Filtrar <i class=\"pi pi-filter\"></i>\r\n    </button>\r\n  }\r\n</div>\r\n\r\n<!-- Active filter chips -->\r\n@if (activeFilters().length) {\r\n  <div class=\"sk-table-chips\">\r\n    @for (filter of activeFilters(); track filter.field + filter.value) {\r\n      <span class=\"sk-chip\">\r\n        {{ filter.groupLabel }}: {{ filter.label }}\r\n        <button class=\"sk-chip-remove\" (click)=\"removeFilter(filter)\" aria-label=\"Eliminar filtro\">\r\n          <i class=\"pi pi-times-circle\"></i>\r\n        </button>\r\n      </span>\r\n    }\r\n  </div>\r\n}\r\n\r\n<!-- Filter popover -->\r\n<p-popover #filterPopover>\r\n  <div class=\"sk-filter-panel\">\r\n    @for (group of filterGroups(); track group.field) {\r\n      <div class=\"sk-filter-group\">\r\n        <span class=\"sk-filter-group-label\">{{ group.label }}</span>\r\n        @for (option of group.options; track option.value) {\r\n          <div class=\"sk-filter-option\">\r\n            <p-checkbox\r\n              [binary]=\"true\"\r\n              [ngModel]=\"isOptionSelected(group.field, option.value)\"\r\n              (onChange)=\"toggleFilterOption(group.field, option.value)\"\r\n              [inputId]=\"group.field + '_' + option.value\"\r\n            />\r\n            <label [for]=\"group.field + '_' + option.value\">{{ option.label }}</label>\r\n          </div>\r\n        }\r\n      </div>\r\n    }\r\n  </div>\r\n</p-popover>\r\n\r\n<!-- Row actions menu -->\r\n@if (rowActions().length) {\r\n  <p-menu #rowMenu [model]=\"_menuItems()\" [popup]=\"true\" />\r\n}\r\n\r\n<!-- Table -->\r\n<p-table\r\n  [value]=\"pageData()\"\r\n  [lazy]=\"lazy()\"\r\n  [loading]=\"loading()\"\r\n  [stripedRows]=\"striped()\"\r\n  [tableStyle]=\"{ 'min-width': '100%' }\"\r\n  (onSort)=\"onSort($event)\"\r\n>\r\n  <ng-template #header>\r\n    <tr>\r\n      @for (col of columns(); track col.field) {\r\n        @if (col.sortable) {\r\n          <th [pSortableColumn]=\"col.field\" [style.width]=\"col.width\">\r\n            <span class=\"sk-th-content\">\r\n              <h5>{{ col.header }}</h5>\r\n              <p-sortIcon [field]=\"col.field\" />\r\n            </span>\r\n          </th>\r\n        } @else {\r\n          <th [style.width]=\"col.width\"><h5>{{ col.header }}</h5></th>\r\n        }\r\n      }\r\n      @if (rowActions().length) {\r\n        <th class=\"sk-actions-th\"></th>\r\n      }\r\n    </tr>\r\n  </ng-template>\r\n\r\n  <ng-template #body let-row>\r\n    <tr>\r\n      @for (col of columns(); track col.field) {\r\n        <td>\r\n          @if (col.type === 'badge') {\r\n            <span class=\"sk-badge sk-badge--square sk-badge--stroke sk-badge--{{ getBadgeVariant(row, col) }}\">\r\n              <span class=\"sk-badge__label\">{{ getCellValue(row, col) }}</span>\r\n            </span>\r\n          } @else {\r\n            <div [class.sk-cell-multi]=\"col.subfield\">\r\n              <span class=\"sk-cell-main\">{{ getCellValue(row, col) }}</span>\r\n              @if (col.subfield && row[col.subfield]) {\r\n                <span class=\"sk-cell-sub\">{{ row[col.subfield] }}</span>\r\n              }\r\n            </div>\r\n          }\r\n        </td>\r\n      }\r\n      @if (rowActions().length) {\r\n        <td class=\"sk-actions-td\">\r\n          <button class=\"sk-row-menu-btn\" (click)=\"openRowMenu($event, row)\" aria-label=\"Acciones\">\r\n            <i class=\"pi pi-ellipsis-v\"></i>\r\n          </button>\r\n        </td>\r\n      }\r\n    </tr>\r\n  </ng-template>\r\n\r\n  <ng-template #emptymessage>\r\n    <tr>\r\n      <td\r\n        [attr.colspan]=\"columns().length + (rowActions().length ? 1 : 0)\"\r\n        class=\"sk-table-empty\"\r\n      >\r\n        {{ emptyMessage() }}\r\n      </td>\r\n    </tr>\r\n  </ng-template>\r\n</p-table>\r\n\r\n<!-- Paginator -->\r\n<p-paginator\r\n  [first]=\"_first()\"\r\n  [rows]=\"_rows()\"\r\n  [totalRecords]=\"effectiveTotalRecords()\"\r\n  [rowsPerPageOptions]=\"rowsPerPageOptions()\"\r\n  (onPageChange)=\"onPageChange($event)\"\r\n/>\r\n\r\n", styles: [":host{display:block}.sk-table-toolbar{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px}.sk-table-search{flex:1;max-width:400px}.sk-filter-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;border:1px solid var(--p-select-border-color, #d1d5db);border-radius:var(--p-border-radius-md, 6px);background:transparent;cursor:pointer;font-size:14px;color:var(--p-text-color, #374151);transition:border-color .2s}.sk-filter-btn:hover{border-color:var(--p-primary-color, #00a859);color:var(--p-primary-color, #00a859)}.sk-table-chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}.sk-chip{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border:1px solid var(--p-content-border-color, #e5e7eb);border-radius:20px;font-size:13px;background:var(--p-content-background, #fff);color:var(--p-text-color, #374151)}.sk-chip-remove{display:inline-flex;align-items:center;background:none;border:none;padding:0;cursor:pointer;color:var(--p-text-muted-color, #6b7280);line-height:1}.sk-chip-remove:hover{color:var(--p-primary-color, #00a859)}.sk-filter-panel{min-width:180px;padding:4px 0}.sk-filter-group{padding:8px 16px}.sk-filter-group-label{display:block;font-size:12px;font-weight:600;color:var(--p-text-muted-color, #6b7280);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px}.sk-filter-option{display:flex;align-items:center;gap:8px;padding:5px 0;cursor:pointer}.sk-filter-option label{cursor:pointer;font-size:14px;color:var(--p-text-color, #374151);-webkit-user-select:none;user-select:none}.sk-th-content{display:inline-flex;align-items:center;gap:4px}:host ::ng-deep .p-datatable-thead>tr>th h5{margin:0;font-family:var(--meta-title-h5-bold-16-px-font, var(--title, \"Montserrat\", sans-serif));font-size:var(--meta-title-h5-bold-16-px-size, 16px)!important;font-weight:var(--meta-title-h5-bold-16-px-weight, 700)!important;line-height:var(--meta-title-h5-bold-16-px-line-height, 24px);letter-spacing:0;color:inherit}.sk-cell-multi{display:flex;flex-direction:column;gap:2px}.sk-cell-main{font-size:14px;color:var(--p-text-color, #374151)}.sk-cell-sub{font-size:12px;color:var(--p-text-muted-color, #6b7280)}.sk-badge{display:inline-flex;align-items:center;justify-content:center;font-family:var(--label-medium-font, \"Open Sans\", sans-serif);font-size:var(--label-medium-size, .875rem);font-weight:var(--label-medium-weight, 500);line-height:var(--label-medium-line-height, 1.375rem);box-sizing:border-box;border:1px solid transparent}.sk-badge--square{min-height:38px;gap:var(--size-xxs, 4px);padding:0 var(--size-xs, 8px);border-radius:6px}.sk-badge--stroke.sk-badge--success{background:var(--background-success-light);border-color:var(--stroke-success);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--warning{background:var(--background-warning-light);border-color:var(--stroke-warning);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--info{background:var(--background-info-light);border-color:var(--stroke-info);color:var(--texts-dark)}.sk-badge--stroke.sk-badge--error{background:var(--background-error-light);border-color:var(--stroke-error-dark);color:var(--background-error-dark)}.sk-badge__label{font-size:inherit;line-height:inherit}.sk-actions-th,.sk-actions-td{width:48px;text-align:center}.sk-row-menu-btn{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;background:none;border:none;border-radius:50%;cursor:pointer;color:var(--p-text-muted-color, #6b7280);transition:background .2s}.sk-row-menu-btn:hover{background:var(--p-content-hover-background, #f3f4f6);color:var(--p-text-color, #374151)}.sk-table-empty{text-align:center;padding:32px 16px;color:var(--p-text-muted-color, #6b7280);font-size:14px}:host ::ng-deep .p-datatable-thead>tr>th{background:var(--p-content-hover-background, #f9fafb)!important;font-weight:600!important;font-size:13px;padding:12px 16px!important;border-bottom:2px solid var(--p-content-border-color, #e5e7eb)!important;white-space:nowrap}:host ::ng-deep .p-datatable-tbody>tr>td{padding:12px 16px!important;border-bottom:1px solid var(--p-content-border-color, #e5e7eb)!important;vertical-align:middle}:host ::ng-deep .p-datatable-tbody>tr:hover{background:var(--p-content-hover-background, #f9fafb)!important}\n"] }]
        }], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: false }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }], filterGroups: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterGroups", required: false }] }], rowActions: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowActions", required: false }] }], searchPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchPlaceholder", required: false }] }], rowsPerPageOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowsPerPageOptions", required: false }] }], totalRecords: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalRecords", required: false }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], striped: [{ type: i0.Input, args: [{ isSignal: true, alias: "striped", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], searchChange: [{ type: i0.Output, args: ["searchChange"] }], filterChange: [{ type: i0.Output, args: ["filterChange"] }], pageChange: [{ type: i0.Output, args: ["pageChange"] }], sortChange: [{ type: i0.Output, args: ["sortChange"] }], rowActionSelect: [{ type: i0.Output, args: ["rowActionSelect"] }], _filterPopover: [{ type: i0.ViewChild, args: ['filterPopover', { isSignal: true }] }], _rowMenu: [{ type: i0.ViewChild, args: ['rowMenu', { isSignal: true }] }] } });

class SkTabsComponent {
    tabs = input([
        { value: '0', label: 'Resumen', content: 'Vista general. Información consolidada del componente y su estado actual.' },
        { value: '1', label: 'Detalles', content: 'Información específica y técnica del componente con sus propiedades.' },
        { value: '2', label: 'Historial', content: 'Registro de cambios y actividades históricas del componente.' },
    ], ...(ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []));
    activeValue = input('0', ...(ngDevMode ? [{ debugName: "activeValue" }] : /* istanbul ignore next */ []));
    scrollable = input(false, { ...(ngDevMode ? { debugName: "scrollable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkTabsComponent, isStandalone: true, selector: "sk-tabs", inputs: { tabs: { classPropertyName: "tabs", publicName: "tabs", isSignal: true, isRequired: false, transformFunction: null }, activeValue: { classPropertyName: "activeValue", publicName: "activeValue", isSignal: true, isRequired: false, transformFunction: null }, scrollable: { classPropertyName: "scrollable", publicName: "scrollable", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-tabs [value]="activeValue()" [scrollable]="scrollable()">
      <p-tablist>
        @for (tab of tabs(); track tab.value) {
          <p-tab [value]="tab.value">{{ tab.label }}</p-tab>
        }
      </p-tablist>
      <p-tabpanels>
        @for (tab of tabs(); track tab.value) {
          <p-tabpanel [value]="tab.value">
            <p style="margin:0;font-size:14px;color:var(--p-surface-600,#4b5563);">{{ tab.content }}</p>
          </p-tabpanel>
        }
      </p-tabpanels>
    </p-tabs>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Tabs, selector: "p-tabs", inputs: ["value", "scrollable", "lazy", "selectOnFocus", "showNavigators", "tabindex"], outputs: ["valueChange"] }, { kind: "component", type: TabList, selector: "p-tablist" }, { kind: "component", type: Tab, selector: "p-tab", inputs: ["value", "disabled"], outputs: ["valueChange"] }, { kind: "component", type: TabPanels, selector: "p-tabpanels" }, { kind: "component", type: TabPanel, selector: "p-tabpanel", inputs: ["lazy", "value"], outputs: ["valueChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-tabs', standalone: true, imports: [Tabs, TabList, Tab, TabPanels, TabPanel], template: `
    <p-tabs [value]="activeValue()" [scrollable]="scrollable()">
      <p-tablist>
        @for (tab of tabs(); track tab.value) {
          <p-tab [value]="tab.value">{{ tab.label }}</p-tab>
        }
      </p-tablist>
      <p-tabpanels>
        @for (tab of tabs(); track tab.value) {
          <p-tabpanel [value]="tab.value">
            <p style="margin:0;font-size:14px;color:var(--p-surface-600,#4b5563);">{{ tab.content }}</p>
          </p-tabpanel>
        }
      </p-tabpanels>
    </p-tabs>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { tabs: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabs", required: false }] }], activeValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeValue", required: false }] }], scrollable: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollable", required: false }] }] } });

class SkTagComponent {
    value = input('Etiqueta', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    severity = input('success', ...(ngDevMode ? [{ debugName: "severity" }] : /* istanbul ignore next */ []));
    rounded = input(false, { ...(ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    icon = input('', ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    showAll = input(false, { ...(ngDevMode ? { debugName: "showAll" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTagComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkTagComponent, isStandalone: true, selector: "sk-tag", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, severity: { classPropertyName: "severity", publicName: "severity", isSignal: true, isRequired: false, transformFunction: null }, rounded: { classPropertyName: "rounded", publicName: "rounded", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, showAll: { classPropertyName: "showAll", publicName: "showAll", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
      <p-tag [value]="value()" [severity]="severity()" [rounded]="rounded()" [icon]="icon()" />
      @if (showAll()) {
        <p-tag value="Éxito" severity="success" />
        <p-tag value="Info" severity="info" />
        <p-tag value="Aviso" severity="warn" />
        <p-tag value="Error" severity="danger" />
      }
    </div>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Tag, selector: "p-tag", inputs: ["styleClass", "severity", "value", "icon", "rounded"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTagComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-tag', standalone: true, imports: [Tag], template: `
    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
      <p-tag [value]="value()" [severity]="severity()" [rounded]="rounded()" [icon]="icon()" />
      @if (showAll()) {
        <p-tag value="Éxito" severity="success" />
        <p-tag value="Info" severity="info" />
        <p-tag value="Aviso" severity="warn" />
        <p-tag value="Error" severity="danger" />
      }
    </div>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], severity: [{ type: i0.Input, args: [{ isSignal: true, alias: "severity", required: false }] }], rounded: [{ type: i0.Input, args: [{ isSignal: true, alias: "rounded", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], showAll: [{ type: i0.Input, args: [{ isSignal: true, alias: "showAll", required: false }] }] } });

class SkTerminalComponent {
    terminalService;
    welcomeMessage = input('Bienvenido al terminal Skandia. Escribe "help" para ver los comandos disponibles.', ...(ngDevMode ? [{ debugName: "welcomeMessage" }] : /* istanbul ignore next */ []));
    prompt = input('skandia$ ', ...(ngDevMode ? [{ debugName: "prompt" }] : /* istanbul ignore next */ []));
    subscription;
    constructor(terminalService) {
        this.terminalService = terminalService;
    }
    ngOnInit() {
        this.subscription = this.terminalService.commandHandler.subscribe((command) => {
            let response;
            switch (command.trim().toLowerCase()) {
                case 'help':
                    response = 'Comandos disponibles: help, version, clear, date';
                    break;
                case 'version':
                    response = 'Skandia Design System v1.0.0';
                    break;
                case 'date':
                    response = new Date().toLocaleString('es-CO');
                    break;
                default: response = `Comando no reconocido: "${command}". Escribe "help" para ayuda.`;
            }
            this.terminalService.sendResponse(response);
        });
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTerminalComponent, deps: [{ token: i1$2.TerminalService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkTerminalComponent, isStandalone: true, selector: "sk-terminal", inputs: { welcomeMessage: { classPropertyName: "welcomeMessage", publicName: "welcomeMessage", isSignal: true, isRequired: false, transformFunction: null }, prompt: { classPropertyName: "prompt", publicName: "prompt", isSignal: true, isRequired: false, transformFunction: null } }, providers: [TerminalService], ngImport: i0, template: `
    <p-terminal
      [welcomeMessage]="welcomeMessage()"
      [prompt]="prompt()"
      [style]="{ height: '180px' }"
    />
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Terminal, selector: "p-terminal", inputs: ["welcomeMessage", "prompt", "styleClass", "response"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTerminalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-terminal', standalone: true, imports: [Terminal], providers: [TerminalService], template: `
    <p-terminal
      [welcomeMessage]="welcomeMessage()"
      [prompt]="prompt()"
      [style]="{ height: '180px' }"
    />
  `, styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.TerminalService }], propDecorators: { welcomeMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "welcomeMessage", required: false }] }], prompt: [{ type: i0.Input, args: [{ isSignal: true, alias: "prompt", required: false }] }] } });

class SkTextLinkComponent {
    size = input('large', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    href = input('', ...(ngDevMode ? [{ debugName: "href" }] : /* istanbul ignore next */ []));
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    iconLeft = input(false, ...(ngDevMode ? [{ debugName: "iconLeft" }] : /* istanbul ignore next */ []));
    iconRight = input(false, ...(ngDevMode ? [{ debugName: "iconRight" }] : /* istanbul ignore next */ []));
    external = input(false, ...(ngDevMode ? [{ debugName: "external" }] : /* istanbul ignore next */ []));
    clicked = output();
    isExternal = computed(() => {
        const v = this.external();
        return v === true || v === 'true' || v === '';
    }, ...(ngDevMode ? [{ debugName: "isExternal" }] : /* istanbul ignore next */ []));
    isIconLeft = computed(() => {
        const v = this.iconLeft();
        return !!v && v !== 'false';
    }, ...(ngDevMode ? [{ debugName: "isIconLeft" }] : /* istanbul ignore next */ []));
    isIconRight = computed(() => {
        const v = this.iconRight();
        return (!!v && v !== 'false') || this.isExternal();
    }, ...(ngDevMode ? [{ debugName: "isIconRight" }] : /* istanbul ignore next */ []));
    iconLeftClass = computed(() => {
        const v = this.iconLeft();
        return typeof v === 'string' && v !== 'true' && v !== 'false' ? v : null;
    }, ...(ngDevMode ? [{ debugName: "iconLeftClass" }] : /* istanbul ignore next */ []));
    iconRightClass = computed(() => {
        const v = this.iconRight();
        return typeof v === 'string' && v !== 'true' && v !== 'false' ? v : null;
    }, ...(ngDevMode ? [{ debugName: "iconRightClass" }] : /* istanbul ignore next */ []));
    linkClasses = computed(() => `sk-link sk-link--${this.size()}`, ...(ngDevMode ? [{ debugName: "linkClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTextLinkComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkTextLinkComponent, isStandalone: true, selector: "sk-text-link", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, href: { classPropertyName: "href", publicName: "href", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, iconLeft: { classPropertyName: "iconLeft", publicName: "iconLeft", isSignal: true, isRequired: false, transformFunction: null }, iconRight: { classPropertyName: "iconRight", publicName: "iconRight", isSignal: true, isRequired: false, transformFunction: null }, external: { classPropertyName: "external", publicName: "external", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { clicked: "clicked" }, ngImport: i0, template: "<a\r\n      [class]=\"linkClasses()\"\r\n      [href]=\"href() || undefined\"\r\n      [attr.target]=\"isExternal() ? '_blank' : null\"\r\n      [attr.rel]=\"isExternal() ? 'noopener noreferrer' : null\"\r\n      (click)=\"clicked.emit($event)\"\r\n    >\r\n      @if (isIconLeft()) {\r\n        <span class=\"sk-link__icon\" aria-hidden=\"true\">\r\n          @if (iconLeftClass()) {\r\n            <i [class]=\"iconLeftClass()\"></i>\r\n          } @else {\r\n            <svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n              <circle cx=\"8\" cy=\"8\" r=\"7\" stroke=\"currentColor\" stroke-width=\"1.25\"/>\r\n              <path d=\"M8 7.5v4\" stroke=\"currentColor\" stroke-width=\"1.25\" stroke-linecap=\"round\"/>\r\n              <circle cx=\"8\" cy=\"5.5\" r=\"0.75\" fill=\"currentColor\"/>\r\n            </svg>\r\n          }\r\n        </span>\r\n      }\r\n      <span class=\"sk-link__label\">{{ label() }}</span>\r\n      @if (isIconRight()) {\r\n        <span class=\"sk-link__icon\" aria-hidden=\"true\">\r\n          @if (iconRightClass()) {\r\n            <i [class]=\"iconRightClass()\"></i>\r\n          } @else {\r\n            <svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n              <circle cx=\"8\" cy=\"8\" r=\"7\" stroke=\"currentColor\" stroke-width=\"1.25\"/>\r\n              <path d=\"M8 7.5v4\" stroke=\"currentColor\" stroke-width=\"1.25\" stroke-linecap=\"round\"/>\r\n              <circle cx=\"8\" cy=\"5.5\" r=\"0.75\" fill=\"currentColor\"/>\r\n            </svg>\r\n          }\r\n        </span>\r\n      }\r\n    </a>\r\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}a.sk-link{text-decoration:none;outline:none}.sk-link{display:inline-flex;align-items:center;gap:4px;color:var(--texts-link, #0099de);font-family:Open Sans,sans-serif;font-weight:400;cursor:pointer}.sk-link:focus-visible{outline:2px solid var(--stroke-brand, #00c73d)!important;outline-offset:2px}.sk-link--small{font-size:12px;line-height:18px}.sk-link--small .sk-link__icon{width:12px;height:12px}.sk-link--large{font-size:16px;line-height:24px}.sk-link--large .sk-link__icon{width:16px;height:16px}.sk-link__icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--icon-link, #0099de)!important}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTextLinkComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-text-link', standalone: true, imports: [], template: "<a\r\n      [class]=\"linkClasses()\"\r\n      [href]=\"href() || undefined\"\r\n      [attr.target]=\"isExternal() ? '_blank' : null\"\r\n      [attr.rel]=\"isExternal() ? 'noopener noreferrer' : null\"\r\n      (click)=\"clicked.emit($event)\"\r\n    >\r\n      @if (isIconLeft()) {\r\n        <span class=\"sk-link__icon\" aria-hidden=\"true\">\r\n          @if (iconLeftClass()) {\r\n            <i [class]=\"iconLeftClass()\"></i>\r\n          } @else {\r\n            <svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n              <circle cx=\"8\" cy=\"8\" r=\"7\" stroke=\"currentColor\" stroke-width=\"1.25\"/>\r\n              <path d=\"M8 7.5v4\" stroke=\"currentColor\" stroke-width=\"1.25\" stroke-linecap=\"round\"/>\r\n              <circle cx=\"8\" cy=\"5.5\" r=\"0.75\" fill=\"currentColor\"/>\r\n            </svg>\r\n          }\r\n        </span>\r\n      }\r\n      <span class=\"sk-link__label\">{{ label() }}</span>\r\n      @if (isIconRight()) {\r\n        <span class=\"sk-link__icon\" aria-hidden=\"true\">\r\n          @if (iconRightClass()) {\r\n            <i [class]=\"iconRightClass()\"></i>\r\n          } @else {\r\n            <svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\r\n              <circle cx=\"8\" cy=\"8\" r=\"7\" stroke=\"currentColor\" stroke-width=\"1.25\"/>\r\n              <path d=\"M8 7.5v4\" stroke=\"currentColor\" stroke-width=\"1.25\" stroke-linecap=\"round\"/>\r\n              <circle cx=\"8\" cy=\"5.5\" r=\"0.75\" fill=\"currentColor\"/>\r\n            </svg>\r\n          }\r\n        </span>\r\n      }\r\n    </a>\r\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}a.sk-link{text-decoration:none;outline:none}.sk-link{display:inline-flex;align-items:center;gap:4px;color:var(--texts-link, #0099de);font-family:Open Sans,sans-serif;font-weight:400;cursor:pointer}.sk-link:focus-visible{outline:2px solid var(--stroke-brand, #00c73d)!important;outline-offset:2px}.sk-link--small{font-size:12px;line-height:18px}.sk-link--small .sk-link__icon{width:12px;height:12px}.sk-link--large{font-size:16px;line-height:24px}.sk-link--large .sk-link__icon{width:16px;height:16px}.sk-link__icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--icon-link, #0099de)!important}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], href: [{ type: i0.Input, args: [{ isSignal: true, alias: "href", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], iconLeft: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconLeft", required: false }] }], iconRight: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconRight", required: false }] }], external: [{ type: i0.Input, args: [{ isSignal: true, alias: "external", required: false }] }], clicked: [{ type: i0.Output, args: ["clicked"] }] } });

let _textareaUid = 0;
class SkTextareaComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    helpText = input('', ...(ngDevMode ? [{ debugName: "helpText" }] : /* istanbul ignore next */ []));
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    rows = input(5, ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoResize = input(false, { ...(ngDevMode ? { debugName: "autoResize" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    inputId = `sk-textarea-${_textareaUid++}`;
    innerControl = new FormControl('', { nonNullable: true });
    _cvaDisabled = signal(false, ...(ngDevMode ? [{ debugName: "_cvaDisabled" }] : /* istanbul ignore next */ []));
    _isDisabled = computed(() => this.disabled() || this._cvaDisabled(), ...(ngDevMode ? [{ debugName: "_isDisabled" }] : /* istanbul ignore next */ []));
    _onChange = () => { };
    onTouched = () => { };
    sub;
    constructor() {
        this.sub = this.innerControl.valueChanges.subscribe(val => {
            this._onChange(val);
            this.valueChange.emit(val);
        });
        effect(() => {
            this._isDisabled()
                ? this.innerControl.disable({ emitEvent: false })
                : this.innerControl.enable({ emitEvent: false });
        });
    }
    writeValue(val) { this.innerControl.setValue(val ?? '', { emitEvent: false }); }
    registerOnChange(fn) { this._onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(d) { this._cvaDisabled.set(d); }
    ngOnDestroy() { this.sub.unsubscribe(); }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTextareaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkTextareaComponent, isStandalone: true, selector: "sk-textarea", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, helpText: { classPropertyName: "helpText", publicName: "helpText", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, autoResize: { classPropertyName: "autoResize", publicName: "autoResize", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkTextareaComponent), multi: true }], ngImport: i0, template: "<div\r\n  class=\"sk-textarea\"\r\n  [class.sk-textarea--fluid]=\"fluid()\"\r\n  [class.sk-textarea--invalid]=\"invalid()\"\r\n  [class.sk-textarea--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-textarea__floatlabel\">\r\n    <textarea\r\n      pTextarea\r\n      [id]=\"inputId\"\r\n      [formControl]=\"innerControl\"\r\n      [rows]=\"rows()\"\r\n      [autoResize]=\"autoResize()\"\r\n      [attr.placeholder]=\"placeholder() || null\"\r\n      [invalid]=\"invalid()\"\r\n      (blur)=\"onTouched()\"\r\n      class=\"sk-textarea__field\"\r\n    ></textarea>\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-textarea__help sk-textarea__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-textarea__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-textarea{display:flex;flex-direction:column;gap:4px}.sk-textarea--fluid,.sk-textarea--fluid .sk-textarea__floatlabel,.sk-textarea--fluid .sk-textarea__field{width:100%}.sk-textarea__field{width:100%;min-height:50px;padding-block-start:20px!important;padding-block-end:10px!important;padding-inline:12px;border-radius:4px;border:1px solid var(--stroke-grey-light, #dddddd);background:var(--background-principal, #ffffff);font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);color:var(--texts-dark, #404040);box-sizing:border-box;resize:vertical;outline:none;transition:border-color .15s ease}::ng-deep .sk-textarea__floatlabel label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;color:var(--texts-medium, #666666)}.sk-textarea:not(.sk-textarea--disabled):not(.sk-textarea--invalid):focus-within .sk-textarea__field{border-color:var(--stroke-brand, #00c73d);box-shadow:none}.sk-textarea--invalid .sk-textarea__field{border-color:var(--color-error, #e03430)!important}.sk-textarea--disabled .sk-textarea__field{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;color:var(--texts-medium, #666666)!important;cursor:not-allowed;resize:none}.sk-textarea__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-textarea__help--error{color:var(--color-error, #e03430)}\n"], dependencies: [{ kind: "directive", type: Textarea, selector: "[pTextarea], [pInputTextarea]", inputs: ["pTextareaPT", "pTextareaUnstyled", "autoResize", "pSize", "variant", "fluid", "invalid"], outputs: ["onResize"] }, { kind: "component", type: FloatLabel, selector: "p-floatlabel, p-floatLabel, p-float-label", inputs: ["variant"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTextareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-textarea', standalone: true, imports: [Textarea, FloatLabel, ReactiveFormsModule], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SkTextareaComponent), multi: true }], template: "<div\r\n  class=\"sk-textarea\"\r\n  [class.sk-textarea--fluid]=\"fluid()\"\r\n  [class.sk-textarea--invalid]=\"invalid()\"\r\n  [class.sk-textarea--disabled]=\"_isDisabled()\"\r\n>\r\n  <p-floatlabel variant=\"in\" class=\"sk-textarea__floatlabel\">\r\n    <textarea\r\n      pTextarea\r\n      [id]=\"inputId\"\r\n      [formControl]=\"innerControl\"\r\n      [rows]=\"rows()\"\r\n      [autoResize]=\"autoResize()\"\r\n      [attr.placeholder]=\"placeholder() || null\"\r\n      [invalid]=\"invalid()\"\r\n      (blur)=\"onTouched()\"\r\n      class=\"sk-textarea__field\"\r\n    ></textarea>\r\n    <label [for]=\"inputId\">{{ label() }}</label>\r\n  </p-floatlabel>\r\n\r\n  @if (invalid() && errorMessage()) {\r\n    <small class=\"sk-textarea__help sk-textarea__help--error\">{{ errorMessage() }}</small>\r\n  } @else if (helpText()) {\r\n    <small class=\"sk-textarea__help\">{{ helpText() }}</small>\r\n  }\r\n</div>\r\n", styles: ["@charset \"UTF-8\";:host{display:block}.sk-textarea{display:flex;flex-direction:column;gap:4px}.sk-textarea--fluid,.sk-textarea--fluid .sk-textarea__floatlabel,.sk-textarea--fluid .sk-textarea__field{width:100%}.sk-textarea__field{width:100%;min-height:50px;padding-block-start:20px!important;padding-block-end:10px!important;padding-inline:12px;border-radius:4px;border:1px solid var(--stroke-grey-light, #dddddd);background:var(--background-principal, #ffffff);font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--label-body-2-size, 14px);font-weight:500;line-height:var(--label-body-2-line-height, 20px);color:var(--texts-dark, #404040);box-sizing:border-box;resize:vertical;outline:none;transition:border-color .15s ease}::ng-deep .sk-textarea__floatlabel label{font-family:var(--body),\"Open Sans\",sans-serif;font-size:14px;color:var(--texts-medium, #666666)}.sk-textarea:not(.sk-textarea--disabled):not(.sk-textarea--invalid):focus-within .sk-textarea__field{border-color:var(--stroke-brand, #00c73d);box-shadow:none}.sk-textarea--invalid .sk-textarea__field{border-color:var(--color-error, #e03430)!important}.sk-textarea--disabled .sk-textarea__field{background:var(--background-grey-light, #f7f7f7)!important;border-color:var(--stroke-grey-light, #dddddd)!important;color:var(--texts-medium, #666666)!important;cursor:not-allowed;resize:none}.sk-textarea__help{display:block;font-family:var(--body),\"Open Sans\",sans-serif;font-size:var(--caption-body-3-size, 11px);font-weight:500;line-height:var(--caption-body-3-line-height, 18px);color:var(--texts-medium, #666666);padding:0 4px}.sk-textarea__help--error{color:var(--color-error, #e03430)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], helpText: [{ type: i0.Input, args: [{ isSignal: true, alias: "helpText", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], autoResize: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoResize", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkTieredMenuComponent {
    model = input([
        { label: 'Archivo', icon: 'pi pi-file', items: [
                { label: 'Nuevo', icon: 'pi pi-plus' },
                { label: 'Abrir reciente', icon: 'pi pi-clock', items: [
                        { label: 'Proyecto A' },
                        { label: 'Proyecto B' },
                        { label: 'Proyecto C' },
                    ] },
                { label: 'Guardar', icon: 'pi pi-save' },
            ] },
        { label: 'Herramientas', icon: 'pi pi-wrench', items: [
                { label: 'Opciones', icon: 'pi pi-cog' },
                { label: 'Preferencias', icon: 'pi pi-sliders-v' },
            ] },
        { separator: true },
        { label: 'Salir', icon: 'pi pi-sign-out' },
    ], ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTieredMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkTieredMenuComponent, isStandalone: true, selector: "sk-tieredmenu", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<p-tieredmenu [model]="model()" />`, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: TieredMenu, selector: "p-tieredMenu, p-tieredmenu, p-tiered-menu", inputs: ["model", "popup", "style", "styleClass", "breakpoint", "autoZIndex", "baseZIndex", "autoDisplay", "showTransitionOptions", "hideTransitionOptions", "id", "ariaLabel", "ariaLabelledBy", "disabled", "tabindex", "appendTo", "motionOptions"], outputs: ["onShow", "onHide"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTieredMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-tieredmenu', standalone: true, imports: [TieredMenu], template: `<p-tieredmenu [model]="model()" />`, styles: [":host{display:block}\n"] }]
        }], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }] } });

class SkTimelineComponent {
    events = input([
        { title: 'Inicio del proyecto', date: 'Enero 2024', icon: 'pi pi-flag' },
        { title: 'Primer MVP', date: 'Marzo 2024', icon: 'pi pi-check' },
        { title: 'Beta pública', date: 'Junio 2024', icon: 'pi pi-users' },
        { title: 'Lanzamiento v1.0', date: 'Octubre 2024', icon: 'pi pi-star' },
    ], ...(ngDevMode ? [{ debugName: "events" }] : /* istanbul ignore next */ []));
    align = input('left', ...(ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []));
    layout = input('vertical', ...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTimelineComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkTimelineComponent, isStandalone: true, selector: "sk-timeline", inputs: { events: { classPropertyName: "events", publicName: "events", isSignal: true, isRequired: false, transformFunction: null }, align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null }, layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-timeline [value]="events()" [align]="align()" [layout]="layout()">
      <ng-template #content let-event>
        <div style="padding:4px 0;">
          <div style="font-weight:600;font-size:13px;">{{ event.title }}</div>
          <div style="font-size:12px;color:var(--p-surface-500,#6b7280);">{{ event.date }}</div>
        </div>
      </ng-template>
      <ng-template #marker let-event>
        <span style="display:flex;width:2rem;height:2rem;align-items:center;justify-content:center;border-radius:50%;background:var(--p-primary-color,#22c55e);color:#fff;font-size:12px;">
          <i [class]="event.icon"></i>
        </span>
      </ng-template>
    </p-timeline>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Timeline, selector: "p-timeline", inputs: ["value", "styleClass", "align", "layout"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTimelineComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-timeline', standalone: true, imports: [Timeline], template: `
    <p-timeline [value]="events()" [align]="align()" [layout]="layout()">
      <ng-template #content let-event>
        <div style="padding:4px 0;">
          <div style="font-weight:600;font-size:13px;">{{ event.title }}</div>
          <div style="font-size:12px;color:var(--p-surface-500,#6b7280);">{{ event.date }}</div>
        </div>
      </ng-template>
      <ng-template #marker let-event>
        <span style="display:flex;width:2rem;height:2rem;align-items:center;justify-content:center;border-radius:50%;background:var(--p-primary-color,#22c55e);color:#fff;font-size:12px;">
          <i [class]="event.icon"></i>
        </span>
      </ng-template>
    </p-timeline>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { events: [{ type: i0.Input, args: [{ isSignal: true, alias: "events", required: false }] }], align: [{ type: i0.Input, args: [{ isSignal: true, alias: "align", required: false }] }], layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: false }] }] } });

class SkToastComponent {
    position = input('top-right', ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    life = input(3000, ...(ngDevMode ? [{ debugName: "life" }] : /* istanbul ignore next */ []));
    messageService = inject(MessageService);
    show(severity, summary, detail) {
        this.messageService.add({ severity, summary, detail, life: this.life() });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkToastComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkToastComponent, isStandalone: true, selector: "sk-toast", inputs: { position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, life: { classPropertyName: "life", publicName: "life", isSignal: true, isRequired: false, transformFunction: null } }, providers: [MessageService], ngImport: i0, template: `<p-toast [position]="position()" [life]="life()" />`, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: Toast, selector: "p-toast", inputs: ["key", "autoZIndex", "baseZIndex", "life", "styleClass", "position", "preventOpenDuplicates", "preventDuplicates", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions", "motionOptions", "breakpoints"], outputs: ["onClose"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkToastComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-toast', standalone: true, imports: [Toast], providers: [MessageService], template: `<p-toast [position]="position()" [life]="life()" />`, styles: [":host{display:block}\n"] }]
        }], propDecorators: { position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: false }] }], life: [{ type: i0.Input, args: [{ isSignal: true, alias: "life", required: false }] }] } });

class SkToggleButtonComponent {
    checked = false;
    onLabel = input('Activado', ...(ngDevMode ? [{ debugName: "onLabel" }] : /* istanbul ignore next */ []));
    offLabel = input('Desactivado', ...(ngDevMode ? [{ debugName: "offLabel" }] : /* istanbul ignore next */ []));
    onIcon = input('pi pi-check', ...(ngDevMode ? [{ debugName: "onIcon" }] : /* istanbul ignore next */ []));
    offIcon = input('pi pi-times', ...(ngDevMode ? [{ debugName: "offIcon" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    valueChange = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkToggleButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkToggleButtonComponent, isStandalone: true, selector: "sk-togglebutton", inputs: { onLabel: { classPropertyName: "onLabel", publicName: "onLabel", isSignal: true, isRequired: false, transformFunction: null }, offLabel: { classPropertyName: "offLabel", publicName: "offLabel", isSignal: true, isRequired: false, transformFunction: null }, onIcon: { classPropertyName: "onIcon", publicName: "onIcon", isSignal: true, isRequired: false, transformFunction: null }, offIcon: { classPropertyName: "offIcon", publicName: "offIcon", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <p-togglebutton
      [(ngModel)]="checked"
      [onLabel]="onLabel()"
      [offLabel]="offLabel()"
      [onIcon]="onIcon()"
      [offIcon]="offIcon()"
      [disabled]="disabled()"
      (onChange)="valueChange.emit($event)"
    />
  `, isInline: true, styles: [":host{display:inline-flex}\n"], dependencies: [{ kind: "component", type: ToggleButton, selector: "p-toggleButton, p-togglebutton, p-toggle-button", inputs: ["onLabel", "offLabel", "onIcon", "offIcon", "ariaLabel", "ariaLabelledBy", "styleClass", "inputId", "tabindex", "iconPos", "autofocus", "size", "allowEmpty", "fluid"], outputs: ["onChange"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkToggleButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-togglebutton', standalone: true, imports: [ToggleButton, FormsModule], template: `
    <p-togglebutton
      [(ngModel)]="checked"
      [onLabel]="onLabel()"
      [offLabel]="offLabel()"
      [onIcon]="onIcon()"
      [offIcon]="offIcon()"
      [disabled]="disabled()"
      (onChange)="valueChange.emit($event)"
    />
  `, styles: [":host{display:inline-flex}\n"] }]
        }], propDecorators: { onLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "onLabel", required: false }] }], offLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "offLabel", required: false }] }], onIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "onIcon", required: false }] }], offIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "offIcon", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkToolbarComponent {
    startContent = input('', ...(ngDevMode ? [{ debugName: "startContent" }] : /* istanbul ignore next */ []));
    centerContent = input('', ...(ngDevMode ? [{ debugName: "centerContent" }] : /* istanbul ignore next */ []));
    endContent = input('', ...(ngDevMode ? [{ debugName: "endContent" }] : /* istanbul ignore next */ []));
    styleClass = input('', ...(ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkToolbarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkToolbarComponent, isStandalone: true, selector: "sk-toolbar", inputs: { startContent: { classPropertyName: "startContent", publicName: "startContent", isSignal: true, isRequired: false, transformFunction: null }, centerContent: { classPropertyName: "centerContent", publicName: "centerContent", isSignal: true, isRequired: false, transformFunction: null }, endContent: { classPropertyName: "endContent", publicName: "endContent", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-toolbar [styleClass]="styleClass()">
      <ng-template #start>
        <span class="sk-toolbar__start">{{ startContent() }}</span>
      </ng-template>
      <ng-template #center>
        <span class="sk-toolbar__center">{{ centerContent() }}</span>
      </ng-template>
      <ng-template #end>
        <span class="sk-toolbar__end">{{ endContent() }}</span>
      </ng-template>
    </p-toolbar>
  `, isInline: true, styles: [":host{display:block}.sk-toolbar__start{font-weight:600;font-size:15px;color:var(--texts-dark, #404040)}.sk-toolbar__center{font-size:14px;color:var(--texts-medium, #666)}.sk-toolbar__end{font-size:13px;color:var(--texts-medium, #888)}\n"], dependencies: [{ kind: "component", type: Toolbar, selector: "p-toolbar", inputs: ["styleClass", "ariaLabelledBy"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-toolbar', standalone: true, imports: [Toolbar], template: `
    <p-toolbar [styleClass]="styleClass()">
      <ng-template #start>
        <span class="sk-toolbar__start">{{ startContent() }}</span>
      </ng-template>
      <ng-template #center>
        <span class="sk-toolbar__center">{{ centerContent() }}</span>
      </ng-template>
      <ng-template #end>
        <span class="sk-toolbar__end">{{ endContent() }}</span>
      </ng-template>
    </p-toolbar>
  `, styles: [":host{display:block}.sk-toolbar__start{font-weight:600;font-size:15px;color:var(--texts-dark, #404040)}.sk-toolbar__center{font-size:14px;color:var(--texts-medium, #666)}.sk-toolbar__end{font-size:13px;color:var(--texts-medium, #888)}\n"] }]
        }], propDecorators: { startContent: [{ type: i0.Input, args: [{ isSignal: true, alias: "startContent", required: false }] }], centerContent: [{ type: i0.Input, args: [{ isSignal: true, alias: "centerContent", required: false }] }], endContent: [{ type: i0.Input, args: [{ isSignal: true, alias: "endContent", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }] } });

class SkTooltipComponent {
    content = input('Información adicional', ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    position = input('top', ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    showDelay = input(0, { ...(ngDevMode ? { debugName: "showDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    hideDelay = input(0, { ...(ngDevMode ? { debugName: "hideDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    escape = input(true, { ...(ngDevMode ? { debugName: "escape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    label = input('Mostrar tooltip', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTooltipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkTooltipComponent, isStandalone: true, selector: "sk-tooltip", inputs: { content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: false, transformFunction: null }, position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, showDelay: { classPropertyName: "showDelay", publicName: "showDelay", isSignal: true, isRequired: false, transformFunction: null }, hideDelay: { classPropertyName: "hideDelay", publicName: "hideDelay", isSignal: true, isRequired: false, transformFunction: null }, escape: { classPropertyName: "escape", publicName: "escape", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <span
      class="sk-tooltip__trigger"
      [pTooltip]="content()"
      [tooltipPosition]="position()"
      [showDelay]="showDelay()"
      [hideDelay]="hideDelay()"
      [escape]="escape()"
    >
      @if (label()) {
        <p-button [label]="label()" severity="secondary" size="small" />
      }
      <ng-content />
    </span>
  `, isInline: true, styles: [":host{display:inline-flex}.sk-tooltip__trigger{display:contents}\n"], dependencies: [{ kind: "directive", type: Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "component", type: Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-tooltip', standalone: true, imports: [Tooltip, Button], template: `
    <span
      class="sk-tooltip__trigger"
      [pTooltip]="content()"
      [tooltipPosition]="position()"
      [showDelay]="showDelay()"
      [hideDelay]="hideDelay()"
      [escape]="escape()"
    >
      @if (label()) {
        <p-button [label]="label()" severity="secondary" size="small" />
      }
      <ng-content />
    </span>
  `, styles: [":host{display:inline-flex}.sk-tooltip__trigger{display:contents}\n"] }]
        }], propDecorators: { content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: false }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: false }] }], showDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDelay", required: false }] }], hideDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideDelay", required: false }] }], escape: [{ type: i0.Input, args: [{ isSignal: true, alias: "escape", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

class SkTreeComponent {
    nodes = input([
        {
            key: '0', label: 'Fondos de inversión', icon: 'pi pi-fw pi-chart-line', expanded: true,
            children: [
                {
                    key: '0-0', label: 'Conservador', icon: 'pi pi-fw pi-shield', expanded: false,
                    children: [
                        { key: '0-0-0', label: 'Renta fija local', icon: 'pi pi-fw pi-lock' },
                        { key: '0-0-1', label: 'Deuda pública', icon: 'pi pi-fw pi-building' },
                    ],
                },
                {
                    key: '0-1', label: 'Moderado', icon: 'pi pi-fw pi-chart-bar',
                    children: [
                        { key: '0-1-0', label: 'Acciones nacionales', icon: 'pi pi-fw pi-trending-up' },
                        { key: '0-1-1', label: 'Mixto balanceado', icon: 'pi pi-fw pi-sync' },
                    ],
                },
            ],
        },
        {
            key: '1', label: 'Seguros de vida', icon: 'pi pi-fw pi-heart',
            children: [
                { key: '1-0', label: 'Póliza individual', icon: 'pi pi-fw pi-user' },
                { key: '1-1', label: 'Póliza familiar', icon: 'pi pi-fw pi-users' },
            ],
        },
    ], ...(ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []));
    selectionMode = input(null, ...(ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []));
    filter = input(false, { ...(ngDevMode ? { debugName: "filter" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    filterPlaceholder = input('Buscar...', ...(ngDevMode ? [{ debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []));
    selectionChange = output();
    nodeSelected = output();
    nodeUnselected = output();
    _selection = null;
    onSelectionChange(event) {
        this._selection = event ?? null;
        this.selectionChange.emit(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTreeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkTreeComponent, isStandalone: true, selector: "sk-tree", inputs: { nodes: { classPropertyName: "nodes", publicName: "nodes", isSignal: true, isRequired: false, transformFunction: null }, selectionMode: { classPropertyName: "selectionMode", publicName: "selectionMode", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceholder: { classPropertyName: "filterPlaceholder", publicName: "filterPlaceholder", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange", nodeSelected: "nodeSelected", nodeUnselected: "nodeUnselected" }, ngImport: i0, template: `
    <p-tree
      styleClass="sk-tree"
      [value]="nodes()"
      [selectionMode]="selectionMode()"
      [selection]="_selection"
      (selectionChange)="onSelectionChange($event)"
      [filter]="filter()"
      [filterPlaceholder]="filterPlaceholder()"
      (onNodeSelect)="nodeSelected.emit($event)"
      (onNodeUnselect)="nodeUnselected.emit($event)"
    />
  `, isInline: true, styles: [":host{display:block}:host ::ng-deep .sk-tree.p-tree{border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);padding:8px}:host ::ng-deep .sk-tree .p-tree-node-content{padding:5px 8px;border-radius:var(--bordes-s, 4px);color:var(--texts-dark, #404040);font-size:14px;transition:background .15s}:host ::ng-deep .sk-tree .p-tree-node-content:hover{background:color-mix(in srgb,var(--color-primary, #00c73d),white 92%)}:host ::ng-deep .sk-tree .p-tree-node-content.p-highlight{background:color-mix(in srgb,var(--color-primary, #00c73d),white 85%)}:host ::ng-deep .sk-tree .p-tree-node-icon{color:var(--color-primary, #00c73d);font-size:14px;margin-right:6px}:host ::ng-deep .sk-tree .p-tree-node-toggle-button{color:var(--texts-medium, #888);width:20px;height:20px;margin-right:4px}:host ::ng-deep .sk-tree .p-tree-node-toggle-button:hover{color:var(--color-primary, #00c73d)}:host ::ng-deep .sk-tree .p-tree-filter{display:flex;padding:4px 4px 8px}:host ::ng-deep .sk-tree .p-tree-filter .p-inputtext{width:100%;border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);padding:6px 12px;font-size:14px}:host ::ng-deep .sk-tree .p-tree-filter .p-inputtext:focus{outline:none;border-color:var(--color-primary, #00c73d);box-shadow:0 0 0 2px color-mix(in srgb,var(--color-primary, #00c73d),white 80%)}\n"], dependencies: [{ kind: "component", type: Tree, selector: "p-tree", inputs: ["value", "selectionMode", "loadingMode", "selection", "styleClass", "contextMenu", "contextMenuSelectionMode", "contextMenuSelection", "draggableScope", "droppableScope", "draggableNodes", "droppableNodes", "metaKeySelection", "propagateSelectionUp", "propagateSelectionDown", "loading", "loadingIcon", "emptyMessage", "ariaLabel", "togglerAriaLabel", "ariaLabelledBy", "validateDrop", "filter", "filterInputAutoFocus", "filterBy", "filterMode", "filterOptions", "filterPlaceholder", "filteredNodes", "filterLocale", "scrollHeight", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "indentation", "_templateMap", "trackBy", "highlightOnSelect"], outputs: ["selectionChange", "contextMenuSelectionChange", "onNodeSelect", "onNodeUnselect", "onNodeExpand", "onNodeCollapse", "onNodeContextMenuSelect", "onNodeDoubleClick", "onNodeDrop", "onLazyLoad", "onScroll", "onScrollIndexChange", "onFilter"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTreeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-tree', standalone: true, imports: [Tree], template: `
    <p-tree
      styleClass="sk-tree"
      [value]="nodes()"
      [selectionMode]="selectionMode()"
      [selection]="_selection"
      (selectionChange)="onSelectionChange($event)"
      [filter]="filter()"
      [filterPlaceholder]="filterPlaceholder()"
      (onNodeSelect)="nodeSelected.emit($event)"
      (onNodeUnselect)="nodeUnselected.emit($event)"
    />
  `, styles: [":host{display:block}:host ::ng-deep .sk-tree.p-tree{border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);padding:8px}:host ::ng-deep .sk-tree .p-tree-node-content{padding:5px 8px;border-radius:var(--bordes-s, 4px);color:var(--texts-dark, #404040);font-size:14px;transition:background .15s}:host ::ng-deep .sk-tree .p-tree-node-content:hover{background:color-mix(in srgb,var(--color-primary, #00c73d),white 92%)}:host ::ng-deep .sk-tree .p-tree-node-content.p-highlight{background:color-mix(in srgb,var(--color-primary, #00c73d),white 85%)}:host ::ng-deep .sk-tree .p-tree-node-icon{color:var(--color-primary, #00c73d);font-size:14px;margin-right:6px}:host ::ng-deep .sk-tree .p-tree-node-toggle-button{color:var(--texts-medium, #888);width:20px;height:20px;margin-right:4px}:host ::ng-deep .sk-tree .p-tree-node-toggle-button:hover{color:var(--color-primary, #00c73d)}:host ::ng-deep .sk-tree .p-tree-filter{display:flex;padding:4px 4px 8px}:host ::ng-deep .sk-tree .p-tree-filter .p-inputtext{width:100%;border:1px solid var(--stroke-grey-light, #e5e7eb);border-radius:var(--bordes-s, 4px);padding:6px 12px;font-size:14px}:host ::ng-deep .sk-tree .p-tree-filter .p-inputtext:focus{outline:none;border-color:var(--color-primary, #00c73d);box-shadow:0 0 0 2px color-mix(in srgb,var(--color-primary, #00c73d),white 80%)}\n"] }]
        }], propDecorators: { nodes: [{ type: i0.Input, args: [{ isSignal: true, alias: "nodes", required: false }] }], selectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMode", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], filterPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceholder", required: false }] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], nodeSelected: [{ type: i0.Output, args: ["nodeSelected"] }], nodeUnselected: [{ type: i0.Output, args: ["nodeUnselected"] }] } });

class SkTreeSelectComponent {
    value = null;
    options = input([
        { key: '0', label: 'Documentos', icon: 'pi pi-fw pi-inbox', children: [
                { key: '0-0', label: 'Trabajo', icon: 'pi pi-fw pi-cog', children: [
                        { key: '0-0-0', label: 'Informe.pdf', icon: 'pi pi-fw pi-file' },
                    ] },
                { key: '0-1', label: 'Personal', icon: 'pi pi-fw pi-home', children: [
                        { key: '0-1-0', label: 'Foto.jpg', icon: 'pi pi-fw pi-image' },
                    ] },
            ] },
        { key: '1', label: 'Escritorio', icon: 'pi pi-fw pi-desktop', children: [
                { key: '1-0', label: 'Video.mp4', icon: 'pi pi-fw pi-video' },
            ] },
    ], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    placeholder = input('Selecciona un nodo', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selectionMode = input('single', ...(ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []));
    valueChange = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTreeSelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.9", type: SkTreeSelectComponent, isStandalone: true, selector: "sk-treeselect", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, selectionMode: { classPropertyName: "selectionMode", publicName: "selectionMode", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <p-treeselect
      style="width: 100%"
      [(ngModel)]="value"
      [options]="options()"
      [placeholder]="placeholder()"
      [disabled]="disabled()"
      [selectionMode]="selectionMode()"
      (onChange)="valueChange.emit($event)"
    />
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: TreeSelect, selector: "p-treeSelect, p-treeselect, p-tree-select", inputs: ["inputId", "scrollHeight", "metaKeySelection", "display", "selectionMode", "tabindex", "ariaLabel", "ariaLabelledBy", "placeholder", "panelClass", "panelStyle", "panelStyleClass", "containerStyle", "containerStyleClass", "labelStyle", "labelStyleClass", "overlayOptions", "emptyMessage", "filter", "filterBy", "filterMode", "filterPlaceholder", "filterLocale", "filterInputAutoFocus", "propagateSelectionDown", "propagateSelectionUp", "showClear", "resetFilterOnHide", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "autofocus", "options", "loading", "loadingMode", "size", "variant", "fluid", "appendTo", "motionOptions"], outputs: ["onNodeExpand", "onNodeCollapse", "onShow", "onHide", "onClear", "onFilter", "onFocus", "onBlur", "onNodeUnselect", "onNodeSelect"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTreeSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-treeselect', standalone: true, imports: [TreeSelect, FormsModule], template: `
    <p-treeselect
      style="width: 100%"
      [(ngModel)]="value"
      [options]="options()"
      [placeholder]="placeholder()"
      [disabled]="disabled()"
      [selectionMode]="selectionMode()"
      (onChange)="valueChange.emit($event)"
    />
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], selectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMode", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

class SkTreeTableComponent {
    nodes = input([
        { data: { name: 'src', size: '—', type: 'Carpeta' }, expanded: true, children: [
                { data: { name: 'app', size: '—', type: 'Carpeta' }, children: [
                        { data: { name: 'app.component.ts', size: '4 KB', type: 'TypeScript' } },
                    ] },
                { data: { name: 'main.ts', size: '2 KB', type: 'TypeScript' } },
            ] },
        { data: { name: 'package.json', size: '1 KB', type: 'JSON' } },
    ], ...(ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []));
    columns = input([
        { field: 'name', header: 'Nombre' },
        { field: 'size', header: 'Tamaño' },
        { field: 'type', header: 'Tipo' },
    ], ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    scrollable = input(false, { ...(ngDevMode ? { debugName: "scrollable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    scrollHeight = input('300px', ...(ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTreeTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkTreeTableComponent, isStandalone: true, selector: "sk-treetable", inputs: { nodes: { classPropertyName: "nodes", publicName: "nodes", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, scrollable: { classPropertyName: "scrollable", publicName: "scrollable", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <p-treetable [value]="nodes()" [scrollable]="scrollable()" [scrollHeight]="scrollHeight()" [tableStyle]="{ 'min-width': '100%' }">
      <ng-template #header>
        <tr>
          @for (col of columns(); track col.field) {
            <th [ttSortableColumn]="col.field">{{ col.header }}</th>
          }
        </tr>
      </ng-template>
      <ng-template #body let-rowNode let-rowData="rowData">
        <tr [ttRow]="rowNode">
          @for (col of columns(); track col.field; let i = $index) {
            <td>
              @if (i === 0) { <p-treetable-toggler [rowNode]="rowNode" /> }
              {{ rowData[col.field] }}
            </td>
          }
        </tr>
      </ng-template>
    </p-treetable>
  `, isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: TreeTableModule }, { kind: "component", type: i1$3.TreeTable, selector: "p-treeTable, p-treetable, p-tree-table", inputs: ["columns", "styleClass", "tableStyle", "tableStyleClass", "autoLayout", "lazy", "lazyLoadOnInit", "paginator", "rows", "first", "pageLinks", "rowsPerPageOptions", "alwaysShowPaginator", "paginatorPosition", "paginatorStyleClass", "paginatorDropdownAppendTo", "currentPageReportTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showFirstLastIcon", "showPageLinks", "defaultSortOrder", "sortMode", "resetPageOnSort", "customSort", "selectionMode", "contextMenuSelection", "contextMenuSelectionMode", "dataKey", "metaKeySelection", "compareSelectionBy", "rowHover", "loading", "loadingIcon", "showLoader", "scrollable", "scrollHeight", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "virtualScrollDelay", "frozenWidth", "frozenColumns", "resizableColumns", "columnResizeMode", "reorderableColumns", "contextMenu", "rowTrackBy", "filters", "globalFilterFields", "filterDelay", "filterMode", "filterLocale", "paginatorLocale", "totalRecords", "sortField", "sortOrder", "multiSortMeta", "selection", "value", "virtualRowHeight", "selectionKeys", "showGridlines"], outputs: ["selectionChange", "contextMenuSelectionChange", "onFilter", "onNodeExpand", "onNodeCollapse", "onPage", "onSort", "onLazyLoad", "sortFunction", "onColResize", "onColReorder", "onNodeSelect", "onNodeUnselect", "onContextMenuSelect", "onHeaderCheckboxToggle", "onEditInit", "onEditComplete", "onEditCancel", "selectionKeysChange"] }, { kind: "component", type: i1$3.TreeTableToggler, selector: "p-treeTableToggler, p-treetabletoggler, p-treetable-toggler", inputs: ["rowNode"] }, { kind: "directive", type: i1$3.TTSortableColumn, selector: "[ttSortableColumn]", inputs: ["ttSortableColumn", "ttSortableColumnDisabled"] }, { kind: "directive", type: i1$3.TTRow, selector: "[ttRow]", inputs: ["ttRow"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkTreeTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-treetable', standalone: true, imports: [TreeTableModule], template: `
    <p-treetable [value]="nodes()" [scrollable]="scrollable()" [scrollHeight]="scrollHeight()" [tableStyle]="{ 'min-width': '100%' }">
      <ng-template #header>
        <tr>
          @for (col of columns(); track col.field) {
            <th [ttSortableColumn]="col.field">{{ col.header }}</th>
          }
        </tr>
      </ng-template>
      <ng-template #body let-rowNode let-rowData="rowData">
        <tr [ttRow]="rowNode">
          @for (col of columns(); track col.field; let i = $index) {
            <td>
              @if (i === 0) { <p-treetable-toggler [rowNode]="rowNode" /> }
              {{ rowData[col.field] }}
            </td>
          }
        </tr>
      </ng-template>
    </p-treetable>
  `, styles: [":host{display:block}\n"] }]
        }], propDecorators: { nodes: [{ type: i0.Input, args: [{ isSignal: true, alias: "nodes", required: false }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }], scrollable: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollable", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }] } });

class SkLoginFormComponent {
    // ── Texts ────────────────────────────────────────────────────────────────
    title = input('Inicia sesión', ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    subtitle = input('', ...(ngDevMode ? [{ debugName: "subtitle" }] : /* istanbul ignore next */ []));
    logoUrl = input('', ...(ngDevMode ? [{ debugName: "logoUrl" }] : /* istanbul ignore next */ []));
    logoAlt = input('Skandia', ...(ngDevMode ? [{ debugName: "logoAlt" }] : /* istanbul ignore next */ []));
    emailLabel = input('Correo electrónico', ...(ngDevMode ? [{ debugName: "emailLabel" }] : /* istanbul ignore next */ []));
    emailPlaceholder = input('correo@ejemplo.com', ...(ngDevMode ? [{ debugName: "emailPlaceholder" }] : /* istanbul ignore next */ []));
    emailRequired = input(true, { ...(ngDevMode ? { debugName: "emailRequired" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    passwordLabel = input('Contraseña', ...(ngDevMode ? [{ debugName: "passwordLabel" }] : /* istanbul ignore next */ []));
    passwordPlaceholder = input('••••••••', ...(ngDevMode ? [{ debugName: "passwordPlaceholder" }] : /* istanbul ignore next */ []));
    passwordRequired = input(true, { ...(ngDevMode ? { debugName: "passwordRequired" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    rememberLabel = input('Recordarme', ...(ngDevMode ? [{ debugName: "rememberLabel" }] : /* istanbul ignore next */ []));
    forgotLabel = input('¿Olvidaste tu contraseña?', ...(ngDevMode ? [{ debugName: "forgotLabel" }] : /* istanbul ignore next */ []));
    submitLabel = input('Ingresar', ...(ngDevMode ? [{ debugName: "submitLabel" }] : /* istanbul ignore next */ []));
    registerLabel = input('Regístrate', ...(ngDevMode ? [{ debugName: "registerLabel" }] : /* istanbul ignore next */ []));
    // ── State ────────────────────────────────────────────────────────────────
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    errorMessage = input('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    // ── Outputs ──────────────────────────────────────────────────────────────
    loginSubmit = output();
    forgotPasswordClick = output();
    registerClick = output();
    // ── Internal state ───────────────────────────────────────────────────────
    email = signal('', ...(ngDevMode ? [{ debugName: "email" }] : /* istanbul ignore next */ []));
    password = signal('', ...(ngDevMode ? [{ debugName: "password" }] : /* istanbul ignore next */ []));
    rememberMe = signal(false, ...(ngDevMode ? [{ debugName: "rememberMe" }] : /* istanbul ignore next */ []));
    isValid = computed(() => this.email().trim().length > 0 && this.password().length > 0, ...(ngDevMode ? [{ debugName: "isValid" }] : /* istanbul ignore next */ []));
    handleSubmit() {
        if (!this.isValid() || this.loading())
            return;
        this.loginSubmit.emit({
            email: this.email().trim(),
            password: this.password(),
            rememberMe: this.rememberMe(),
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkLoginFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.9", type: SkLoginFormComponent, isStandalone: true, selector: "sk-login-form", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null }, logoUrl: { classPropertyName: "logoUrl", publicName: "logoUrl", isSignal: true, isRequired: false, transformFunction: null }, logoAlt: { classPropertyName: "logoAlt", publicName: "logoAlt", isSignal: true, isRequired: false, transformFunction: null }, emailLabel: { classPropertyName: "emailLabel", publicName: "emailLabel", isSignal: true, isRequired: false, transformFunction: null }, emailPlaceholder: { classPropertyName: "emailPlaceholder", publicName: "emailPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, emailRequired: { classPropertyName: "emailRequired", publicName: "emailRequired", isSignal: true, isRequired: false, transformFunction: null }, passwordLabel: { classPropertyName: "passwordLabel", publicName: "passwordLabel", isSignal: true, isRequired: false, transformFunction: null }, passwordPlaceholder: { classPropertyName: "passwordPlaceholder", publicName: "passwordPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, passwordRequired: { classPropertyName: "passwordRequired", publicName: "passwordRequired", isSignal: true, isRequired: false, transformFunction: null }, rememberLabel: { classPropertyName: "rememberLabel", publicName: "rememberLabel", isSignal: true, isRequired: false, transformFunction: null }, forgotLabel: { classPropertyName: "forgotLabel", publicName: "forgotLabel", isSignal: true, isRequired: false, transformFunction: null }, submitLabel: { classPropertyName: "submitLabel", publicName: "submitLabel", isSignal: true, isRequired: false, transformFunction: null }, registerLabel: { classPropertyName: "registerLabel", publicName: "registerLabel", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { loginSubmit: "loginSubmit", forgotPasswordClick: "forgotPasswordClick", registerClick: "registerClick" }, ngImport: i0, template: `
    <div class="sk-login">

      <!-- Header -->
      <div class="sk-login__header">
        @if (logoUrl()) {
          <img class="sk-login__logo" [src]="logoUrl()" [alt]="logoAlt()" />
        }
        <h2 class="sk-login__title">{{ title() }}</h2>
        @if (subtitle()) {
          <p class="sk-login__subtitle">{{ subtitle() }}</p>
        }
      </div>

      <!-- Error global -->
      @if (errorMessage()) {
        <div class="sk-login__error" role="alert">
          <span class="sk-login__error-icon pi pi-exclamation-circle"></span>
          {{ errorMessage() }}
        </div>
      }

      <!-- Campos -->
      <div class="sk-login__fields">
        <sk-input
          [label]="emailLabel()"
          [placeholder]="emailPlaceholder()"
          iconLeft="envelope"
          [disabled]="loading()"
          [fluid]="true"
          (valueChange)="email.set($event)"
        />
        <sk-password
          [label]="passwordLabel()"
          [placeholder]="passwordPlaceholder()"
          [feedback]="false"
          [toggleMask]="true"
          [disabled]="loading()"
          [fluid]="true"
          (valueChange)="password.set($event)"
        />
      </div>

      <!-- Recordarme + ¿Olvidaste tu contraseña? -->
      <div class="sk-login__meta">
        <sk-checkbox
          [label]="rememberLabel()"
          [checked]="rememberMe()"
          (checkedChange)="rememberMe.set($event)"
        />
        <sk-text-link
          [label]="forgotLabel()"
          size="small"
          (clicked)="forgotPasswordClick.emit($event)"
        />
      </div>

      <!-- Botón principal: Ingresar -->
      <sk-button
        class="sk-login__cta"
        [label]="submitLabel()"
        variant="primary"
        [loading]="loading()"
        [disabled]="!isValid() || loading()"
        (clicked)="handleSubmit()"
      />

      <!-- Botón secundario: Registrarse -->
      @if (registerLabel()) {
        <sk-button
          class="sk-login__cta"
          [label]="registerLabel()"
          variant="secondary"
          [disabled]="loading()"
          (clicked)="registerClick.emit($event)"
        />
      }

    </div>
  `, isInline: true, styles: [":host{display:block}.sk-login{display:flex;flex-direction:column;gap:20px;width:100%;max-width:400px}.sk-login__header{display:flex;flex-direction:column;align-items:flex-start;gap:6px}.sk-login__logo{height:32px;width:auto;margin-bottom:8px}.sk-login__title{margin:0;font-family:Open Sans,sans-serif;font-size:24px;font-weight:700;line-height:1.2;color:var(--texts-dark, #232323)}.sk-login__subtitle{margin:0;font-family:Open Sans,sans-serif;font-size:14px;font-weight:400;line-height:1.5;color:var(--texts-medium, #666666)}.sk-login__error{display:flex;align-items:center;gap:8px;padding:12px 14px;border-radius:8px;background:var(--background-error-light, #fff5f4);border:1px solid var(--stroke-error-dark, #e03430);font-family:Open Sans,sans-serif;font-size:14px;color:var(--texts-error, #e03430)}.sk-login__error-icon{font-size:16px;flex-shrink:0}.sk-login__fields{display:flex;flex-direction:column;gap:16px}.sk-login__meta{display:flex;align-items:center;justify-content:space-between}.sk-login__cta{display:flex;width:100%}.sk-login__cta ::ng-deep p-button{display:flex;width:100%}.sk-login__cta ::ng-deep button.p-button{width:100%;justify-content:center}\n"], dependencies: [{ kind: "component", type: SkInputComponent, selector: "sk-input", inputs: ["label", "type", "placeholder", "helpText", "errorMessage", "iconLeft", "iconRight", "disabled", "invalid", "fluid"], outputs: ["valueChange"] }, { kind: "component", type: SkPasswordComponent, selector: "sk-password", inputs: ["label", "value", "placeholder", "helpText", "errorMessage", "feedback", "toggleMask", "disabled", "invalid", "fluid"], outputs: ["valueChange"] }, { kind: "component", type: SkButtonComponent, selector: "sk-button", inputs: ["variant", "product", "size", "label", "icon", "iconLeft", "iconRight", "type", "iconOnly", "disabled", "loading", "ariaLabel", "raised", "rounded", "text", "plain", "outlined", "link", "severity", "loadingIcon", "badge", "badgeClass", "styleClass"], outputs: ["clicked", "focused", "blurred"] }, { kind: "component", type: SkCheckboxComponent, selector: "sk-checkbox", inputs: ["label", "showLabel", "error", "checked", "disabled", "indeterminate", "inputId", "ariaLabel", "styleClass"], outputs: ["checkedChange", "focused", "blurred"] }, { kind: "component", type: SkTextLinkComponent, selector: "sk-text-link", inputs: ["size", "href", "label", "iconLeft", "iconRight", "external"], outputs: ["clicked"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.9", ngImport: i0, type: SkLoginFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sk-login-form', standalone: true, imports: [
                        SkInputComponent,
                        SkPasswordComponent,
                        SkButtonComponent,
                        SkCheckboxComponent,
                        SkTextLinkComponent,
                    ], template: `
    <div class="sk-login">

      <!-- Header -->
      <div class="sk-login__header">
        @if (logoUrl()) {
          <img class="sk-login__logo" [src]="logoUrl()" [alt]="logoAlt()" />
        }
        <h2 class="sk-login__title">{{ title() }}</h2>
        @if (subtitle()) {
          <p class="sk-login__subtitle">{{ subtitle() }}</p>
        }
      </div>

      <!-- Error global -->
      @if (errorMessage()) {
        <div class="sk-login__error" role="alert">
          <span class="sk-login__error-icon pi pi-exclamation-circle"></span>
          {{ errorMessage() }}
        </div>
      }

      <!-- Campos -->
      <div class="sk-login__fields">
        <sk-input
          [label]="emailLabel()"
          [placeholder]="emailPlaceholder()"
          iconLeft="envelope"
          [disabled]="loading()"
          [fluid]="true"
          (valueChange)="email.set($event)"
        />
        <sk-password
          [label]="passwordLabel()"
          [placeholder]="passwordPlaceholder()"
          [feedback]="false"
          [toggleMask]="true"
          [disabled]="loading()"
          [fluid]="true"
          (valueChange)="password.set($event)"
        />
      </div>

      <!-- Recordarme + ¿Olvidaste tu contraseña? -->
      <div class="sk-login__meta">
        <sk-checkbox
          [label]="rememberLabel()"
          [checked]="rememberMe()"
          (checkedChange)="rememberMe.set($event)"
        />
        <sk-text-link
          [label]="forgotLabel()"
          size="small"
          (clicked)="forgotPasswordClick.emit($event)"
        />
      </div>

      <!-- Botón principal: Ingresar -->
      <sk-button
        class="sk-login__cta"
        [label]="submitLabel()"
        variant="primary"
        [loading]="loading()"
        [disabled]="!isValid() || loading()"
        (clicked)="handleSubmit()"
      />

      <!-- Botón secundario: Registrarse -->
      @if (registerLabel()) {
        <sk-button
          class="sk-login__cta"
          [label]="registerLabel()"
          variant="secondary"
          [disabled]="loading()"
          (clicked)="registerClick.emit($event)"
        />
      }

    </div>
  `, styles: [":host{display:block}.sk-login{display:flex;flex-direction:column;gap:20px;width:100%;max-width:400px}.sk-login__header{display:flex;flex-direction:column;align-items:flex-start;gap:6px}.sk-login__logo{height:32px;width:auto;margin-bottom:8px}.sk-login__title{margin:0;font-family:Open Sans,sans-serif;font-size:24px;font-weight:700;line-height:1.2;color:var(--texts-dark, #232323)}.sk-login__subtitle{margin:0;font-family:Open Sans,sans-serif;font-size:14px;font-weight:400;line-height:1.5;color:var(--texts-medium, #666666)}.sk-login__error{display:flex;align-items:center;gap:8px;padding:12px 14px;border-radius:8px;background:var(--background-error-light, #fff5f4);border:1px solid var(--stroke-error-dark, #e03430);font-family:Open Sans,sans-serif;font-size:14px;color:var(--texts-error, #e03430)}.sk-login__error-icon{font-size:16px;flex-shrink:0}.sk-login__fields{display:flex;flex-direction:column;gap:16px}.sk-login__meta{display:flex;align-items:center;justify-content:space-between}.sk-login__cta{display:flex;width:100%}.sk-login__cta ::ng-deep p-button{display:flex;width:100%}.sk-login__cta ::ng-deep button.p-button{width:100%;justify-content:center}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], subtitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "subtitle", required: false }] }], logoUrl: [{ type: i0.Input, args: [{ isSignal: true, alias: "logoUrl", required: false }] }], logoAlt: [{ type: i0.Input, args: [{ isSignal: true, alias: "logoAlt", required: false }] }], emailLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "emailLabel", required: false }] }], emailPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "emailPlaceholder", required: false }] }], emailRequired: [{ type: i0.Input, args: [{ isSignal: true, alias: "emailRequired", required: false }] }], passwordLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "passwordLabel", required: false }] }], passwordPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "passwordPlaceholder", required: false }] }], passwordRequired: [{ type: i0.Input, args: [{ isSignal: true, alias: "passwordRequired", required: false }] }], rememberLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "rememberLabel", required: false }] }], forgotLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "forgotLabel", required: false }] }], submitLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "submitLabel", required: false }] }], registerLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "registerLabel", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }], loginSubmit: [{ type: i0.Output, args: ["loginSubmit"] }], forgotPasswordClick: [{ type: i0.Output, args: ["forgotPasswordClick"] }], registerClick: [{ type: i0.Output, args: ["registerClick"] }] } });

const SKANDIA_THEME_TOKENS = {
    color: {
        brand: {
            50: '#f6fcf2',
            100: '#caf9cb',
            200: '#5fed73',
            300: '#47e264',
            400: '#1dd64c',
            500: '#00c73d',
            600: '#03a835',
            700: '#009a2f',
            800: '#007c26',
            900: '#006e22',
        },
        neutral: {
            0: '#ffffff',
            50: '#fafafa',
            100: '#f7f7f7',
            200: '#e9e9e9',
            300: '#dddddd',
            400: '#c5c5c5',
            500: '#b7b7b7',
            600: '#878787',
            700: '#666666',
            800: '#404040',
            900: '#232323',
            950: '#000000',
        },
        info: {
            light: '#ebf4ff',
            dark: '#0099de',
        },
        warning: {
            light: '#fff3e0',
            dark: '#ffae08',
        },
        error: {
            light: '#fff5f4',
            dark: '#e03430',
        },
        success: {
            light: '#ecfdf3',
            dark: '#87f491',
        },
    },
    radius: {
        none: '0',
        xs: '2px',
        sm: '4px',
        md: '6px',
        lg: '8px',
        xl: '12px',
        full: '9999px',
    },
    motion: {
        focusRingWidth: '2px',
        focusRingOffset: '2px',
    },
};

const { color, radius, motion } = SKANDIA_THEME_TOKENS;
/**
 * Skandia Design System Theme Preset
 * Extiende PrimeNG Aura con los tokens y CSS de Skandia.
 * La base visual sale de skandia-theme.tokens.ts y de los aliases CSS globales.
 */
const SkandiaPreset = definePreset(Aura, {
    primitive: {
        borderRadius: {
            none: radius.none,
            xs: radius.xs,
            sm: radius.sm,
            md: radius.md,
            lg: radius.lg,
            xl: radius.xl,
        },
        green: {
            50: color.brand[50],
            100: color.brand[100],
            200: color.brand[200],
            300: color.brand[300],
            400: color.brand[400],
            500: color.brand[500],
            600: color.brand[600],
            700: color.brand[700],
            800: color.brand[800],
            900: color.brand[900],
            950: color.neutral[950],
        },
    },
    semantic: {
        primary: {
            50: '{green.50}',
            100: '{green.100}',
            200: '{green.200}',
            300: '{green.300}',
            400: '{green.400}',
            500: '{green.500}',
            600: '{green.600}',
            700: '{green.700}',
            800: '{green.800}',
            900: '{green.900}',
            950: '{green.950}',
        },
        focusRing: {
            width: motion.focusRingWidth,
            style: 'solid',
            color: '{primary.color}',
            offset: motion.focusRingOffset,
            shadow: 'none',
        },
        colorScheme: {
            light: {
                primary: {
                    color: '{green.500}',
                    contrastColor: color.neutral[0],
                    hoverColor: '{green.600}',
                    activeColor: '{green.700}',
                },
                highlight: {
                    background: '{green.50}',
                    focusBackground: '{green.100}',
                    color: '{green.700}',
                    focusColor: '{green.800}',
                },
                surface: {
                    0: color.neutral[0],
                    50: color.neutral[50],
                    100: color.neutral[100],
                    200: color.neutral[200],
                    300: color.neutral[300],
                    400: color.neutral[400],
                    500: color.neutral[500],
                    600: color.neutral[600],
                    700: color.neutral[700],
                    800: color.neutral[800],
                    900: color.neutral[900],
                    950: color.neutral[950],
                },
            },
            dark: {
                primary: {
                    color: '{green.400}',
                    contrastColor: color.neutral[0],
                    hoverColor: '{green.300}',
                    activeColor: '{green.200}',
                },
                highlight: {
                    background: 'color-mix(in srgb, {green.400}, transparent 84%)',
                    focusBackground: 'color-mix(in srgb, {green.400}, transparent 76%)',
                    color: 'rgba(255,255,255,.87)',
                    focusColor: 'rgba(255,255,255,.87)',
                },
                surface: {
                    0: color.neutral[0],
                    50: color.neutral[50],
                    100: color.neutral[100],
                    200: color.neutral[200],
                    300: color.neutral[300],
                    400: color.neutral[400],
                    500: color.neutral[500],
                    600: color.neutral[600],
                    700: color.neutral[700],
                    800: color.neutral[800],
                    900: color.neutral[900],
                    950: color.neutral[950],
                },
            },
        },
    },
    components: {
        button: {
            root: {
                borderRadius: radius.full,
                label: { fontWeight: '600' },
            },
        },
        chip: {
            root: { borderRadius: radius.full },
        },
        checkbox: {
            root: { borderRadius: radius.sm },
        },
        message: {
            root: { borderRadius: radius.lg, borderWidth: '1px' },
        },
        tag: {
            root: { borderRadius: radius.sm, fontWeight: '600' },
        },
        avatar: {
            root: { borderRadius: radius.full },
        },
        breadcrumb: {
            root: { padding: '0', gap: '0.5rem' },
        },
        inputtext: {
            root: {
                filledBackground: '{form.field.background}',
                filledHoverBackground: '{form.field.background}',
                filledFocusBackground: '{form.field.background}',
            },
        },
        floatlabel: {
            root: {
                color: color.neutral[700], // texts-medium #666666 (neutro, no cambia)
                focusColor: '{primary.color}', // sigue al token dinámico de la familia activa
                activeColor: color.neutral[700], // texts-medium #666666 (neutro, no cambia)
                invalidColor: color.error.dark, // #e03430
                fontWeight: '500',
                active: {
                    fontSize: '0.688rem', // ~11px
                    fontWeight: '500',
                },
            },
            in: {
                active: { top: '0.5rem' }, // 8px — posición del label flotado
            },
        },
        // ────────────────────────────────────────────────────────────────────────
        // DataTable: alineado al sistema Skandia.
        // Paddings de celda en múltiplos de 4 (12/16). Tipografía 14px. Bordes
        // suaves con --stroke-grey-light. Hover usa --background-grey-light.
        // ────────────────────────────────────────────────────────────────────────
        datatable: {
            header: {
                background: color.neutral[100], // background-grey-light
                borderColor: color.neutral[300], // stroke-grey-light
                color: color.neutral[800], // texts-dark
                padding: '0.75rem 1rem', // 12px 16px
            },
            headerCell: {
                background: color.neutral[100],
                hoverBackground: color.neutral[200],
                borderColor: color.neutral[300],
                color: color.neutral[800],
                gap: '0.5rem',
                padding: '0.75rem 1rem',
                sm: { padding: '0.5rem 0.75rem' }, // 8px 12px
                lg: { padding: '1rem 1.25rem' },
            },
            columnTitle: {
                fontWeight: '600',
            },
            row: {
                background: color.neutral[0], // background-principal
                hoverBackground: color.neutral[50],
                color: color.neutral[800],
            },
            bodyCell: {
                borderColor: color.neutral[300],
                padding: '0.75rem 1rem',
                sm: { padding: '0.5rem 0.75rem' },
                lg: { padding: '1rem 1.25rem' },
            },
            footerCell: {
                background: color.neutral[100],
                borderColor: color.neutral[300],
                color: color.neutral[800],
                padding: '0.75rem 1rem',
            },
            footer: {
                background: color.neutral[100],
                borderColor: color.neutral[300],
                color: color.neutral[800],
                padding: '0.5rem 1rem', // un poco menos que header
            },
            sortIcon: {
                color: color.neutral[700], // texts-medium
                hoverColor: color.neutral[800],
                size: '0.875rem',
            },
            loadingIcon: { size: '2rem' },
            rowToggleButton: {
                hoverBackground: color.neutral[200],
                color: color.neutral[700],
                hoverColor: color.neutral[800],
                size: '1.5rem', // 24px, más compacto que el default 1.75rem
                borderRadius: '50%',
            },
            paginatorTop: {
                borderColor: color.neutral[300],
                borderWidth: '0 0 1px 0',
            },
            paginatorBottom: {
                borderColor: color.neutral[300],
                borderWidth: '1px 0 0 0',
            },
        },
        // ────────────────────────────────────────────────────────────────────────
        // Paginator: botones de 32px (el default de Aura es 40px y se ve enorme
        // en el footer de una tabla). Padding y gap reducidos para compactar.
        // ────────────────────────────────────────────────────────────────────────
        paginator: {
            root: {
                padding: '0.5rem 0.75rem', // 8px 12px
                gap: '0.25rem',
                background: color.neutral[0],
                color: color.neutral[800],
            },
            navButton: {
                background: 'transparent',
                hoverBackground: color.neutral[100],
                selectedBackground: '{primary.color}',
                color: color.neutral[700],
                hoverColor: color.neutral[800],
                selectedColor: color.neutral[0],
                width: '2rem', // 32px (default 2.5rem = 40px)
                height: '2rem',
                borderRadius: '50%',
            },
            currentPageReport: {
                color: color.neutral[700],
            },
            jumpToPageInput: {
                maxWidth: '2rem',
            },
        },
    },
    // CSS adicional inyectado por PrimeNG junto al theme.
    // Cubre casos que el sistema de tokens no puede manejar (gradientes, variantes custom).
    css: `
    /* ════════════════════════════════
       sk-button variants
    ════════════════════════════════ */

    .p-button.sk-btn--fill,
    .p-button.sk-btn--outline,
    .p-button.sk-btn--ghost {
      border-radius: var(--bordes-xl) !important;
      min-height: var(--size-048, 48px);
      min-width: calc(var(--size-120, 120px) + var(--size-m, 16px) + var(--size-xxs, 4px));
      padding: var(--size-xs, 8px) var(--size-m, 16px) !important;
      font-family: var(--body), var(--title), sans-serif;
      font-weight: var(--weight-bold, 700);
      line-height: var(--supporting-title-h4-bold-18px-line-height, 26px);
    }

    .p-button.p-button-sm.sk-btn--fill,
    .p-button.p-button-sm.sk-btn--outline,
    .p-button.p-button-sm.sk-btn--ghost {
      min-height: calc(var(--size-024, 24px) + var(--size-xxs, 4px) + 2px);
      min-width: var(--size-080, 80px);
      padding: var(--size-xxs, 4px) var(--size-m, 16px) !important;
      font-size: var(--auxiliary-title-h6-bold-14px-size, 14px);
      line-height: var(--auxiliary-title-h6-bold-14px-line-height, 22px);
    }

    /* fill: gradiente Skandia */
    .p-button.sk-btn--fill {
      background: var(--button-brand-default) !important;
      border-color: transparent !important;
      color: var(--color-white) !important;
    }
    .p-button.sk-btn--fill:not(:disabled):hover {
      background: var(--button-brand-hover) !important;
      border-color: transparent !important;
    }
    .p-button.sk-btn--fill:not(:disabled):active {
      background: color-mix(in srgb, var(--button-brand-hover), black 12%) !important;
    }

    /* outline: borde verde, fondo transparente */
    .p-button.sk-btn--outline {
      background: transparent !important;
      border-color: var(--button-brand-default) !important;
      color: var(--button-brand-default) !important;
    }
    .p-button.sk-btn--outline:not(:disabled):hover {
      background: var(--button-brand-secondary-hover) !important;
      border-color: var(--button-brand-default) !important;
      color: var(--button-brand-default) !important;
    }

    /* ghost: sin borde, texto verde */
    .p-button.sk-btn--ghost {
      background: transparent !important;
      border-color: transparent !important;
      color: var(--button-brand-default) !important;
    }
    .p-button.sk-btn--ghost:not(:disabled):hover {
      background: var(--button-brand-tertiary-hover) !important;
      border-color: transparent !important;
      color: var(--button-brand-default) !important;
    }

    /* ════════════════════════════════
       sk-button producto Fiduciaria
       Sobreescribe radio y colores;
       tamaños y layout los hereda del
       bloque base (.sk-btn--*)
    ════════════════════════════════ */

    .p-button.sk-btn--fiduciaria {
      border-radius: var(--bordes-s, 4px) !important;
    }

    /* fiduciaria fill */
    .p-button.sk-btn--fiduciaria.sk-btn--fill {
      background: var(--button-fiduciaria-default) !important;
      border-color: transparent !important;
    }
    .p-button.sk-btn--fiduciaria.sk-btn--fill:not(:disabled):hover {
      background: var(--button-fiduciaria-hover) !important;
    }
    .p-button.sk-btn--fiduciaria.sk-btn--fill:not(:disabled):active {
      background: color-mix(in srgb, var(--button-fiduciaria-hover), black 12%) !important;
    }

    /* fiduciaria outline */
    .p-button.sk-btn--fiduciaria.sk-btn--outline {
      border-color: var(--button-fiduciaria-default) !important;
      color: var(--button-fiduciaria-default) !important;
    }
    .p-button.sk-btn--fiduciaria.sk-btn--outline:not(:disabled):hover {
      background: var(--button-fiduciaria-secondary-hover) !important;
      border-color: var(--button-fiduciaria-default) !important;
      color: var(--button-fiduciaria-default) !important;
    }

    /* fiduciaria ghost */
    .p-button.sk-btn--fiduciaria.sk-btn--ghost {
      color: var(--button-fiduciaria-default) !important;
      border-color: transparent !important;
    }
    .p-button.sk-btn--fiduciaria.sk-btn--ghost:not(:disabled):hover {
      background: var(--button-fiduciaria-tertiary-hover) !important;
      color: var(--button-fiduciaria-default) !important;
    }

    /* ════════════════════════════════
       sk-button icon-only (circular)
       Siempre redondo, independiente
       del producto. Va después de las
       reglas fiduciaria para ganarles.
    ════════════════════════════════ */

    .p-button.sk-btn--icon-only {
      border-radius: 50% !important;
      min-width: var(--size-048, 48px) !important;
      width: var(--size-048, 48px);
      height: var(--size-048, 48px);
      padding: 0 !important;
    }

    .p-button.p-button-sm.sk-btn--icon-only {
      min-width: calc(var(--size-024, 24px) + var(--size-xxs, 4px) + 2px) !important;
      width: calc(var(--size-024, 24px) + var(--size-xxs, 4px) + 2px);
      height: calc(var(--size-024, 24px) + var(--size-xxs, 4px) + 2px);
      padding: 0 !important;
    }

    /* ════════════════════════════════
       sk-button disabled states
       Aplica a Skandia y Fiduciaria;
       la fiduciaria hereda estas reglas
       sin necesitar bloque extra.
    ════════════════════════════════ */

    /* Primary (fill) disabled: fondo gris, texto e ícono Medium */
    .p-button.sk-btn--fill:disabled,
    .p-button.sk-btn--fill.p-disabled {
      background: var(--button-disable) !important;
      border-color: transparent !important;
      color: var(--texts-medium) !important;
      opacity: 1 !important;
      cursor: not-allowed !important;
      pointer-events: none !important;
    }

    /* Secondary (outline) disabled: sin relleno, solo stroke Grey dark */
    .p-button.sk-btn--outline:disabled,
    .p-button.sk-btn--outline.p-disabled {
      background: transparent !important;
      border-color: var(--stroke-grey-dark) !important;
      color: var(--texts-medium) !important;
      opacity: 1 !important;
      cursor: not-allowed !important;
      pointer-events: none !important;
    }

    /* Tertiary (ghost) disabled: sin relleno, sin stroke */
    .p-button.sk-btn--ghost:disabled,
    .p-button.sk-btn--ghost.p-disabled {
      background: transparent !important;
      border-color: transparent !important;
      color: var(--texts-medium) !important;
      opacity: 1 !important;
      cursor: not-allowed !important;
      pointer-events: none !important;
    }

    /* ════════════════════════════════
       ds-chip variants / sizes
    ════════════════════════════════ */

    .p-chip.ds-chip--primary,
    .p-chip.sk-chip--primary {
      background: var(--color-primary-soft);
      color: var(--primary-d02);
      border: 1px solid color-mix(in srgb, var(--color-primary), white 65%);
    }
    .p-chip.ds-chip--primary:hover,
    .p-chip.sk-chip--primary:hover { background: color-mix(in srgb, var(--color-primary-soft), var(--color-primary) 18%); }
    .p-chip.ds-chip--primary .p-chip-remove-icon,
    .p-chip.sk-chip--primary .p-chip-remove-icon { color: var(--primary-d02); }

    .p-chip.ds-chip--secondary,
    .p-chip.sk-chip--secondary {
      background: var(--p-surface-100, #f3f4f6);
      color: var(--p-surface-700, #374151);
      border: 1px solid var(--p-surface-200, #e5e7eb);
    }
    .p-chip.ds-chip--secondary:hover,
    .p-chip.sk-chip--secondary:hover { background: var(--p-surface-200, #e5e7eb); }
    .p-chip.ds-chip--secondary .p-chip-remove-icon,
    .p-chip.sk-chip--secondary .p-chip-remove-icon { color: var(--p-surface-500, #6b7280); }

    .p-chip.ds-chip--small,
    .p-chip.sk-chip--small { font-size: 11px; padding: 3px 8px; }
    .p-chip.ds-chip--large,
    .p-chip.sk-chip--large { font-size: 13px; padding: 6px 12px; }

    /* ════════════════════════════════
       ds-badge (Tag) variants
    ════════════════════════════════ */

    /* Stroke: sin fondo, solo borde */
    .p-tag.ds-badge--stroke,
    .p-tag.sk-badge--stroke { background: transparent !important; border-width: 1px; border-style: solid; }
    .p-tag.ds-badge--stroke.p-tag-success,
    .p-tag.sk-badge--stroke.p-tag-success { border-color: var(--color-success); color: var(--primary-d02); }
    .p-tag.ds-badge--stroke.p-tag-warn,
    .p-tag.sk-badge--stroke.p-tag-warn { border-color: var(--color-warning); color: color-mix(in srgb, var(--color-warning), black 30%); }
    .p-tag.ds-badge--stroke.p-tag-info,
    .p-tag.sk-badge--stroke.p-tag-info { border-color: var(--color-info); color: color-mix(in srgb, var(--color-info), black 28%); }
    .p-tag.ds-badge--stroke.p-tag-danger,
    .p-tag.sk-badge--stroke.p-tag-danger { border-color: var(--color-error); color: color-mix(in srgb, var(--color-error), black 28%); }

    /* Square: cuadrado 20×20 */
    .p-tag.ds-badge--square,
    .p-tag.sk-badge--square {
      width: 20px; height: 20px; padding: 0;
      border-radius: var(--radius-sm);
      display: inline-flex; align-items: center; justify-content: center;
    }

    /* Medium / large sizes */
    .p-tag.ds-badge--medium,
    .p-tag.sk-badge--medium { padding: 2px 8px; font-size: 11px; }
    .p-tag.ds-badge--large,
    .p-tag.sk-badge--large { padding: 4px 10px; font-size: 12px; }

    /* ════════════════════════════════
       ds-alert (Message)
    ════════════════════════════════ */

    .p-message.ds-alert--success,
    .p-message.sk-alert--success { border-left: 4px solid var(--color-success); }
    .p-message.ds-alert--error,
    .p-message.sk-alert--error { border-left: 4px solid var(--color-error); }
    .p-message.ds-alert--warning,
    .p-message.sk-alert--warning { border-left: 4px solid var(--color-warning); }
    .p-message.ds-alert--info,
    .p-message.sk-alert--info { border-left: 4px solid var(--color-info); }

    /* ════════════════════════════════
       ds-avatar / sk-avatar
    ════════════════════════════════ */

    /* Anillo activo: el wrapper recibe el degradé como fondo (ver sk-avatar.component.ts).
       Aquí solo nos aseguramos de que el p-avatar interior no añada su propio borde. */
    .ds-avatar-wrap--active .p-avatar,
    .sk-avatar-wrap--active .p-avatar {
      border: none !important;
      box-shadow: none !important;
    }

    /* ════════════════════════════════
       ds-breadcrumb
    ════════════════════════════════ */

    .ds-breadcrumb .p-breadcrumb,
    .sk-breadcrumb .p-breadcrumb { background: transparent; border: none; padding: 0; }
    .ds-breadcrumb .p-breadcrumb-item-link,
    .sk-breadcrumb .p-breadcrumb-item-link {
      color: var(--p-surface-500, #6b7280);
      font-size: 14px;
      font-weight: 500;
      transition: color 0.15s;
    }
    .ds-breadcrumb .p-breadcrumb-item-link:hover,
    .sk-breadcrumb .p-breadcrumb-item-link:hover { color: var(--p-primary-600, #16a34a); }
    .ds-breadcrumb .p-breadcrumb-item.p-breadcrumb-item-active .p-breadcrumb-item-link,
    .sk-breadcrumb .p-breadcrumb-item.p-breadcrumb-item-active .p-breadcrumb-item-link {
      color: var(--p-primary-600, #16a34a);
      font-weight: 600;
      pointer-events: none;
    }

    /* ════════════════════════════════
       ds-checkbox error state
    ════════════════════════════════ */

    .ds-checkbox--error .p-checkbox-box,
    .sk-checkbox--error .p-checkbox-box {
      border-color: var(--color-error) !important;
    }
    .ds-checkbox--error .p-checkbox-box.p-checked,
    .sk-checkbox--error .p-checkbox-box.p-checked {
      background: var(--color-error) !important;
      border-color: var(--color-error) !important;
    }
  `,
});

// Auto-generado por scripts/generate-design-tokens-ts.mjs — no editar manualmente.
// Contiene los design tokens CSS de Skandia embebidos para inyección en runtime.
const SKANDIA_DESIGN_TOKENS_CSS = `:root { --primary-d04: #006e22; --primary-d03: #007c26; --primary-d02: #009a2f; --primary-d01: #03a835; --primary-00: #00c73d; --primary-l01: #1dd64c; --primary-l02: #47e264; --primary-l03: #5fed73; --primary-l04: #caf9cb; --primary-l05: #f6fcf2; --primarygrey-d05: #000000; --primarygrey-d04: #232323; --primarygrey-d03: #2c2c2c; --primarygrey-d02: #323232; --primarygrey-d01: #363636; --primarygrey-00: #404040; --primarygrey-l01: #444444; --primarygrey-l02: #565656; --primarygrey-l03: #666666; --primarygrey-l04: #878787; --primarygrey-l05: #a5a5a5; --secondarygreencomplementary-d04: #487000; --secondarygreencomplementary-d03: #629a00; --secondarygreencomplementary-d02: #6ba800; --secondarygreencomplementary-d01: #7dc400; --secondarygreencomplementary-00: #8fe000; --secondarygreencomplementary-l01: #a5e633; --secondarygreencomplementary-l02: #bbec65; --secondarygreencomplementary-l03: #d2f298; --secondarygreencomplementary-l04: #ddf6b1; --secondarygreencomplementary-l05: #f3fce3; --secondarybluecomplementary-d05: #1d594c; --secondarybluecomplementary-d04: #29806d; --secondarybluecomplementary-d03: #39b398; --secondarybluecomplementary-d02: #42ccae; --secondarybluecomplementary-d01: #4ae6c3; --secondarybluecomplementary-00: #52ffd9; --secondarybluecomplementary-l01: #76fee0; --secondarybluecomplementary-l02: #76fee0; --secondarybluecomplementary-l03: #bbfdee; --secondarybluecomplementary-l04: #ccfdf2; --secondarybluecomplementary-l05: #edfefa; --neutral-00: #ffffff; --neutral-l01: #fafafa; --neutral-l02: #f7f7f7; --neutral-l03: #e9e9e9; --neutral-l04: #dddddd; --neutral-l05: #c5c5c5; --neutral-l06: #b7b7b7; --feedback-success-light: #ecfdf3; --feedback-success-medium: #87f491; --feedback-success-dark: #16d727; --feedback-warning-light: #fff3e0; --feedback-warning-dark: #ffae08; --feedback-info-light: #ebf4ff; --feedback-info-dark: #0099de; --feedback-error-light: #fff5f4; --feedback-error-dark: #e03430; --feedback-standby-light: #f5f5f5; --feedback-standby-dark: #444444; --extras-c01: #a1dd70; --extras-c02: #a4d7e1; --extras-c03: #60a9a6; --extras-c04: #ff9460; --extras-c05: #8ba2c1; --extras-c06: #f67e7d; --extras-c07: #dddfd0; --extras-c08: #6a7491; --extras-c09: #de423e; --extras-c10: #95dbb7; --extras-c11: #ffbf9f; --extras-c12: #bc6995; --extras-c13: #d9d052; --extras-c14: #d6c09c; --extras-c15: #fecd72; --extras-c16: #cba1d2; --extras-c17: #c5d8a4; --extras-c18: #368cb5; --extras-c19: #00f59f; --extras-c20: #f50cc9; --extras-c21: #83a488; --extras-c22: #fcf9c6; --extras-c23: #b2f9fc; --extras-c24: #bf9078; --extras-c25: #9eb23b; --extras-c26: #73777b; --extras-c27: #ffe2e2; --extras-c28: #36d6e0; --extras-c29: #aba09d; --extras-c30: #b5d1ff; --extras-c31: #ecffb5; --extras-c32: #6f32c6; --extras-c33: #1f6feb; --extras-c34: #2e8b57; --extras-c35: #f4b400; --extras-c36: #ff5a5f; --extras-c37: #7b3fa1; --extras-c38: #1abc9c; --extras-c39: #f28c28; --extras-c40: #4f6d8a; --illustration-01: #00f0e0; --illustration-02: #45e39e; --illustration-03: #45ad00; --illustration-04: #ffae08; } :root { --size-000: 0px; --size-008: 8px; --size-016: 16px; --size-024: 24px; --size-032: 32px; --size-040: 40px; --size-048: 48px; --size-056: 56px; --size-064: 64px; --size-072: 72px; --size-080: 80px; --size-088: 88px; --size-096: 96px; --size-104: 104px; --size-112: 112px; --size-120: 120px; --size-128: 128px; --size-004: 4px; --size-012: 12px; } :root { --texts-white: var(--neutral-00); --texts-light: var(--primarygrey-l05); --texts-dark: var(--primarygrey-00); --texts-medium: var(--primarygrey-l03); --texts-brand: var(--primary-00); --texts-fiduciaria: var(--secondarybluecomplementary-d04); --texts-complementary: var(--secondarybluecomplementary-d01); --texts-link: var(--feedback-info-dark); --icon-disable: var(--primarygrey-l05); --icon-neutral: var(--primarygrey-00); --icon-neutral-2: var(--primarygrey-l03); --icon-link: var(--feedback-info-dark); --icon-white: var(--neutral-00); --icon-brand: var(--primary-00); --icon-fiduciaria: var(--secondarybluecomplementary-d04); --icon-success: var(--feedback-success-dark); --button-brand-default: var(--primary-00); --button-disable: var(--neutral-l03); --background-principal: var(--neutral-00); --background-grey-light: var(--neutral-l02); --background-brand-light: var(--primary-l05); --stroke-brand: var(--primary-00); --stroke-fiduciaria: var(--secondarybluecomplementary-d04); --stroke-grey-light: var(--neutral-l04); --stroke-grey-dark: var(--primarygrey-l03); --button-brand-hover: var(--primary-d01); --button-brand-secondary-hover: var(--primary-l04); --button-brand-tertiary-hover: var(--primary-l05); --button-fiduciaria-default: var(--secondarybluecomplementary-d04); --button-fiduciaria-hover: var(--secondarybluecomplementary-d05); --button-fiduciaria-secondary-hover: var(--secondarybluecomplementary-l04); --button-fiduciaria-tertiary-hover: var(--secondarybluecomplementary-l05); --stroke-grey-medium: var(--neutral-l05); --background-grey-medium: var(--neutral-l06); --background-grey-dark: var(--primarygrey-00); --stroke-success: var(--feedback-success-dark); --stroke-warning: var(--feedback-warning-dark); --stroke-info: var(--feedback-info-dark); --stroke-error-dark: var(--feedback-error-dark); --background-brand: var(--primary-00); --background-fiduciaria: var(--neutral-l02); --background-success-light: var(--feedback-success-light); --background-success-medium: var(--feedback-success-medium); --background-success-dark: var(--feedback-success-dark); --background-warning-dark: var(--feedback-warning-dark); --background-warning-light: var(--feedback-warning-light); --background-info-dark: var(--feedback-info-dark); --background-info-light: var(--feedback-info-light); --background-error-dark: var(--feedback-error-dark); --background-error-light: var(--feedback-error-light); --charts-c01: var(--extras-c01); --charts-c02: var(--extras-c02); --charts-c03: var(--extras-c03); --charts-c04: var(--extras-c04); --charts-c05: var(--extras-c05); --charts-c06: var(--extras-c06); --charts-c07: var(--extras-c07); --charts-c08: var(--extras-c08); --charts-c09: var(--extras-c09); --charts-c10: var(--extras-c10); --charts-c11: var(--extras-c11); --charts-c12: var(--extras-c12); --charts-c13: var(--extras-c13); --charts-c14: var(--extras-c14); --charts-c15: var(--extras-c15); --charts-c16: var(--extras-c16); --charts-c17: var(--extras-c17); --charts-c18: var(--extras-c18); --charts-c19: var(--extras-c19); --charts-c20: var(--extras-c20); --charts-c21: var(--extras-c21); --charts-c22: var(--extras-c22); --charts-c23: var(--extras-c23); --charts-c24: var(--extras-c24); --charts-c25: var(--extras-c25); --charts-c26: var(--extras-c26); --charts-c27: var(--extras-c27); --charts-c28: var(--extras-c28); --charts-c29: var(--extras-c29); --charts-c30: var(--extras-c30); --charts-c31: var(--extras-c31); --charts-c32: var(--extras-c32); --charts-c33: var(--extras-c33); --charts-c34: var(--extras-c34); --charts-c35: var(--extras-c35); --charts-c36: var(--extras-c36); --charts-c37: var(--extras-c37); --charts-c38: var(--extras-c38); --charts-c39: var(--extras-c39); --charts-c40: var(--extras-c40); --texts-error: var(--feedback-error-dark); --background-black: var(--primarygrey-d04); --icon-warning: var(--feedback-warning-dark); --icon-error: var(--feedback-error-dark); --estilos-degrade: linear-gradient(135deg, var(--primary-00), var(--secondarygreencomplementary-00)); } :root { --size-xxs: var(--size-004); --size-xs: var(--size-008); --size-s: var(--size-012); --size-m: var(--size-016); --size-l: var(--size-024); --size-xl: var(--size-032); --size-2xl: var(--size-040); --size-3xl: var(--size-048); --size-4xl: var(--size-056); --size-zero: var(--size-000); --bordes-m: var(--size-016); --bordes-l: var(--size-032); --bordes-xl: var(--size-104); --bordes-s: var(--size-004); --size-5xl: var(--size-064); --breakpoint-mobile: 768px; --breakpoint-tablet: 1024px; --grid-mobile-columns: 4; --grid-mobile-gutter: var(--size-m); --grid-mobile-margin: var(--size-m); --grid-tablet-columns: 8; --grid-tablet-gutter: var(--size-l); --grid-tablet-margin: var(--size-xl); --grid-desktop-columns: 12; --grid-desktop-gutter: var(--size-l); --grid-desktop-margin: 90px; } :root { --weight-regular: 400; --weight-medium: 500; --weight-bold: 700; --title: "Montserrat"; --body: "Open Sans"; } :root { --auxiliary-title-h6-medium-14px-font: var(--title); --auxiliary-title-h6-medium-14px-weight: var(--weight-medium); --auxiliary-title-h6-medium-14px-size: 0.875rem; --auxiliary-title-h6-medium-14px-line-height: 1.375rem; --auxiliary-title-h6-medium-14px-tracking: var(--size-zero); --caption-body-3-font: var(--body); --caption-body-3-weight: var(--weight-medium); --caption-body-3-size: var(--size-s); --caption-body-3-line-height: 1.25rem; --caption-body-3-tracking: var(--size-zero); --caption-body-3-bold-font: var(--body); --caption-body-3-bold-weight: var(--weight-bold); --caption-body-3-bold-size: var(--size-s); --caption-body-3-bold-line-height: 1.25rem; --caption-body-3-bold-tracking: var(--size-zero); --meta-title-h5-medium-16-px-font: var(--title); --meta-title-h5-medium-16-px-weight: var(--weight-medium); --meta-title-h5-medium-16-px-size: var(--size-m); --meta-title-h5-medium-16-px-line-height: var(--size-l); --meta-title-h5-medium-16-px-tracking: var(--size-zero); --body-medium-font: var(--body); --body-medium-weight: var(--weight-medium); --body-medium-size: var(--size-m); --body-medium-line-height: var(--size-l); --body-medium-tracking: var(--size-zero); --body-bold-font: var(--body); --body-bold-weight: var(--weight-bold); --body-bold-size: var(--size-m); --body-bold-line-height: var(--size-l); --body-bold-tracking: var(--size-zero); --label-medium-font: var(--body); --label-medium-weight: var(--weight-medium); --label-medium-size: 0.875rem; --label-medium-line-height: 1.375rem; --label-medium-tracking: var(--size-zero); --label-bold-font: var(--body); --label-bold-weight: var(--weight-bold); --label-bold-size: 0.875rem; --label-bold-line-height: 1.375rem; --label-bold-tracking: var(--size-zero); --meta-title-h5-bold-16-px-font: var(--title); --meta-title-h5-bold-16-px-weight: var(--weight-bold); --meta-title-h5-bold-16-px-size: var(--size-m); --meta-title-h5-bold-16-px-line-height: var(--size-l); --meta-title-h5-bold-16-px-tracking: var(--size-zero); --auxiliary-title-h6-bold-14px-font: var(--title); --auxiliary-title-h6-bold-14px-weight: var(--weight-bold); --auxiliary-title-h6-bold-14px-size: 0.875rem; --auxiliary-title-h6-bold-14px-line-height: 1.375rem; --auxiliary-title-h6-bold-14px-tracking: var(--size-zero); --section-title-h2-medium-24px-font: var(--title); --section-title-h2-medium-24px-weight: var(--weight-medium); --section-title-h2-medium-24px-size: var(--size-l); --section-title-h2-medium-24px-line-height: var(--size-xl); --section-title-h2-medium-24px-tracking: var(--size-zero); --subsection-title-h3-medium-20px-font: var(--title); --subsection-title-h3-medium-20px-weight: var(--weight-medium); --subsection-title-h3-medium-20px-size: 1.25rem; --subsection-title-h3-medium-20px-line-height: 1.75rem; --subsection-title-h3-medium-20px-tracking: 0rem; --section-title-h2-bold-24px-font: var(--title); --section-title-h2-bold-24px-weight: var(--weight-bold); --section-title-h2-bold-24px-size: var(--size-l); --section-title-h2-bold-24px-line-height: var(--size-xl); --section-title-h2-bold-24px-tracking: var(--size-zero); --subsection-title-h3-bold-20px-font: var(--title); --subsection-title-h3-bold-20px-weight: var(--weight-bold); --subsection-title-h3-bold-20px-size: 1.25rem; --subsection-title-h3-bold-20px-line-height: 1.75rem; --subsection-title-h3-bold-20px-tracking: 0rem; --supporting-title-h4-medium-18px-font: var(--title); --supporting-title-h4-medium-18px-weight: var(--weight-medium); --supporting-title-h4-medium-18px-size: 1.125rem; --supporting-title-h4-medium-18px-line-height: 1.625rem; --supporting-title-h4-medium-18px-tracking: 0rem; --supporting-title-h4-bold-18px-font: var(--title); --supporting-title-h4-bold-18px-weight: var(--weight-bold); --supporting-title-h4-bold-18px-size: 1.125rem; --supporting-title-h4-bold-18px-line-height: 1.625rem; --supporting-title-h4-bold-18px-tracking: 0rem; --page-title-h1-medium-32px-font: var(--title); --page-title-h1-medium-32px-weight: var(--weight-medium); --page-title-h1-medium-32px-size: var(--size-xl); --page-title-h1-medium-32px-line-height: var(--size-2xl); --page-title-h1-medium-32px-tracking: var(--size-zero); --page-title-h1-bold-32px-font: var(--title); --page-title-h1-bold-32px-weight: var(--weight-bold); --page-title-h1-bold-32px-size: var(--size-xl); --page-title-h1-bold-32px-line-height: var(--size-2xl); --page-title-h1-bold-32px-tracking: var(--size-zero); } :root { --color-primary: var(--background-brand); --color-primary-hover: var(--button-brand-hover); --color-secondary: var(--background-grey-light); --color-secondary-hover: var(--neutral-l03); --color-primary-soft: var(--background-brand-light); --color-primary-strong: var(--button-brand-hover); --color-success: var(--background-success-dark); --color-warning: var(--background-warning-dark); --color-error: var(--background-error-dark); --color-info: var(--background-info-dark); --color-success-bg: var(--background-success-light); --color-warning-bg: var(--background-warning-light); --color-error-bg: var(--background-error-light); --color-info-bg: var(--background-info-light); --color-success-border: var(--stroke-success); --color-warning-border: var(--stroke-warning); --color-error-border: var(--stroke-error-dark); --color-info-border: var(--stroke-info); --color-dark: var(--texts-dark); --color-medium: var(--texts-medium); --color-muted: var(--texts-light); --color-light: var(--stroke-grey-light); --color-border-strong: var(--stroke-grey-medium); --color-surface: var(--background-grey-light); --color-surface-soft: var(--neutral-l01); --color-surface-strong: var(--background-grey-medium); --color-white: var(--background-principal); --color-inverse: var(--background-black); --gradient-degrade: var(--estilos-degrade); --gradient-panel: linear-gradient(180deg, color-mix(in srgb, var(--color-white), transparent 2%) 0%, color-mix(in srgb, var(--color-surface-soft), transparent 2%) 100%); --gradient-panel-accent: radial-gradient(circle at top left, color-mix(in srgb, var(--color-primary), transparent 92%), transparent 36%); --space-1: var(--size-xxs); --space-2: var(--size-xs); --space-3: var(--size-m); --space-4: var(--size-l); --space-5: var(--size-xl); --breakpoint-mobile: 768px; --breakpoint-tablet: 1024px; --grid-mobile-columns: 4; --grid-mobile-gutter: var(--size-m); --grid-mobile-margin: var(--size-m); --grid-tablet-columns: 8; --grid-tablet-gutter: var(--size-l); --grid-tablet-margin: var(--size-xl); --grid-desktop-columns: 12; --grid-desktop-gutter: var(--size-l); --grid-desktop-margin: 90px; --radius-sm: var(--bordes-s); --radius-md: 8px; --radius-lg: 12px; --radius-full: 9999px; --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05); --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); --shadow-focus: 0 0 0 3px color-mix(in srgb, var(--color-primary), transparent 70%); --font-family: var(--body), system-ui, -apple-system, 'Segoe UI', sans-serif; --font-family-mono: 'Courier New', 'Consolas', monospace; --text-h1-size: var(--page-title-h1-bold-32px-size); --text-h1-weight: 700; --text-h1-line-height: var(--page-title-h1-bold-32px-line-height); --text-h4-size: 1.125rem; --text-h4-weight: 700; --text-h4-line-height: 1.625rem; --text-label-bold-size: 0.875rem; --text-label-bold-weight: 700; --text-label-bold-line-height: 1.375rem; --text-label-medium-size: 0.875rem; --text-label-medium-weight: 500; --text-label-medium-line-height: 1.375rem; --text-body1-size: var(--body-medium-size); --text-body1-weight: 400; --text-body1-line-height: var(--body-medium-line-height); --text-caption-size: var(--caption-body-3-size); --text-caption-weight: 500; --text-caption-line-height: var(--caption-body-3-line-height); --sk-field-min-width: 0px; --tag-bg: var(--color-primary-soft); --tag-fg: var(--color-primary); --interactive-hover: color-mix(in srgb, var(--color-white), var(--color-primary) 4%); --interactive-active: color-mix(in srgb, var(--color-primary-soft), var(--color-white) 35%); --code-bg: #0f172a; --code-fg: #a5f3a0; --code-muted: #94a3b8; --code-border: rgba(255, 255, 255, 0.12); --danger-soft: #fef2f2; --danger-border: #fecaca; --danger-fg: #991b1b; --accent-1: var(--color-primary); --accent-2: var(--color-info); --accent-3: var(--color-success); --accent-4: var(--color-warning); --accent-5: var(--charts-c32, #6f32c6); --accent-6: var(--charts-c38, #1abc9c); --accent-7: var(--charts-c39, #f28c28); --accent-8: var(--charts-c33, #1f6feb); --avatar-badge-bg: var(--color-error); --avatar-badge-fg: var(--color-white); --avatar-badge-ring: var(--color-white); } @media (min-width: 768px) { :root { --sk-field-min-width: 280px; } } @media (min-width: 1024px) { :root { --sk-field-min-width: clamp(280px, calc((100vw - 444px) / 3 + 72px), 400px); } }`;

const SKANDIA_STYLE_URLS = [
    'https://skcoblobresources.blob.core.windows.net/styles/sk-desing-main.css',
    'https://skcoblobresources.blob.core.windows.net/styles/sk-icon-all.min.css',
];
function provideSkandiaUI() {
    return makeEnvironmentProviders([
        provideAnimationsAsync(),
        providePrimeNG({
            theme: {
                preset: SkandiaPreset,
                options: { darkModeSelector: false },
            },
            translation: {
                dayNames: ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'],
                dayNamesShort: ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'],
                dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'],
                monthNames: ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'],
                monthNamesShort: ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'],
                today: 'Hoy',
                clear: 'Limpiar',
                weekHeader: 'Sm',
                firstDayOfWeek: 1,
            },
        }),
        {
            provide: ENVIRONMENT_INITIALIZER,
            multi: true,
            useValue: () => {
                const doc = inject(DOCUMENT);
                // 1. Tokens CSS propios de Skandia (embebidos en el bundle)
                if (!doc.getElementById('skandia-design-tokens')) {
                    const style = doc.createElement('style');
                    style.id = 'skandia-design-tokens';
                    style.textContent = SKANDIA_DESIGN_TOKENS_CSS;
                    doc.head.prepend(style); // prepend: antes de cualquier otro estilo
                }
                // 2. CSS del sistema de diseño Skandia (tipografía, grid, iconos)
                SKANDIA_STYLE_URLS.forEach(href => {
                    if (!doc.querySelector(`link[href="${href}"]`)) {
                        const link = doc.createElement('link');
                        link.rel = 'stylesheet';
                        link.href = href;
                        doc.head.appendChild(link);
                    }
                });
            },
        },
    ]);
}

// Auto-generado por scripts/generate-public-api.mjs — no editar manualmente.
// Generado el 2026-08-26 con 83 átomos y 1 moléculas.
// ── Átomos ──────────────────────────────────────────────────────────────────

/**
 * Generated bundle index. Do not edit.
 */

export { SKANDIA_DESIGN_TOKENS_CSS, SKANDIA_THEME_TOKENS, SkAccordionComponent, SkAlertComponent, SkAutoCompleteComponent, SkAvatarComponent, SkAvatarGroupComponent, SkBadgeComponent, SkBlockUIComponent, SkBreadcrumbComponent, SkButtonComponent, SkButtonGroupComponent, SkCardComponent, SkCarouselComponent, SkCascadeSelectComponent, SkCheckboxComponent, SkChipComponent, SkColorPickerComponent, SkConfirmDialogComponent, SkContextMenuComponent, SkDataViewComponent, SkDatePickerComponent, SkDialogComponent, SkDividerComponent, SkDockComponent, SkDrawerComponent, SkDropdownComponent, SkFieldsetComponent, SkFileUploadComponent, SkGalleriaComponent, SkImageCompareComponent, SkImageComponent, SkInplaceComponent, SkInputComponent, SkInputMaskComponent, SkInputNumberComponent, SkInputOtpComponent, SkKnobComponent, SkListComponent, SkListboxComponent, SkLoginFormComponent, SkMegaMenuComponent, SkMenuComponent, SkMenubarComponent, SkMeterGroupComponent, SkMultiSelectComponent, SkOrderListComponent, SkOrgChartComponent, SkOverlayBadgeComponent, SkPaginatorComponent, SkPanelComponent, SkPanelMenuComponent, SkPasswordComponent, SkPickListComponent, SkPopoverComponent, SkProgressBarComponent, SkProgressSpinnerComponent, SkRadioComponent, SkRadiogroupComponent, SkRatingComponent, SkScrollPanelComponent, SkScrollTopComponent, SkSelectButtonComponent, SkSkeletonComponent, SkSliderComponent, SkSpeedDialComponent, SkSplitButtonComponent, SkStepperComponent, SkStepsComponent, SkSwitchComponent, SkTableComponent, SkTabsComponent, SkTagComponent, SkTerminalComponent, SkTextLinkComponent, SkTextareaComponent, SkTieredMenuComponent, SkTimelineComponent, SkToastComponent, SkToggleButtonComponent, SkToolbarComponent, SkTooltipComponent, SkTreeComponent, SkTreeSelectComponent, SkTreeTableComponent, SkandiaPreset, provideSkandiaUI };
//# sourceMappingURL=skandia-ui.mjs.map
