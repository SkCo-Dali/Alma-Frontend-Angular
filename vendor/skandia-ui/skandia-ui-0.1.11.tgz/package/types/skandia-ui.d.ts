import * as _angular_core from '@angular/core';
import { OnDestroy, OnChanges, SimpleChanges, OnInit, EnvironmentProviders } from '@angular/core';
import { ControlValueAccessor, FormControl } from '@angular/forms';
import { ContextMenu } from 'primeng/contextmenu';
import { MenuItem, MegaMenuItem, TreeNode } from 'primeng/api';
export { CancelEditableRow, CellEditor, ColumnFilter, ColumnFilterFormElement, ContextMenuRow, EditableColumn, EditableRow, FrozenColumn, InitEditableRow, ReorderableColumn, ReorderableRow, ReorderableRowHandle, ResizableColumn, RowGroupHeader, RowToggler, SaveEditableRow, SelectableRow, SelectableRowDblClick, Table as SkDataTable, TableColResizeEvent as SkDataTableColResizeEvent, TableColumnReorderEvent as SkDataTableColumnReorderEvent, TableContextMenuSelectEvent as SkDataTableContextMenuSelectEvent, TableEditCancelEvent as SkDataTableEditCancelEvent, TableEditCompleteEvent as SkDataTableEditCompleteEvent, TableEditInitEvent as SkDataTableEditInitEvent, ExportCSVOptions as SkDataTableExportCSVOptions, TableFilterEvent as SkDataTableFilterEvent, TableHeaderCheckboxToggleEvent as SkDataTableHeaderCheckboxToggleEvent, TableLazyLoadEvent as SkDataTableLazyLoadEvent, TableModule as SkDataTableModule, TablePageEvent as SkDataTablePageEvent, TableRowCollapseEvent as SkDataTableRowCollapseEvent, TableRowExpandEvent as SkDataTableRowExpandEvent, TableRowReorderEvent as SkDataTableRowReorderEvent, TableRowSelectEvent as SkDataTableRowSelectEvent, TableRowUnSelectEvent as SkDataTableRowUnSelectEvent, TableSelectAllChangeEvent as SkDataTableSelectAllChangeEvent, SortIcon, SortableColumn, TableBody, TableCheckbox, TableClasses, TableHeaderCheckbox, TableRadioButton, TableService, TableStyle } from 'primeng/table';
import { Popover } from 'primeng/popover';
import { TerminalService } from 'primeng/terminal';
import { ToastPositionType } from 'primeng/toast';
import * as _primeuix_themes_types from '@primeuix/themes/types';

interface SkAccordionPanel {
    header: string;
    content: string;
    icon?: string;
    disabled?: boolean;
}
declare class SkAccordionComponent {
    readonly panels: _angular_core.InputSignal<SkAccordionPanel[]>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkAccordionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkAccordionComponent, "sk-accordion", never, { "panels": { "alias": "panels"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type SkAlertVariant = 'success' | 'error' | 'warning' | 'info';
type PrimeSeverity = 'success' | 'info' | 'warn' | 'error';
declare class SkAlertComponent {
    readonly variant: _angular_core.InputSignal<SkAlertVariant>;
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly _severity: _angular_core.Signal<PrimeSeverity>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkAlertComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkAlertComponent, "sk-alert", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, never, true, never>;
}

declare class SkAutoCompleteComponent implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    readonly items: _angular_core.InputSignal<string[]>;
    readonly helpText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly dropdown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    readonly selected: _angular_core.OutputEmitterRef<unknown>;
    readonly inputId: string;
    readonly _value: _angular_core.WritableSignal<unknown>;
    filteredItems: string[];
    private readonly _cvaDisabled;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    private _onChange;
    private _onTouched;
    handleInput(val: unknown): void;
    handleBlur(): void;
    filterItems(event: {
        query: string;
    }): void;
    writeValue(val: unknown): void;
    registerOnChange(fn: (v: unknown) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkAutoCompleteComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkAutoCompleteComponent, "sk-autocomplete", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "dropdown": { "alias": "dropdown"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; "selected": "selected"; }, never, never, true, never>;
}

type SkAvatarType = 'img' | 'text' | 'icon';
type SkAvatarSize = 'large' | 'small';
declare class SkAvatarComponent {
    readonly type: _angular_core.InputSignal<SkAvatarType>;
    readonly size: _angular_core.InputSignal<SkAvatarSize>;
    readonly src: _angular_core.InputSignal<string>;
    readonly initials: _angular_core.InputSignal<string>;
    readonly badge: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly badgeCount: _angular_core.InputSignal<string | number>;
    readonly active: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly image: _angular_core.InputSignal<string | undefined>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    readonly imageError: _angular_core.OutputEmitterRef<Event>;
    readonly isActive: _angular_core.Signal<boolean>;
    readonly hasBadge: _angular_core.Signal<boolean>;
    readonly numBadgeCount: _angular_core.Signal<number>;
    readonly displayInitials: _angular_core.Signal<string>;
    readonly badgeLabel: _angular_core.Signal<string>;
    /** Dimensión interior: total (40/32px) menos 2px de padding por cada lado */
    readonly avatarDim: _angular_core.Signal<"36px" | "28px">;
    readonly avatarStyleClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkAvatarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkAvatarComponent, "sk-avatar", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "src": { "alias": "src"; "required": false; "isSignal": true; }; "initials": { "alias": "initials"; "required": false; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; "badgeCount": { "alias": "badgeCount"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "image": { "alias": "image"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, { "imageError": "imageError"; }, never, never, true, never>;
}

declare class SkAvatarGroupComponent {
    readonly surplus: _angular_core.InputSignal<number>;
    readonly avatars: _angular_core.InputSignal<{
        label: string;
        image: string;
        bg: string;
    }[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkAvatarGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkAvatarGroupComponent, "sk-avatargroup", never, { "surplus": { "alias": "surplus"; "required": false; "isSignal": true; }; "avatars": { "alias": "avatars"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type SkBadgeVariant = 'success' | 'warning' | 'info' | 'error';
type SkBadgeType = 'stroke' | 'fill';
type SkBadgeSize = 'square' | 'mini' | 'medium' | 'large';
declare class SkBadgeComponent {
    readonly variant: _angular_core.InputSignal<SkBadgeVariant>;
    readonly type: _angular_core.InputSignal<SkBadgeType>;
    readonly size: _angular_core.InputSignal<SkBadgeSize>;
    readonly label: _angular_core.InputSignal<string>;
    readonly count: _angular_core.InputSignal<number | null>;
    readonly showIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly value: _angular_core.InputSignal<string | undefined>;
    readonly severity: _angular_core.InputSignal<string | undefined>;
    readonly rounded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    readonly resolvedShowIcon: _angular_core.Signal<boolean>;
    readonly resolvedCount: _angular_core.Signal<string>;
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkBadgeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkBadgeComponent, "sk-badge", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "count": { "alias": "count"; "required": false; "isSignal": true; }; "showIcon": { "alias": "showIcon"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkBlockUIComponent {
    readonly blocked: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly message: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkBlockUIComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkBlockUIComponent, "sk-blockui", never, { "blocked": { "alias": "blocked"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface SkBreadcrumbItem {
    label: string;
    href?: string;
    icon?: string;
}
declare class SkBreadcrumbComponent {
    readonly items: _angular_core.InputSignal<string | SkBreadcrumbItem[]>;
    readonly separator: _angular_core.InputSignal<string>;
    /** Muestra el ícono de casa en el primer ítem si no tiene icon propio */
    readonly showHomeIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly model: _angular_core.InputSignal<unknown[]>;
    readonly home: _angular_core.InputSignal<unknown>;
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    readonly resolvedItems: _angular_core.Signal<{
        icon: string | undefined;
        label: string;
        href?: string;
    }[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkBreadcrumbComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkBreadcrumbComponent, "sk-breadcrumb", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "separator": { "alias": "separator"; "required": false; "isSignal": true; }; "showHomeIcon": { "alias": "showHomeIcon"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "home": { "alias": "home"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type SkButtonVariant = 'primary' | 'secondary' | 'tertiary' | 'fill' | 'outline' | 'ghost';
type SkButtonSize = 'small' | 'large';
type SkButtonProduct = 'skandia' | 'fiduciaria';
declare class SkButtonComponent {
    readonly variant: _angular_core.InputSignal<SkButtonVariant>;
    readonly product: _angular_core.InputSignal<SkButtonProduct>;
    readonly size: _angular_core.InputSignal<SkButtonSize | undefined>;
    readonly label: _angular_core.InputSignal<string>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly iconLeft: _angular_core.InputSignal<string>;
    readonly iconRight: _angular_core.InputSignal<string>;
    readonly type: _angular_core.InputSignal<string>;
    readonly iconOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly raised: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rounded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly text: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly plain: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly outlined: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly link: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly severity: _angular_core.InputSignal<"success" | "info" | "warn" | "secondary" | "contrast" | "danger" | undefined>;
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    readonly badge: _angular_core.InputSignal<string | undefined>;
    readonly badgeClass: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    readonly clicked: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly focused: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly blurred: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly resolvedVariant: _angular_core.Signal<"fill" | "outline" | "ghost">;
    readonly resolvedLabel: _angular_core.Signal<string>;
    readonly resolvedIcon: _angular_core.Signal<string>;
    readonly resolvedIconPos: _angular_core.Signal<"left" | "right">;
    readonly resolvedSeverity: _angular_core.Signal<"success" | "info" | "warn" | "secondary" | "contrast" | "danger" | undefined>;
    readonly resolvedLoadingIcon: _angular_core.Signal<string | undefined>;
    readonly resolvedOutlined: _angular_core.Signal<boolean>;
    readonly resolvedText: _angular_core.Signal<boolean>;
    readonly resolvedLink: _angular_core.Signal<boolean>;
    readonly resolvedStyleClass: _angular_core.Signal<string>;
    handleClick(event: MouseEvent): void;
    private normalizeIconName;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkButtonComponent, "sk-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "product": { "alias": "product"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconLeft": { "alias": "iconLeft"; "required": false; "isSignal": true; }; "iconRight": { "alias": "iconRight"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "iconOnly": { "alias": "iconOnly"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "raised": { "alias": "raised"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "plain": { "alias": "plain"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "link": { "alias": "link"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; "badgeClass": { "alias": "badgeClass"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, { "clicked": "clicked"; "focused": "focused"; "blurred": "blurred"; }, never, never, true, never>;
}

declare class SkButtonGroupComponent {
    readonly buttons: _angular_core.InputSignal<{
        label: string;
        icon?: string;
    }[]>;
    readonly outlined: _angular_core.InputSignal<boolean>;
    readonly severity: _angular_core.InputSignal<"success" | "info" | "warn" | "secondary" | "contrast" | "danger" | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkButtonGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkButtonGroupComponent, "sk-buttongroup", never, { "buttons": { "alias": "buttons"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkCardComponent {
    readonly header: _angular_core.InputSignal<string>;
    readonly subheader: _angular_core.InputSignal<string>;
    readonly content: _angular_core.InputSignal<string>;
    readonly footer: _angular_core.InputSignal<string>;
    readonly elevated: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkCardComponent, "sk-card", never, { "header": { "alias": "header"; "required": false; "isSignal": true; }; "subheader": { "alias": "subheader"; "required": false; "isSignal": true; }; "content": { "alias": "content"; "required": false; "isSignal": true; }; "footer": { "alias": "footer"; "required": false; "isSignal": true; }; "elevated": { "alias": "elevated"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface SkCarouselItem {
    title: string;
    subtitle?: string;
    icon?: string;
    image?: string;
    color?: string;
}
declare class SkCarouselComponent {
    readonly value: _angular_core.InputSignal<SkCarouselItem[]>;
    readonly numVisible: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly numScroll: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly circular: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoplayInterval: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly showIndicators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showNavigators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkCarouselComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkCarouselComponent, "sk-carousel", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "numVisible": { "alias": "numVisible"; "required": false; "isSignal": true; }; "numScroll": { "alias": "numScroll"; "required": false; "isSignal": true; }; "circular": { "alias": "circular"; "required": false; "isSignal": true; }; "autoplayInterval": { "alias": "autoplayInterval"; "required": false; "isSignal": true; }; "showIndicators": { "alias": "showIndicators"; "required": false; "isSignal": true; }; "showNavigators": { "alias": "showNavigators"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkCascadeSelectComponent implements ControlValueAccessor, OnDestroy {
    readonly label: _angular_core.InputSignal<string>;
    readonly options: _angular_core.InputSignal<any[]>;
    readonly optionLabel: _angular_core.InputSignal<string>;
    readonly optionGroupLabel: _angular_core.InputSignal<string>;
    readonly optionGroupChildren: _angular_core.InputSignal<string[]>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    readonly inputId: string;
    readonly innerControl: FormControl<unknown>;
    private readonly _cvaDisabled;
    private readonly _isOpen;
    private readonly _value;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    readonly _isFloatActive: _angular_core.Signal<boolean>;
    private _onChange;
    onTouched: () => void;
    private readonly sub;
    constructor();
    onPanelShow(): void;
    onPanelHide(): void;
    writeValue(val: unknown): void;
    registerOnChange(fn: (v: unknown) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkCascadeSelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkCascadeSelectComponent, "sk-cascadeselect", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkCheckboxComponent implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    readonly showLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly error: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly checked: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly checkedChange: _angular_core.OutputEmitterRef<boolean>;
    readonly focused: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly blurred: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly indeterminate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    readonly uid: string;
    isChecked: boolean;
    private cvaChange;
    private cvaTouched;
    readonly isShowLabel: _angular_core.Signal<boolean>;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly isIndeterminate: _angular_core.Signal<boolean>;
    readonly hostClasses: _angular_core.Signal<string>;
    readonly pCheckboxClass: _angular_core.Signal<string>;
    constructor();
    handleChange(event: {
        checked?: boolean;
    }): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(_isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkCheckboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkCheckboxComponent, "sk-checkbox", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "showLabel": { "alias": "showLabel"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, { "checkedChange": "checkedChange"; "focused": "focused"; "blurred": "blurred"; }, never, never, true, never>;
}

type SkChipVariant = 'primary' | 'secondary';
type SkChipSize = 'large' | 'small';
declare class SkChipComponent {
    readonly variant: _angular_core.InputSignal<SkChipVariant>;
    readonly size: _angular_core.InputSignal<SkChipSize>;
    readonly showIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showDelete: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly icon: _angular_core.InputSignal<string | undefined>;
    readonly image: _angular_core.InputSignal<string | undefined>;
    readonly alt: _angular_core.InputSignal<string | undefined>;
    readonly removable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    readonly removed: _angular_core.OutputEmitterRef<string>;
    readonly imageError: _angular_core.OutputEmitterRef<Event>;
    visible: boolean;
    constructor();
    handleRemove(_event: Event): void;
    readonly isRemovable: _angular_core.Signal<boolean>;
    /** Normalises icon name: accepts 'user', 'pi pi-user', or undefined. */
    readonly resolvedLeftIcon: _angular_core.Signal<string>;
    readonly chipStyleClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkChipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkChipComponent, "sk-chip", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "showIcon": { "alias": "showIcon"; "required": false; "isSignal": true; }; "showDelete": { "alias": "showDelete"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "image": { "alias": "image"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, { "removed": "removed"; "imageError": "imageError"; }, never, never, true, never>;
}

declare class SkColorPickerComponent {
    readonly inline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly format: _angular_core.InputSignal<"hex" | "rgb" | "hsb">;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    value: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkColorPickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkColorPickerComponent, "sk-colorpicker", never, { "inline": { "alias": "inline"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "format": { "alias": "format"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkConfirmDialogComponent {
    readonly message: _angular_core.InputSignal<string>;
    readonly header: _angular_core.InputSignal<string>;
    readonly acceptLabel: _angular_core.InputSignal<string>;
    readonly rejectLabel: _angular_core.InputSignal<string>;
    readonly triggerLabel: _angular_core.InputSignal<string>;
    readonly showTrigger: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly accepted: _angular_core.OutputEmitterRef<void>;
    readonly rejected: _angular_core.OutputEmitterRef<void>;
    readonly visible: _angular_core.WritableSignal<boolean>;
    get dialogTitle(): string;
    open(): void;
    showConfirm(): void;
    onAccept(): void;
    onReject(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkConfirmDialogComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkConfirmDialogComponent, "sk-confirmdialog", never, { "message": { "alias": "message"; "required": false; "isSignal": true; }; "header": { "alias": "header"; "required": false; "isSignal": true; }; "acceptLabel": { "alias": "acceptLabel"; "required": false; "isSignal": true; }; "rejectLabel": { "alias": "rejectLabel"; "required": false; "isSignal": true; }; "triggerLabel": { "alias": "triggerLabel"; "required": false; "isSignal": true; }; "showTrigger": { "alias": "showTrigger"; "required": false; "isSignal": true; }; }, { "accepted": "accepted"; "rejected": "rejected"; }, never, never, true, never>;
}

declare class SkContextMenuComponent {
    cm: ContextMenu;
    readonly model: _angular_core.InputSignal<MenuItem[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkContextMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkContextMenuComponent, "sk-contextmenu", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkDataViewComponent {
    readonly items: _angular_core.InputSignal<{
        name: string;
        category: string;
        status: string;
    }[]>;
    readonly layout: _angular_core.InputSignal<"list" | "grid">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkDataViewComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkDataViewComponent, "sk-dataview", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkDatePickerComponent implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    readonly helpText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly showIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dateFormat: _angular_core.InputSignal<string>;
    readonly showTime: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showButtonBar: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selected: _angular_core.OutputEmitterRef<Date>;
    readonly inputId: string;
    readonly _value: _angular_core.WritableSignal<Date | null>;
    private readonly _cvaDisabled;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    private _onChange;
    private _onTouched;
    handleInput(val: Date | null): void;
    handleBlur(): void;
    writeValue(val: Date | null): void;
    registerOnChange(fn: (v: Date | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkDatePickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkDatePickerComponent, "sk-datepicker", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "showIcon": { "alias": "showIcon"; "required": false; "isSignal": true; }; "dateFormat": { "alias": "dateFormat"; "required": false; "isSignal": true; }; "showTime": { "alias": "showTime"; "required": false; "isSignal": true; }; "showButtonBar": { "alias": "showButtonBar"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "inline": { "alias": "inline"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "selected": "selected"; }, never, never, true, never>;
}

declare class SkDialogComponent {
    readonly header: _angular_core.InputSignal<string>;
    readonly content: _angular_core.InputSignal<string>;
    readonly contentHtml: _angular_core.InputSignal<string>;
    readonly triggerLabel: _angular_core.InputSignal<string>;
    readonly showTrigger: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly modal: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly buttons: _angular_core.InputSignal<{
        confirm: string;
        cancel: string;
    }>;
    readonly confirm: _angular_core.OutputEmitterRef<void>;
    readonly cancel: _angular_core.OutputEmitterRef<void>;
    readonly show: _angular_core.OutputEmitterRef<void>;
    readonly hide: _angular_core.OutputEmitterRef<void>;
    visible: boolean;
    onConfirm(): void;
    onCancel(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkDialogComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkDialogComponent, "sk-dialog", never, { "header": { "alias": "header"; "required": false; "isSignal": true; }; "content": { "alias": "content"; "required": false; "isSignal": true; }; "contentHtml": { "alias": "contentHtml"; "required": false; "isSignal": true; }; "triggerLabel": { "alias": "triggerLabel"; "required": false; "isSignal": true; }; "showTrigger": { "alias": "showTrigger"; "required": false; "isSignal": true; }; "modal": { "alias": "modal"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; "buttons": { "alias": "buttons"; "required": false; "isSignal": true; }; }, { "confirm": "confirm"; "cancel": "cancel"; "show": "show"; "hide": "hide"; }, never, never, true, never>;
}

declare class SkDividerComponent {
    readonly layout: _angular_core.InputSignal<"horizontal" | "vertical">;
    readonly type: _angular_core.InputSignal<"solid" | "dashed" | "dotted">;
    readonly align: _angular_core.InputSignal<"left" | "right" | "center" | "top" | "bottom" | undefined>;
    readonly label: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkDividerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkDividerComponent, "sk-divider", never, { "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkDockComponent {
    readonly position: _angular_core.InputSignal<"left" | "right" | "top" | "bottom">;
    readonly model: _angular_core.InputSignal<MenuItem[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkDockComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkDockComponent, "sk-dock", never, { "position": { "alias": "position"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkDrawerComponent implements OnChanges {
    readonly header: _angular_core.InputSignal<string>;
    readonly content: _angular_core.InputSignal<string>;
    readonly triggerLabel: _angular_core.InputSignal<string>;
    readonly footerLabel: _angular_core.InputSignal<string>;
    readonly position: _angular_core.InputSignal<"left" | "right" | "top" | "bottom">;
    readonly modal: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly visible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly visibleChange: _angular_core.OutputEmitterRef<boolean>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly _visible: _angular_core.WritableSignal<boolean>;
    ngOnChanges(changes: SimpleChanges): void;
    open(): void;
    close(): void;
    onVisibleChange(v: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkDrawerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkDrawerComponent, "sk-drawer", never, { "header": { "alias": "header"; "required": false; "isSignal": true; }; "content": { "alias": "content"; "required": false; "isSignal": true; }; "triggerLabel": { "alias": "triggerLabel"; "required": false; "isSignal": true; }; "footerLabel": { "alias": "footerLabel"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "modal": { "alias": "modal"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; }, { "visibleChange": "visibleChange"; "closed": "closed"; }, never, ["*"], true, never>;
}

declare class SkDropdownComponent implements ControlValueAccessor, OnDestroy {
    readonly label: _angular_core.InputSignal<string>;
    readonly options: _angular_core.InputSignal<{
        label: string;
        value: string;
    }[]>;
    readonly optionLabel: _angular_core.InputSignal<string>;
    readonly optionValue: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly helpText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    readonly inputId: string;
    readonly innerControl: FormControl<unknown>;
    private readonly _cvaDisabled;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    private _onChange;
    onTouched: () => void;
    private readonly sub;
    constructor();
    writeValue(val: unknown): void;
    registerOnChange(fn: (v: unknown) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkDropdownComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkDropdownComponent, "sk-dropdown", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkFieldsetComponent {
    readonly legend: _angular_core.InputSignal<string>;
    readonly content: _angular_core.InputSignal<string>;
    readonly toggleable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly collapsed: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly beforeToggle: _angular_core.OutputEmitterRef<unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkFieldsetComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkFieldsetComponent, "sk-fieldset", never, { "legend": { "alias": "legend"; "required": false; "isSignal": true; }; "content": { "alias": "content"; "required": false; "isSignal": true; }; "toggleable": { "alias": "toggleable"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; }, { "beforeToggle": "beforeToggle"; }, never, ["*"], true, never>;
}

declare class SkFileUploadComponent {
    readonly name: _angular_core.InputSignal<string>;
    readonly url: _angular_core.InputSignal<string>;
    readonly multiple: _angular_core.InputSignal<boolean>;
    readonly accept: _angular_core.InputSignal<string>;
    readonly maxFileSize: _angular_core.InputSignal<number>;
    readonly mode: _angular_core.InputSignal<"basic" | "advanced">;
    readonly auto: _angular_core.InputSignal<boolean>;
    readonly chooseLabel: _angular_core.InputSignal<string>;
    readonly selected: _angular_core.OutputEmitterRef<unknown>;
    readonly uploaded: _angular_core.OutputEmitterRef<unknown>;
    readonly error: _angular_core.OutputEmitterRef<unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkFileUploadComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkFileUploadComponent, "sk-fileupload", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "url": { "alias": "url"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "auto": { "alias": "auto"; "required": false; "isSignal": true; }; "chooseLabel": { "alias": "chooseLabel"; "required": false; "isSignal": true; }; }, { "selected": "selected"; "uploaded": "uploaded"; "error": "error"; }, never, never, true, never>;
}

declare class SkGalleriaComponent {
    readonly images: _angular_core.InputSignal<{
        label: string;
        short: string;
        color: string;
    }[]>;
    readonly numVisible: _angular_core.InputSignal<number>;
    readonly showThumbnails: _angular_core.InputSignal<boolean>;
    readonly showIndicators: _angular_core.InputSignal<boolean>;
    readonly circular: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkGalleriaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkGalleriaComponent, "sk-galleria", never, { "images": { "alias": "images"; "required": false; "isSignal": true; }; "numVisible": { "alias": "numVisible"; "required": false; "isSignal": true; }; "showThumbnails": { "alias": "showThumbnails"; "required": false; "isSignal": true; }; "showIndicators": { "alias": "showIndicators"; "required": false; "isSignal": true; }; "circular": { "alias": "circular"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkImageComponent {
    readonly src: _angular_core.InputSignal<string>;
    readonly alt: _angular_core.InputSignal<string>;
    readonly width: _angular_core.InputSignal<string>;
    readonly preview: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkImageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkImageComponent, "sk-image", never, { "src": { "alias": "src"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "preview": { "alias": "preview"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkImageCompareComponent {
    readonly leftSrc: _angular_core.InputSignal<string>;
    readonly rightSrc: _angular_core.InputSignal<string>;
    readonly leftAlt: _angular_core.InputSignal<string>;
    readonly rightAlt: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkImageCompareComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkImageCompareComponent, "sk-imagecompare", never, { "leftSrc": { "alias": "leftSrc"; "required": false; "isSignal": true; }; "rightSrc": { "alias": "rightSrc"; "required": false; "isSignal": true; }; "leftAlt": { "alias": "leftAlt"; "required": false; "isSignal": true; }; "rightAlt": { "alias": "rightAlt"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkInplaceComponent {
    readonly display: _angular_core.InputSignal<string>;
    readonly content: _angular_core.InputSignal<string>;
    readonly closable: _angular_core.InputSignal<boolean>;
    active: boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkInplaceComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkInplaceComponent, "sk-inplace", never, { "display": { "alias": "display"; "required": false; "isSignal": true; }; "content": { "alias": "content"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkInputComponent implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    readonly type: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly helpText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly iconLeft: _angular_core.InputSignal<string>;
    readonly iconRight: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    readonly inputId: string;
    readonly _value: _angular_core.WritableSignal<string>;
    private readonly _cvaDisabled;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    readonly normalizedIconLeft: _angular_core.Signal<string>;
    readonly normalizedIconRight: _angular_core.Signal<string>;
    private _onChange;
    private _onTouched;
    handleInput(val: string): void;
    handleBlur(): void;
    writeValue(val: string): void;
    registerOnChange(fn: (v: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    private normalizeIcon;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkInputComponent, "sk-input", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "iconLeft": { "alias": "iconLeft"; "required": false; "isSignal": true; }; "iconRight": { "alias": "iconRight"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkInputMaskComponent implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    readonly mask: _angular_core.InputSignal<string>;
    readonly slotChar: _angular_core.InputSignal<string>;
    readonly helpText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly completed: _angular_core.OutputEmitterRef<unknown>;
    readonly inputId: string;
    readonly _value: _angular_core.WritableSignal<string>;
    private readonly _cvaDisabled;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    private _onChange;
    private _onTouched;
    handleInput(val: string): void;
    handleBlur(): void;
    writeValue(val: string): void;
    registerOnChange(fn: (v: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkInputMaskComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkInputMaskComponent, "sk-inputmask", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "mask": { "alias": "mask"; "required": false; "isSignal": true; }; "slotChar": { "alias": "slotChar"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "completed": "completed"; }, never, never, true, never>;
}

declare class SkInputNumberComponent implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    readonly min: _angular_core.InputSignal<number>;
    readonly max: _angular_core.InputSignal<number>;
    readonly step: _angular_core.InputSignal<number>;
    readonly prefix: _angular_core.InputSignal<string>;
    readonly suffix: _angular_core.InputSignal<string>;
    readonly helpText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly showButtons: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly mode: _angular_core.InputSignal<"decimal" | "currency">;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<number | null>;
    readonly inputId: string;
    readonly _value: _angular_core.WritableSignal<number | null>;
    private readonly _cvaDisabled;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    private _onChange;
    private _onTouched;
    handleInput(val: number | null): void;
    handleBlur(): void;
    writeValue(val: number | null): void;
    registerOnChange(fn: (v: number | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkInputNumberComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkInputNumberComponent, "sk-inputnumber", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "prefix": { "alias": "prefix"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "showButtons": { "alias": "showButtons"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkInputOtpComponent {
    readonly length: _angular_core.InputSignal<number>;
    readonly integerOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    value: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkInputOtpComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkInputOtpComponent, "sk-inputotp", never, { "length": { "alias": "length"; "required": false; "isSignal": true; }; "integerOnly": { "alias": "integerOnly"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkKnobComponent {
    readonly min: _angular_core.InputSignal<number>;
    readonly max: _angular_core.InputSignal<number>;
    readonly step: _angular_core.InputSignal<number>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly size: _angular_core.InputSignal<number>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    value: number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkKnobComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkKnobComponent, "sk-knob", never, { "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "showValue": { "alias": "showValue"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

interface SkListItem {
    label: string;
    value?: unknown;
    icon?: string;
    description?: string;
    disabled?: boolean;
}
declare class SkListComponent {
    readonly DEMO_CHECK: SkListItem[];
    readonly DEMO_TEXT: SkListItem[];
    readonly DEMO_ICON: SkListItem[];
    readonly DEMO_DESC: SkListItem[];
    readonly items: _angular_core.InputSignal<SkListItem[]>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showStates: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    readonly selected: _angular_core.OutputEmitterRef<unknown>;
    value: unknown;
    readonly resolvedStyle: _angular_core.Signal<"text" | "icon" | "check" | "description">;
    isSelected(item: SkListItem): boolean;
    handleSelect(item: SkListItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkListComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkListComponent, "sk-list", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "showStates": { "alias": "showStates"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; "selected": "selected"; }, never, never, true, never>;
}

interface SkListboxOption {
    label: string;
    value?: unknown;
    icon?: string;
    description?: string;
    disabled?: boolean;
    items?: SkListboxOption[];
}
type SkListboxListStyle = 'check' | 'text' | 'icon' | 'description' | 'empty';
declare class SkListboxComponent {
    readonly options: _angular_core.InputSignal<SkListboxOption[]>;
    readonly optionLabel: _angular_core.InputSignal<string>;
    readonly optionValue: _angular_core.InputSignal<string>;
    readonly listStyle: _angular_core.InputSignal<SkListboxListStyle>;
    readonly height: _angular_core.InputSignal<string>;
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterPlaceholder: _angular_core.InputSignal<string>;
    readonly group: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly optionGroupLabel: _angular_core.InputSignal<string>;
    readonly optionGroupChildren: _angular_core.InputSignal<string>;
    readonly emptyIcon: _angular_core.InputSignal<string>;
    readonly emptyTitle: _angular_core.InputSignal<string>;
    readonly emptyMessage: _angular_core.InputSignal<string>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    value: unknown;
    readonly resolvedListStyle: _angular_core.Signal<SkListboxListStyle>;
    readonly effectiveOptions: _angular_core.Signal<SkListboxOption[]>;
    readonly isCheckStyle: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkListboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkListboxComponent, "sk-listbox", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "listStyle": { "alias": "listStyle"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "group": { "alias": "group"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "emptyIcon": { "alias": "emptyIcon"; "required": false; "isSignal": true; }; "emptyTitle": { "alias": "emptyTitle"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkMegaMenuComponent {
    readonly orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    readonly model: _angular_core.InputSignal<MegaMenuItem[] | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkMegaMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkMegaMenuComponent, "sk-megamenu", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkMenuComponent {
    readonly model: _angular_core.InputSignal<MenuItem[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkMenuComponent, "sk-menu", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkMenubarComponent {
    readonly model: _angular_core.InputSignal<MenuItem[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkMenubarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkMenubarComponent, "sk-menubar", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkMeterGroupComponent {
    readonly value: _angular_core.InputSignal<{
        label: string;
        value: number;
        color: string;
    }[]>;
    readonly min: _angular_core.InputSignal<number>;
    readonly max: _angular_core.InputSignal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkMeterGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkMeterGroupComponent, "sk-metergroup", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkMultiSelectComponent implements ControlValueAccessor, OnDestroy {
    readonly label: _angular_core.InputSignal<string>;
    readonly options: _angular_core.InputSignal<{
        label: string;
        value: string;
    }[]>;
    readonly optionLabel: _angular_core.InputSignal<string>;
    readonly optionValue: _angular_core.InputSignal<string>;
    readonly helpText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly display: _angular_core.InputSignal<"comma" | "chip">;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    readonly inputId: string;
    readonly innerControl: FormControl<unknown[]>;
    private readonly _cvaDisabled;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    private _onChange;
    onTouched: () => void;
    private readonly sub;
    constructor();
    writeValue(val: unknown[]): void;
    registerOnChange(fn: (v: unknown[]) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkMultiSelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkMultiSelectComponent, "sk-multiselect", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "display": { "alias": "display"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkOrderListComponent {
    readonly header: _angular_core.InputSignal<string>;
    readonly items: _angular_core.InputSignal<{
        name: string;
        category: string;
    }[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkOrderListComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkOrderListComponent, "sk-orderlist", never, { "header": { "alias": "header"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkOrgChartComponent {
    readonly collapsible: _angular_core.InputSignal<boolean>;
    readonly nodes: _angular_core.InputSignal<TreeNode<any>[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkOrgChartComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkOrgChartComponent, "sk-orgchart", never, { "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type SkOverlayBadgeSeverity = 'secondary' | 'info' | 'success' | 'warn' | 'danger' | 'contrast';
type SkOverlayBadgeSize = 'small' | 'large' | 'xlarge';
declare class SkOverlayBadgeComponent {
    readonly value: _angular_core.InputSignal<string>;
    readonly severity: _angular_core.InputSignal<SkOverlayBadgeSeverity>;
    readonly badgeSize: _angular_core.InputSignal<SkOverlayBadgeSize>;
    readonly badgeDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly icon: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkOverlayBadgeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkOverlayBadgeComponent, "sk-overlaybadge", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "badgeSize": { "alias": "badgeSize"; "required": false; "isSignal": true; }; "badgeDisabled": { "alias": "badgeDisabled"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class SkPaginatorComponent {
    readonly first: _angular_core.InputSignal<number>;
    readonly rows: _angular_core.InputSignal<number>;
    readonly totalRecords: _angular_core.InputSignal<number>;
    readonly rowsPerPageOptions: _angular_core.InputSignal<number[]>;
    readonly showFirstLastIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showCurrentPageReport: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly pageChange: _angular_core.OutputEmitterRef<unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkPaginatorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkPaginatorComponent, "sk-paginator", never, { "first": { "alias": "first"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "totalRecords": { "alias": "totalRecords"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "showFirstLastIcon": { "alias": "showFirstLastIcon"; "required": false; "isSignal": true; }; "showCurrentPageReport": { "alias": "showCurrentPageReport"; "required": false; "isSignal": true; }; }, { "pageChange": "pageChange"; }, never, never, true, never>;
}

declare class SkPanelComponent {
    readonly header: _angular_core.InputSignal<string>;
    readonly content: _angular_core.InputSignal<string>;
    readonly toggleable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly collapsed: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly beforeToggle: _angular_core.OutputEmitterRef<unknown>;
    readonly afterToggle: _angular_core.OutputEmitterRef<unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkPanelComponent, "sk-panel", never, { "header": { "alias": "header"; "required": false; "isSignal": true; }; "content": { "alias": "content"; "required": false; "isSignal": true; }; "toggleable": { "alias": "toggleable"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; }, { "beforeToggle": "beforeToggle"; "afterToggle": "afterToggle"; }, never, ["*"], true, never>;
}

declare class SkPanelMenuComponent {
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly model: _angular_core.InputSignal<MenuItem[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkPanelMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkPanelMenuComponent, "sk-panelmenu", never, { "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkPasswordComponent implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly helpText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly feedback: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly toggleMask: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    readonly inputId: string;
    readonly _value: _angular_core.WritableSignal<string>;
    private readonly _cvaDisabled;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    private _onChange;
    constructor();
    private _onTouched;
    handleInput(val: string): void;
    handleBlur(): void;
    writeValue(val: string): void;
    registerOnChange(fn: (v: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkPasswordComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkPasswordComponent, "sk-password", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "feedback": { "alias": "feedback"; "required": false; "isSignal": true; }; "toggleMask": { "alias": "toggleMask"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkPickListComponent {
    readonly sourceHeader: _angular_core.InputSignal<string>;
    readonly targetHeader: _angular_core.InputSignal<string>;
    readonly source: _angular_core.InputSignal<{
        name: string;
    }[]>;
    readonly target: _angular_core.InputSignal<{
        name: string;
    }[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkPickListComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkPickListComponent, "sk-picklist", never, { "sourceHeader": { "alias": "sourceHeader"; "required": false; "isSignal": true; }; "targetHeader": { "alias": "targetHeader"; "required": false; "isSignal": true; }; "source": { "alias": "source"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkPopoverComponent {
    op: Popover;
    readonly triggerLabel: _angular_core.InputSignal<string>;
    readonly triggerIcon: _angular_core.InputSignal<string>;
    readonly title: _angular_core.InputSignal<string>;
    readonly content: _angular_core.InputSignal<string>;
    readonly dismissable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly shown: _angular_core.OutputEmitterRef<void>;
    readonly hidden: _angular_core.OutputEmitterRef<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkPopoverComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkPopoverComponent, "sk-popover", never, { "triggerLabel": { "alias": "triggerLabel"; "required": false; "isSignal": true; }; "triggerIcon": { "alias": "triggerIcon"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "content": { "alias": "content"; "required": false; "isSignal": true; }; "dismissable": { "alias": "dismissable"; "required": false; "isSignal": true; }; }, { "shown": "shown"; "hidden": "hidden"; }, never, ["*"], true, never>;
}

declare class SkProgressBarComponent {
    readonly value: _angular_core.InputSignal<number>;
    readonly mode: _angular_core.InputSignal<"determinate" | "indeterminate">;
    readonly showValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly labelLeft: _angular_core.InputSignal<string>;
    readonly labelRight: _angular_core.InputSignal<string>;
    readonly dynamic: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly _dynValue;
    private _timer?;
    readonly displayValue: _angular_core.Signal<number>;
    constructor();
    private _start;
    private _stop;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkProgressBarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkProgressBarComponent, "sk-progressbar", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "showValue": { "alias": "showValue"; "required": false; "isSignal": true; }; "labelLeft": { "alias": "labelLeft"; "required": false; "isSignal": true; }; "labelRight": { "alias": "labelRight"; "required": false; "isSignal": true; }; "dynamic": { "alias": "dynamic"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkProgressSpinnerComponent {
    readonly label: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkProgressSpinnerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkProgressSpinnerComponent, "sk-progressspinner", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkRadioComponent implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<unknown>;
    readonly name: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly _uid: string;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    readonly _groupValue: _angular_core.WritableSignal<unknown>;
    private readonly _cvaDisabled;
    readonly _checked: _angular_core.Signal<boolean>;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    private _onChange;
    onTouched: () => void;
    _onSelect(): void;
    writeValue(val: unknown): void;
    registerOnChange(fn: (val: unknown) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkRadioComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkRadioComponent, "sk-radio", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "showLabel": { "alias": "showLabel"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

interface SkRadioGroupOption {
    label: string;
    value: unknown;
    disabled?: boolean;
}
type SkRadioGroupLayout = 'horizontal' | 'vertical';
declare class SkRadiogroupComponent implements ControlValueAccessor {
    readonly options: _angular_core.InputSignal<SkRadioGroupOption[]>;
    readonly name: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly layout: _angular_core.InputSignal<SkRadioGroupLayout>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    readonly _uid: string;
    readonly _selected: _angular_core.WritableSignal<unknown>;
    private readonly _cvaDisabled;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    private _onChange;
    onTouched: () => void;
    _onSelect(val: unknown): void;
    writeValue(val: unknown): void;
    registerOnChange(fn: (val: unknown) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkRadiogroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkRadiogroupComponent, "sk-radiogroup", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkRatingComponent implements OnChanges {
    readonly value: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly stars: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    readonly showValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<number>;
    readonly rated: _angular_core.OutputEmitterRef<unknown>;
    _value: number;
    ngOnChanges(changes: SimpleChanges): void;
    onRate(event: unknown): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkRatingComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkRatingComponent, "sk-rating", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "stars": { "alias": "stars"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "showValue": { "alias": "showValue"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; "rated": "rated"; }, never, never, true, never>;
}

type SkScrollPanelSize = 'small' | 'medium';
declare class SkScrollPanelComponent {
    readonly size: _angular_core.InputSignal<SkScrollPanelSize>;
    readonly width: _angular_core.InputSignal<string>;
    readonly height: _angular_core.InputSignal<string>;
    readonly step: _angular_core.InputSignal<number>;
    readonly demoLines: number[];
    readonly scrollStyleClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkScrollPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkScrollPanelComponent, "sk-scrollpanel", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkScrollTopComponent {
    readonly threshold: _angular_core.InputSignal<number>;
    readonly behavior: _angular_core.InputSignal<"smooth" | "auto">;
    readonly icon: _angular_core.InputSignal<string>;
    lines: number[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkScrollTopComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkScrollTopComponent, "sk-scrolltop", never, { "threshold": { "alias": "threshold"; "required": false; "isSignal": true; }; "behavior": { "alias": "behavior"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkSelectButtonComponent {
    readonly options: _angular_core.InputSignal<{
        label: string;
        value: string;
    }[]>;
    readonly optionLabel: _angular_core.InputSignal<string>;
    readonly optionValue: _angular_core.InputSignal<string>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    value: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkSelectButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkSelectButtonComponent, "sk-selectbutton", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkSkeletonComponent {
    readonly shape: _angular_core.InputSignal<"square" | "rectangle" | "rounded" | "circle">;
    readonly width: _angular_core.InputSignal<string>;
    readonly height: _angular_core.InputSignal<string>;
    readonly borderRadius: _angular_core.InputSignal<string>;
    readonly animation: _angular_core.InputSignal<"wave" | "none">;
    readonly count: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly _pShape: _angular_core.Signal<"rectangle" | "circle">;
    readonly _borderRadius: _angular_core.Signal<string>;
    readonly _items: _angular_core.Signal<number[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkSkeletonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkSkeletonComponent, "sk-skeleton", never, { "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "borderRadius": { "alias": "borderRadius"; "required": false; "isSignal": true; }; "animation": { "alias": "animation"; "required": false; "isSignal": true; }; "count": { "alias": "count"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkSliderComponent {
    readonly min: _angular_core.InputSignal<number>;
    readonly max: _angular_core.InputSignal<number>;
    readonly step: _angular_core.InputSignal<number>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    readonly range: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    value: number | [number, number];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkSliderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkSliderComponent, "sk-slider", never, { "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "range": { "alias": "range"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkSpeedDialComponent {
    readonly model: _angular_core.InputSignal<MenuItem[]>;
    readonly direction: _angular_core.InputSignal<"left" | "right" | "up" | "down">;
    readonly type: _angular_core.InputSignal<"circle" | "linear" | "semi-circle" | "quarter-circle">;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly radius: _angular_core.InputSignal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkSpeedDialComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkSpeedDialComponent, "sk-speeddial", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "direction": { "alias": "direction"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "radius": { "alias": "radius"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkSplitButtonComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly model: _angular_core.InputSignal<MenuItem[]>;
    readonly severity: _angular_core.InputSignal<"success" | "info" | "warn" | "secondary" | "contrast" | "danger" | undefined>;
    readonly outlined: _angular_core.InputSignal<boolean>;
    readonly raised: _angular_core.InputSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly clicked: _angular_core.OutputEmitterRef<MouseEvent>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkSplitButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkSplitButtonComponent, "sk-splitbutton", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "raised": { "alias": "raised"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "clicked": "clicked"; }, never, never, true, never>;
}

interface SkStep {
    value: string;
    label: string;
    content?: string;
}
declare class SkStepperComponent {
    readonly steps: _angular_core.InputSignal<SkStep[]>;
    readonly activeStep: _angular_core.InputSignal<string>;
    readonly linear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly stepChange: _angular_core.OutputEmitterRef<string>;
    private readonly _active;
    readonly resolvedActive: _angular_core.Signal<string>;
    readonly activeIndex: _angular_core.Signal<number>;
    readonly activeStepData: _angular_core.Signal<SkStep | null>;
    isActive(value: string): boolean;
    isDone(index: number): boolean;
    goTo(value: string): void;
    next(): void;
    prev(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkStepperComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkStepperComponent, "sk-stepper", never, { "steps": { "alias": "steps"; "required": false; "isSignal": true; }; "activeStep": { "alias": "activeStep"; "required": false; "isSignal": true; }; "linear": { "alias": "linear"; "required": false; "isSignal": true; }; }, { "stepChange": "stepChange"; }, never, never, true, never>;
}

declare class SkStepsComponent {
    readonly model: _angular_core.InputSignal<MenuItem[]>;
    readonly activeIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly exact: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly activeIndexChange: _angular_core.OutputEmitterRef<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkStepsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkStepsComponent, "sk-steps", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "exact": { "alias": "exact"; "required": false; "isSignal": true; }; }, { "activeIndexChange": "activeIndexChange"; }, never, never, true, never>;
}

declare class SkSwitchComponent implements OnInit {
    readonly checked: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    internalChecked: boolean;
    ngOnInit(): void;
    handleChange(event: unknown): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkSwitchComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkSwitchComponent, "sk-switch", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

type SkTableBadgeVariant = 'success' | 'warning' | 'error' | 'info';
interface SkTableColumn {
    field: string;
    header: string;
    sortable?: boolean;
    subfield?: string;
    type?: 'text' | 'badge';
    badgeSeverity?: (value: unknown) => SkTableBadgeVariant;
    badgeVariantMap?: Record<string, SkTableBadgeVariant>;
    format?: (value: unknown) => string;
    width?: string;
}
interface SkFilterGroup {
    label: string;
    field: string;
    options: {
        label: string;
        value: string;
    }[];
}
interface SkActiveFilter {
    field: string;
    value: string;
    label: string;
    groupLabel: string;
}
interface SkRowAction {
    id: string;
    label: string;
    icon?: string;
}
declare class SkTableComponent {
    readonly data: _angular_core.InputSignal<Record<string, unknown>[]>;
    readonly columns: _angular_core.InputSignal<SkTableColumn[]>;
    readonly filterGroups: _angular_core.InputSignal<SkFilterGroup[]>;
    readonly rowActions: _angular_core.InputSignal<SkRowAction[]>;
    readonly searchPlaceholder: _angular_core.InputSignal<string>;
    readonly rowsPerPageOptions: _angular_core.InputSignal<number[]>;
    readonly totalRecords: _angular_core.InputSignal<number | null>;
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly striped: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly emptyMessage: _angular_core.InputSignal<string>;
    readonly searchChange: _angular_core.OutputEmitterRef<string>;
    readonly filterChange: _angular_core.OutputEmitterRef<SkActiveFilter[]>;
    readonly pageChange: _angular_core.OutputEmitterRef<{
        page: number;
        rows: number;
        first: number;
    }>;
    readonly sortChange: _angular_core.OutputEmitterRef<{
        field: string;
        order: number;
    }>;
    readonly rowActionSelect: _angular_core.OutputEmitterRef<{
        actionId: string;
        row: Record<string, unknown>;
    }>;
    private readonly _filterPopover;
    private readonly _rowMenu;
    private readonly _currentMenuRow;
    readonly _rows: _angular_core.WritableSignal<number>;
    readonly _first: _angular_core.WritableSignal<number>;
    private readonly _searchValue;
    private readonly _filterSelections;
    readonly activeFilters: _angular_core.Signal<SkActiveFilter[]>;
    readonly displayData: _angular_core.Signal<Record<string, unknown>[]>;
    readonly effectiveTotalRecords: _angular_core.Signal<number>;
    readonly pageData: _angular_core.Signal<Record<string, unknown>[]>;
    readonly _menuItems: _angular_core.Signal<MenuItem[]>;
    onSearch(event: Event): void;
    toggleFilterOption(field: string, value: string): void;
    isOptionSelected(field: string, value: string): boolean;
    removeFilter(filter: SkActiveFilter): void;
    onRowsChange(rows: number): void;
    onPageChange(event: unknown): void;
    toggleFilterPanel(event: Event): void;
    openRowMenu(event: Event, row: Record<string, unknown>): void;
    onSort(event: {
        field: string;
        order: number;
    }): void;
    getCellValue(row: Record<string, unknown>, col: SkTableColumn): string;
    getBadgeVariant(row: Record<string, unknown>, col: SkTableColumn): SkTableBadgeVariant;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTableComponent, "sk-table", never, { "data": { "alias": "data"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "filterGroups": { "alias": "filterGroups"; "required": false; "isSignal": true; }; "rowActions": { "alias": "rowActions"; "required": false; "isSignal": true; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "totalRecords": { "alias": "totalRecords"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "striped": { "alias": "striped"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; }, { "searchChange": "searchChange"; "filterChange": "filterChange"; "pageChange": "pageChange"; "sortChange": "sortChange"; "rowActionSelect": "rowActionSelect"; }, never, never, true, never>;
}

declare class SkTabsComponent {
    readonly tabs: _angular_core.InputSignal<{
        value: string;
        label: string;
        content: string;
    }[]>;
    readonly activeValue: _angular_core.InputSignal<string>;
    readonly scrollable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTabsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTabsComponent, "sk-tabs", never, { "tabs": { "alias": "tabs"; "required": false; "isSignal": true; }; "activeValue": { "alias": "activeValue"; "required": false; "isSignal": true; }; "scrollable": { "alias": "scrollable"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkTagComponent {
    readonly value: _angular_core.InputSignal<string>;
    readonly severity: _angular_core.InputSignal<"success" | "info" | "warn" | "secondary" | "contrast" | "danger" | undefined>;
    readonly rounded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly showAll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTagComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTagComponent, "sk-tag", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "showAll": { "alias": "showAll"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkTerminalComponent implements OnInit {
    private terminalService;
    readonly welcomeMessage: _angular_core.InputSignal<string>;
    readonly prompt: _angular_core.InputSignal<string>;
    private subscription;
    constructor(terminalService: TerminalService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTerminalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTerminalComponent, "sk-terminal", never, { "welcomeMessage": { "alias": "welcomeMessage"; "required": false; "isSignal": true; }; "prompt": { "alias": "prompt"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type SkTextLinkSize = 'small' | 'large';
declare class SkTextLinkComponent {
    readonly size: _angular_core.InputSignal<SkTextLinkSize>;
    readonly href: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly iconLeft: _angular_core.InputSignal<string | boolean>;
    readonly iconRight: _angular_core.InputSignal<string | boolean>;
    readonly external: _angular_core.InputSignal<string | boolean>;
    readonly clicked: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly isExternal: _angular_core.Signal<boolean>;
    readonly isIconLeft: _angular_core.Signal<boolean>;
    readonly isIconRight: _angular_core.Signal<boolean>;
    readonly iconLeftClass: _angular_core.Signal<string | null>;
    readonly iconRightClass: _angular_core.Signal<string | null>;
    readonly linkClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTextLinkComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTextLinkComponent, "sk-text-link", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "iconLeft": { "alias": "iconLeft"; "required": false; "isSignal": true; }; "iconRight": { "alias": "iconRight"; "required": false; "isSignal": true; }; "external": { "alias": "external"; "required": false; "isSignal": true; }; }, { "clicked": "clicked"; }, never, never, true, never>;
}

declare class SkTextareaComponent implements ControlValueAccessor, OnDestroy {
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly helpText: _angular_core.InputSignal<string>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly rows: _angular_core.InputSignal<number>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoResize: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    readonly inputId: string;
    readonly innerControl: FormControl<string>;
    private readonly _cvaDisabled;
    readonly _isDisabled: _angular_core.Signal<boolean>;
    private _onChange;
    onTouched: () => void;
    private readonly sub;
    constructor();
    writeValue(val: string): void;
    registerOnChange(fn: (v: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(d: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTextareaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTextareaComponent, "sk-textarea", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "helpText": { "alias": "helpText"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "autoResize": { "alias": "autoResize"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkTieredMenuComponent {
    readonly model: _angular_core.InputSignal<MenuItem[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTieredMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTieredMenuComponent, "sk-tieredmenu", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkTimelineComponent {
    readonly events: _angular_core.InputSignal<{
        title: string;
        date: string;
        icon: string;
    }[]>;
    readonly align: _angular_core.InputSignal<"left" | "right" | "alternate">;
    readonly layout: _angular_core.InputSignal<"horizontal" | "vertical">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTimelineComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTimelineComponent, "sk-timeline", never, { "events": { "alias": "events"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkToastComponent {
    readonly position: _angular_core.InputSignal<ToastPositionType>;
    readonly life: _angular_core.InputSignal<number>;
    private readonly messageService;
    show(severity: string, summary: string, detail: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkToastComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkToastComponent, "sk-toast", never, { "position": { "alias": "position"; "required": false; "isSignal": true; }; "life": { "alias": "life"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkToggleButtonComponent {
    checked: boolean;
    readonly onLabel: _angular_core.InputSignal<string>;
    readonly offLabel: _angular_core.InputSignal<string>;
    readonly onIcon: _angular_core.InputSignal<string>;
    readonly offIcon: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkToggleButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkToggleButtonComponent, "sk-togglebutton", never, { "onLabel": { "alias": "onLabel"; "required": false; "isSignal": true; }; "offLabel": { "alias": "offLabel"; "required": false; "isSignal": true; }; "onIcon": { "alias": "onIcon"; "required": false; "isSignal": true; }; "offIcon": { "alias": "offIcon"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkToolbarComponent {
    readonly startContent: _angular_core.InputSignal<string>;
    readonly centerContent: _angular_core.InputSignal<string>;
    readonly endContent: _angular_core.InputSignal<string>;
    readonly styleClass: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkToolbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkToolbarComponent, "sk-toolbar", never, { "startContent": { "alias": "startContent"; "required": false; "isSignal": true; }; "centerContent": { "alias": "centerContent"; "required": false; "isSignal": true; }; "endContent": { "alias": "endContent"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SkTooltipComponent {
    readonly content: _angular_core.InputSignal<string>;
    readonly position: _angular_core.InputSignal<"left" | "right" | "top" | "bottom">;
    readonly showDelay: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly hideDelay: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly escape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTooltipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTooltipComponent, "sk-tooltip", never, { "content": { "alias": "content"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "showDelay": { "alias": "showDelay"; "required": false; "isSignal": true; }; "hideDelay": { "alias": "hideDelay"; "required": false; "isSignal": true; }; "escape": { "alias": "escape"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class SkTreeComponent {
    readonly nodes: _angular_core.InputSignal<TreeNode<any>[]>;
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple" | "checkbox" | null>;
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly filterPlaceholder: _angular_core.InputSignal<string>;
    readonly selectionChange: _angular_core.OutputEmitterRef<unknown>;
    readonly nodeSelected: _angular_core.OutputEmitterRef<unknown>;
    readonly nodeUnselected: _angular_core.OutputEmitterRef<unknown>;
    _selection: TreeNode | TreeNode[] | null;
    onSelectionChange(event: TreeNode | TreeNode[] | null | undefined): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTreeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTreeComponent, "sk-tree", never, { "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; "nodeSelected": "nodeSelected"; "nodeUnselected": "nodeUnselected"; }, never, never, true, never>;
}

declare class SkTreeSelectComponent {
    value: unknown;
    readonly options: _angular_core.InputSignal<TreeNode<any>[]>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple" | "checkbox">;
    readonly valueChange: _angular_core.OutputEmitterRef<unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTreeSelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTreeSelectComponent, "sk-treeselect", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class SkTreeTableComponent {
    readonly nodes: _angular_core.InputSignal<TreeNode<any>[]>;
    readonly columns: _angular_core.InputSignal<{
        field: string;
        header: string;
    }[]>;
    readonly scrollable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly scrollHeight: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkTreeTableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkTreeTableComponent, "sk-treetable", never, { "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "scrollable": { "alias": "scrollable"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface SkLoginPayload {
    email: string;
    password: string;
    rememberMe: boolean;
}
declare class SkLoginFormComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly subtitle: _angular_core.InputSignal<string>;
    readonly logoUrl: _angular_core.InputSignal<string>;
    readonly logoAlt: _angular_core.InputSignal<string>;
    readonly emailLabel: _angular_core.InputSignal<string>;
    readonly emailPlaceholder: _angular_core.InputSignal<string>;
    readonly emailRequired: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly passwordLabel: _angular_core.InputSignal<string>;
    readonly passwordPlaceholder: _angular_core.InputSignal<string>;
    readonly passwordRequired: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rememberLabel: _angular_core.InputSignal<string>;
    readonly forgotLabel: _angular_core.InputSignal<string>;
    readonly submitLabel: _angular_core.InputSignal<string>;
    readonly registerLabel: _angular_core.InputSignal<string>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly errorMessage: _angular_core.InputSignal<string>;
    readonly loginSubmit: _angular_core.OutputEmitterRef<SkLoginPayload>;
    readonly forgotPasswordClick: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly registerClick: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly email: _angular_core.WritableSignal<string>;
    readonly password: _angular_core.WritableSignal<string>;
    readonly rememberMe: _angular_core.WritableSignal<boolean>;
    readonly isValid: _angular_core.Signal<boolean>;
    handleSubmit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkLoginFormComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SkLoginFormComponent, "sk-login-form", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "logoUrl": { "alias": "logoUrl"; "required": false; "isSignal": true; }; "logoAlt": { "alias": "logoAlt"; "required": false; "isSignal": true; }; "emailLabel": { "alias": "emailLabel"; "required": false; "isSignal": true; }; "emailPlaceholder": { "alias": "emailPlaceholder"; "required": false; "isSignal": true; }; "emailRequired": { "alias": "emailRequired"; "required": false; "isSignal": true; }; "passwordLabel": { "alias": "passwordLabel"; "required": false; "isSignal": true; }; "passwordPlaceholder": { "alias": "passwordPlaceholder"; "required": false; "isSignal": true; }; "passwordRequired": { "alias": "passwordRequired"; "required": false; "isSignal": true; }; "rememberLabel": { "alias": "rememberLabel"; "required": false; "isSignal": true; }; "forgotLabel": { "alias": "forgotLabel"; "required": false; "isSignal": true; }; "submitLabel": { "alias": "submitLabel"; "required": false; "isSignal": true; }; "registerLabel": { "alias": "registerLabel"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, { "loginSubmit": "loginSubmit"; "forgotPasswordClick": "forgotPasswordClick"; "registerClick": "registerClick"; }, never, never, true, never>;
}

/**
 * Skandia Design System Theme Preset
 * Extiende PrimeNG Aura con los tokens y CSS de Skandia.
 * La base visual sale de skandia-theme.tokens.ts y de los aliases CSS globales.
 */
declare const SkandiaPreset: _primeuix_themes_types.Preset;

declare const SKANDIA_THEME_TOKENS: {
    readonly color: {
        readonly brand: {
            readonly 50: "#f6fcf2";
            readonly 100: "#caf9cb";
            readonly 200: "#5fed73";
            readonly 300: "#47e264";
            readonly 400: "#1dd64c";
            readonly 500: "#00c73d";
            readonly 600: "#03a835";
            readonly 700: "#009a2f";
            readonly 800: "#007c26";
            readonly 900: "#006e22";
        };
        readonly neutral: {
            readonly 0: "#ffffff";
            readonly 50: "#fafafa";
            readonly 100: "#f7f7f7";
            readonly 200: "#e9e9e9";
            readonly 300: "#dddddd";
            readonly 400: "#c5c5c5";
            readonly 500: "#b7b7b7";
            readonly 600: "#878787";
            readonly 700: "#666666";
            readonly 800: "#404040";
            readonly 900: "#232323";
            readonly 950: "#000000";
        };
        readonly info: {
            readonly light: "#ebf4ff";
            readonly dark: "#0099de";
        };
        readonly warning: {
            readonly light: "#fff3e0";
            readonly dark: "#ffae08";
        };
        readonly error: {
            readonly light: "#fff5f4";
            readonly dark: "#e03430";
        };
        readonly success: {
            readonly light: "#ecfdf3";
            readonly dark: "#87f491";
        };
    };
    readonly radius: {
        readonly none: "0";
        readonly xs: "2px";
        readonly sm: "4px";
        readonly md: "6px";
        readonly lg: "8px";
        readonly xl: "12px";
        readonly full: "9999px";
    };
    readonly motion: {
        readonly focusRingWidth: "2px";
        readonly focusRingOffset: "2px";
    };
};
type SkandiaThemeTokens = typeof SKANDIA_THEME_TOKENS;

declare function provideSkandiaUI(): EnvironmentProviders;

declare const SKANDIA_DESIGN_TOKENS_CSS = ":root { --primary-d04: #006e22; --primary-d03: #007c26; --primary-d02: #009a2f; --primary-d01: #03a835; --primary-00: #00c73d; --primary-l01: #1dd64c; --primary-l02: #47e264; --primary-l03: #5fed73; --primary-l04: #caf9cb; --primary-l05: #f6fcf2; --primarygrey-d05: #000000; --primarygrey-d04: #232323; --primarygrey-d03: #2c2c2c; --primarygrey-d02: #323232; --primarygrey-d01: #363636; --primarygrey-00: #404040; --primarygrey-l01: #444444; --primarygrey-l02: #565656; --primarygrey-l03: #666666; --primarygrey-l04: #878787; --primarygrey-l05: #a5a5a5; --secondarygreencomplementary-d04: #487000; --secondarygreencomplementary-d03: #629a00; --secondarygreencomplementary-d02: #6ba800; --secondarygreencomplementary-d01: #7dc400; --secondarygreencomplementary-00: #8fe000; --secondarygreencomplementary-l01: #a5e633; --secondarygreencomplementary-l02: #bbec65; --secondarygreencomplementary-l03: #d2f298; --secondarygreencomplementary-l04: #ddf6b1; --secondarygreencomplementary-l05: #f3fce3; --secondarybluecomplementary-d05: #1d594c; --secondarybluecomplementary-d04: #29806d; --secondarybluecomplementary-d03: #39b398; --secondarybluecomplementary-d02: #42ccae; --secondarybluecomplementary-d01: #4ae6c3; --secondarybluecomplementary-00: #52ffd9; --secondarybluecomplementary-l01: #76fee0; --secondarybluecomplementary-l02: #76fee0; --secondarybluecomplementary-l03: #bbfdee; --secondarybluecomplementary-l04: #ccfdf2; --secondarybluecomplementary-l05: #edfefa; --neutral-00: #ffffff; --neutral-l01: #fafafa; --neutral-l02: #f7f7f7; --neutral-l03: #e9e9e9; --neutral-l04: #dddddd; --neutral-l05: #c5c5c5; --neutral-l06: #b7b7b7; --feedback-success-light: #ecfdf3; --feedback-success-medium: #87f491; --feedback-success-dark: #16d727; --feedback-warning-light: #fff3e0; --feedback-warning-dark: #ffae08; --feedback-info-light: #ebf4ff; --feedback-info-dark: #0099de; --feedback-error-light: #fff5f4; --feedback-error-dark: #e03430; --feedback-standby-light: #f5f5f5; --feedback-standby-dark: #444444; --extras-c01: #a1dd70; --extras-c02: #a4d7e1; --extras-c03: #60a9a6; --extras-c04: #ff9460; --extras-c05: #8ba2c1; --extras-c06: #f67e7d; --extras-c07: #dddfd0; --extras-c08: #6a7491; --extras-c09: #de423e; --extras-c10: #95dbb7; --extras-c11: #ffbf9f; --extras-c12: #bc6995; --extras-c13: #d9d052; --extras-c14: #d6c09c; --extras-c15: #fecd72; --extras-c16: #cba1d2; --extras-c17: #c5d8a4; --extras-c18: #368cb5; --extras-c19: #00f59f; --extras-c20: #f50cc9; --extras-c21: #83a488; --extras-c22: #fcf9c6; --extras-c23: #b2f9fc; --extras-c24: #bf9078; --extras-c25: #9eb23b; --extras-c26: #73777b; --extras-c27: #ffe2e2; --extras-c28: #36d6e0; --extras-c29: #aba09d; --extras-c30: #b5d1ff; --extras-c31: #ecffb5; --extras-c32: #6f32c6; --extras-c33: #1f6feb; --extras-c34: #2e8b57; --extras-c35: #f4b400; --extras-c36: #ff5a5f; --extras-c37: #7b3fa1; --extras-c38: #1abc9c; --extras-c39: #f28c28; --extras-c40: #4f6d8a; --illustration-01: #00f0e0; --illustration-02: #45e39e; --illustration-03: #45ad00; --illustration-04: #ffae08; } :root { --size-000: 0px; --size-008: 8px; --size-016: 16px; --size-024: 24px; --size-032: 32px; --size-040: 40px; --size-048: 48px; --size-056: 56px; --size-064: 64px; --size-072: 72px; --size-080: 80px; --size-088: 88px; --size-096: 96px; --size-104: 104px; --size-112: 112px; --size-120: 120px; --size-128: 128px; --size-004: 4px; --size-012: 12px; } :root { --texts-white: var(--neutral-00); --texts-light: var(--primarygrey-l05); --texts-dark: var(--primarygrey-00); --texts-medium: var(--primarygrey-l03); --texts-brand: var(--primary-00); --texts-fiduciaria: var(--secondarybluecomplementary-d04); --texts-complementary: var(--secondarybluecomplementary-d01); --texts-link: var(--feedback-info-dark); --icon-disable: var(--primarygrey-l05); --icon-neutral: var(--primarygrey-00); --icon-neutral-2: var(--primarygrey-l03); --icon-link: var(--feedback-info-dark); --icon-white: var(--neutral-00); --icon-brand: var(--primary-00); --icon-fiduciaria: var(--secondarybluecomplementary-d04); --icon-success: var(--feedback-success-dark); --button-brand-default: var(--primary-00); --button-disable: var(--neutral-l03); --background-principal: var(--neutral-00); --background-grey-light: var(--neutral-l02); --background-brand-light: var(--primary-l05); --stroke-brand: var(--primary-00); --stroke-fiduciaria: var(--secondarybluecomplementary-d04); --stroke-grey-light: var(--neutral-l04); --stroke-grey-dark: var(--primarygrey-l03); --button-brand-hover: var(--primary-d01); --button-brand-secondary-hover: var(--primary-l04); --button-brand-tertiary-hover: var(--primary-l05); --button-fiduciaria-default: var(--secondarybluecomplementary-d04); --button-fiduciaria-hover: var(--secondarybluecomplementary-d05); --button-fiduciaria-secondary-hover: var(--secondarybluecomplementary-l04); --button-fiduciaria-tertiary-hover: var(--secondarybluecomplementary-l05); --stroke-grey-medium: var(--neutral-l05); --background-grey-medium: var(--neutral-l06); --background-grey-dark: var(--primarygrey-00); --stroke-success: var(--feedback-success-dark); --stroke-warning: var(--feedback-warning-dark); --stroke-info: var(--feedback-info-dark); --stroke-error-dark: var(--feedback-error-dark); --background-brand: var(--primary-00); --background-fiduciaria: var(--neutral-l02); --background-success-light: var(--feedback-success-light); --background-success-medium: var(--feedback-success-medium); --background-success-dark: var(--feedback-success-dark); --background-warning-dark: var(--feedback-warning-dark); --background-warning-light: var(--feedback-warning-light); --background-info-dark: var(--feedback-info-dark); --background-info-light: var(--feedback-info-light); --background-error-dark: var(--feedback-error-dark); --background-error-light: var(--feedback-error-light); --charts-c01: var(--extras-c01); --charts-c02: var(--extras-c02); --charts-c03: var(--extras-c03); --charts-c04: var(--extras-c04); --charts-c05: var(--extras-c05); --charts-c06: var(--extras-c06); --charts-c07: var(--extras-c07); --charts-c08: var(--extras-c08); --charts-c09: var(--extras-c09); --charts-c10: var(--extras-c10); --charts-c11: var(--extras-c11); --charts-c12: var(--extras-c12); --charts-c13: var(--extras-c13); --charts-c14: var(--extras-c14); --charts-c15: var(--extras-c15); --charts-c16: var(--extras-c16); --charts-c17: var(--extras-c17); --charts-c18: var(--extras-c18); --charts-c19: var(--extras-c19); --charts-c20: var(--extras-c20); --charts-c21: var(--extras-c21); --charts-c22: var(--extras-c22); --charts-c23: var(--extras-c23); --charts-c24: var(--extras-c24); --charts-c25: var(--extras-c25); --charts-c26: var(--extras-c26); --charts-c27: var(--extras-c27); --charts-c28: var(--extras-c28); --charts-c29: var(--extras-c29); --charts-c30: var(--extras-c30); --charts-c31: var(--extras-c31); --charts-c32: var(--extras-c32); --charts-c33: var(--extras-c33); --charts-c34: var(--extras-c34); --charts-c35: var(--extras-c35); --charts-c36: var(--extras-c36); --charts-c37: var(--extras-c37); --charts-c38: var(--extras-c38); --charts-c39: var(--extras-c39); --charts-c40: var(--extras-c40); --texts-error: var(--feedback-error-dark); --background-black: var(--primarygrey-d04); --icon-warning: var(--feedback-warning-dark); --icon-error: var(--feedback-error-dark); --estilos-degrade: linear-gradient(135deg, var(--primary-00), var(--secondarygreencomplementary-00)); } :root { --size-xxs: var(--size-004); --size-xs: var(--size-008); --size-s: var(--size-012); --size-m: var(--size-016); --size-l: var(--size-024); --size-xl: var(--size-032); --size-2xl: var(--size-040); --size-3xl: var(--size-048); --size-4xl: var(--size-056); --size-zero: var(--size-000); --bordes-m: var(--size-016); --bordes-l: var(--size-032); --bordes-xl: var(--size-104); --bordes-s: var(--size-004); --size-5xl: var(--size-064); --breakpoint-mobile: 768px; --breakpoint-tablet: 1024px; --grid-mobile-columns: 4; --grid-mobile-gutter: var(--size-m); --grid-mobile-margin: var(--size-m); --grid-tablet-columns: 8; --grid-tablet-gutter: var(--size-l); --grid-tablet-margin: var(--size-xl); --grid-desktop-columns: 12; --grid-desktop-gutter: var(--size-l); --grid-desktop-margin: 90px; } :root { --weight-regular: 400; --weight-medium: 500; --weight-bold: 700; --title: \"Montserrat\"; --body: \"Open Sans\"; } :root { --auxiliary-title-h6-medium-14px-font: var(--title); --auxiliary-title-h6-medium-14px-weight: var(--weight-medium); --auxiliary-title-h6-medium-14px-size: 0.875rem; --auxiliary-title-h6-medium-14px-line-height: 1.375rem; --auxiliary-title-h6-medium-14px-tracking: var(--size-zero); --caption-body-3-font: var(--body); --caption-body-3-weight: var(--weight-medium); --caption-body-3-size: var(--size-s); --caption-body-3-line-height: 1.25rem; --caption-body-3-tracking: var(--size-zero); --caption-body-3-bold-font: var(--body); --caption-body-3-bold-weight: var(--weight-bold); --caption-body-3-bold-size: var(--size-s); --caption-body-3-bold-line-height: 1.25rem; --caption-body-3-bold-tracking: var(--size-zero); --meta-title-h5-medium-16-px-font: var(--title); --meta-title-h5-medium-16-px-weight: var(--weight-medium); --meta-title-h5-medium-16-px-size: var(--size-m); --meta-title-h5-medium-16-px-line-height: var(--size-l); --meta-title-h5-medium-16-px-tracking: var(--size-zero); --body-medium-font: var(--body); --body-medium-weight: var(--weight-medium); --body-medium-size: var(--size-m); --body-medium-line-height: var(--size-l); --body-medium-tracking: var(--size-zero); --body-bold-font: var(--body); --body-bold-weight: var(--weight-bold); --body-bold-size: var(--size-m); --body-bold-line-height: var(--size-l); --body-bold-tracking: var(--size-zero); --label-medium-font: var(--body); --label-medium-weight: var(--weight-medium); --label-medium-size: 0.875rem; --label-medium-line-height: 1.375rem; --label-medium-tracking: var(--size-zero); --label-bold-font: var(--body); --label-bold-weight: var(--weight-bold); --label-bold-size: 0.875rem; --label-bold-line-height: 1.375rem; --label-bold-tracking: var(--size-zero); --meta-title-h5-bold-16-px-font: var(--title); --meta-title-h5-bold-16-px-weight: var(--weight-bold); --meta-title-h5-bold-16-px-size: var(--size-m); --meta-title-h5-bold-16-px-line-height: var(--size-l); --meta-title-h5-bold-16-px-tracking: var(--size-zero); --auxiliary-title-h6-bold-14px-font: var(--title); --auxiliary-title-h6-bold-14px-weight: var(--weight-bold); --auxiliary-title-h6-bold-14px-size: 0.875rem; --auxiliary-title-h6-bold-14px-line-height: 1.375rem; --auxiliary-title-h6-bold-14px-tracking: var(--size-zero); --section-title-h2-medium-24px-font: var(--title); --section-title-h2-medium-24px-weight: var(--weight-medium); --section-title-h2-medium-24px-size: var(--size-l); --section-title-h2-medium-24px-line-height: var(--size-xl); --section-title-h2-medium-24px-tracking: var(--size-zero); --subsection-title-h3-medium-20px-font: var(--title); --subsection-title-h3-medium-20px-weight: var(--weight-medium); --subsection-title-h3-medium-20px-size: 1.25rem; --subsection-title-h3-medium-20px-line-height: 1.75rem; --subsection-title-h3-medium-20px-tracking: 0rem; --section-title-h2-bold-24px-font: var(--title); --section-title-h2-bold-24px-weight: var(--weight-bold); --section-title-h2-bold-24px-size: var(--size-l); --section-title-h2-bold-24px-line-height: var(--size-xl); --section-title-h2-bold-24px-tracking: var(--size-zero); --subsection-title-h3-bold-20px-font: var(--title); --subsection-title-h3-bold-20px-weight: var(--weight-bold); --subsection-title-h3-bold-20px-size: 1.25rem; --subsection-title-h3-bold-20px-line-height: 1.75rem; --subsection-title-h3-bold-20px-tracking: 0rem; --supporting-title-h4-medium-18px-font: var(--title); --supporting-title-h4-medium-18px-weight: var(--weight-medium); --supporting-title-h4-medium-18px-size: 1.125rem; --supporting-title-h4-medium-18px-line-height: 1.625rem; --supporting-title-h4-medium-18px-tracking: 0rem; --supporting-title-h4-bold-18px-font: var(--title); --supporting-title-h4-bold-18px-weight: var(--weight-bold); --supporting-title-h4-bold-18px-size: 1.125rem; --supporting-title-h4-bold-18px-line-height: 1.625rem; --supporting-title-h4-bold-18px-tracking: 0rem; --page-title-h1-medium-32px-font: var(--title); --page-title-h1-medium-32px-weight: var(--weight-medium); --page-title-h1-medium-32px-size: var(--size-xl); --page-title-h1-medium-32px-line-height: var(--size-2xl); --page-title-h1-medium-32px-tracking: var(--size-zero); --page-title-h1-bold-32px-font: var(--title); --page-title-h1-bold-32px-weight: var(--weight-bold); --page-title-h1-bold-32px-size: var(--size-xl); --page-title-h1-bold-32px-line-height: var(--size-2xl); --page-title-h1-bold-32px-tracking: var(--size-zero); } :root { --color-primary: var(--background-brand); --color-primary-hover: var(--button-brand-hover); --color-secondary: var(--background-grey-light); --color-secondary-hover: var(--neutral-l03); --color-primary-soft: var(--background-brand-light); --color-primary-strong: var(--button-brand-hover); --color-success: var(--background-success-dark); --color-warning: var(--background-warning-dark); --color-error: var(--background-error-dark); --color-info: var(--background-info-dark); --color-success-bg: var(--background-success-light); --color-warning-bg: var(--background-warning-light); --color-error-bg: var(--background-error-light); --color-info-bg: var(--background-info-light); --color-success-border: var(--stroke-success); --color-warning-border: var(--stroke-warning); --color-error-border: var(--stroke-error-dark); --color-info-border: var(--stroke-info); --color-dark: var(--texts-dark); --color-medium: var(--texts-medium); --color-muted: var(--texts-light); --color-light: var(--stroke-grey-light); --color-border-strong: var(--stroke-grey-medium); --color-surface: var(--background-grey-light); --color-surface-soft: var(--neutral-l01); --color-surface-strong: var(--background-grey-medium); --color-white: var(--background-principal); --color-inverse: var(--background-black); --gradient-degrade: var(--estilos-degrade); --gradient-panel: linear-gradient(180deg, color-mix(in srgb, var(--color-white), transparent 2%) 0%, color-mix(in srgb, var(--color-surface-soft), transparent 2%) 100%); --gradient-panel-accent: radial-gradient(circle at top left, color-mix(in srgb, var(--color-primary), transparent 92%), transparent 36%); --space-1: var(--size-xxs); --space-2: var(--size-xs); --space-3: var(--size-m); --space-4: var(--size-l); --space-5: var(--size-xl); --breakpoint-mobile: 768px; --breakpoint-tablet: 1024px; --grid-mobile-columns: 4; --grid-mobile-gutter: var(--size-m); --grid-mobile-margin: var(--size-m); --grid-tablet-columns: 8; --grid-tablet-gutter: var(--size-l); --grid-tablet-margin: var(--size-xl); --grid-desktop-columns: 12; --grid-desktop-gutter: var(--size-l); --grid-desktop-margin: 90px; --radius-sm: var(--bordes-s); --radius-md: 8px; --radius-lg: 12px; --radius-full: 9999px; --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05); --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); --shadow-focus: 0 0 0 3px color-mix(in srgb, var(--color-primary), transparent 70%); --font-family: var(--body), system-ui, -apple-system, 'Segoe UI', sans-serif; --font-family-mono: 'Courier New', 'Consolas', monospace; --text-h1-size: var(--page-title-h1-bold-32px-size); --text-h1-weight: 700; --text-h1-line-height: var(--page-title-h1-bold-32px-line-height); --text-h4-size: 1.125rem; --text-h4-weight: 700; --text-h4-line-height: 1.625rem; --text-label-bold-size: 0.875rem; --text-label-bold-weight: 700; --text-label-bold-line-height: 1.375rem; --text-label-medium-size: 0.875rem; --text-label-medium-weight: 500; --text-label-medium-line-height: 1.375rem; --text-body1-size: var(--body-medium-size); --text-body1-weight: 400; --text-body1-line-height: var(--body-medium-line-height); --text-caption-size: var(--caption-body-3-size); --text-caption-weight: 500; --text-caption-line-height: var(--caption-body-3-line-height); --sk-field-min-width: 0px; --tag-bg: var(--color-primary-soft); --tag-fg: var(--color-primary); --interactive-hover: color-mix(in srgb, var(--color-white), var(--color-primary) 4%); --interactive-active: color-mix(in srgb, var(--color-primary-soft), var(--color-white) 35%); --code-bg: #0f172a; --code-fg: #a5f3a0; --code-muted: #94a3b8; --code-border: rgba(255, 255, 255, 0.12); --danger-soft: #fef2f2; --danger-border: #fecaca; --danger-fg: #991b1b; --accent-1: var(--color-primary); --accent-2: var(--color-info); --accent-3: var(--color-success); --accent-4: var(--color-warning); --accent-5: var(--charts-c32, #6f32c6); --accent-6: var(--charts-c38, #1abc9c); --accent-7: var(--charts-c39, #f28c28); --accent-8: var(--charts-c33, #1f6feb); --avatar-badge-bg: var(--color-error); --avatar-badge-fg: var(--color-white); --avatar-badge-ring: var(--color-white); } @media (min-width: 768px) { :root { --sk-field-min-width: 280px; } } @media (min-width: 1024px) { :root { --sk-field-min-width: clamp(280px, calc((100vw - 444px) / 3 + 72px), 400px); } }";

export { SKANDIA_DESIGN_TOKENS_CSS, SKANDIA_THEME_TOKENS, SkAccordionComponent, SkAlertComponent, SkAutoCompleteComponent, SkAvatarComponent, SkAvatarGroupComponent, SkBadgeComponent, SkBlockUIComponent, SkBreadcrumbComponent, SkButtonComponent, SkButtonGroupComponent, SkCardComponent, SkCarouselComponent, SkCascadeSelectComponent, SkCheckboxComponent, SkChipComponent, SkColorPickerComponent, SkConfirmDialogComponent, SkContextMenuComponent, SkDataViewComponent, SkDatePickerComponent, SkDialogComponent, SkDividerComponent, SkDockComponent, SkDrawerComponent, SkDropdownComponent, SkFieldsetComponent, SkFileUploadComponent, SkGalleriaComponent, SkImageCompareComponent, SkImageComponent, SkInplaceComponent, SkInputComponent, SkInputMaskComponent, SkInputNumberComponent, SkInputOtpComponent, SkKnobComponent, SkListComponent, SkListboxComponent, SkLoginFormComponent, SkMegaMenuComponent, SkMenuComponent, SkMenubarComponent, SkMeterGroupComponent, SkMultiSelectComponent, SkOrderListComponent, SkOrgChartComponent, SkOverlayBadgeComponent, SkPaginatorComponent, SkPanelComponent, SkPanelMenuComponent, SkPasswordComponent, SkPickListComponent, SkPopoverComponent, SkProgressBarComponent, SkProgressSpinnerComponent, SkRadioComponent, SkRadiogroupComponent, SkRatingComponent, SkScrollPanelComponent, SkScrollTopComponent, SkSelectButtonComponent, SkSkeletonComponent, SkSliderComponent, SkSpeedDialComponent, SkSplitButtonComponent, SkStepperComponent, SkStepsComponent, SkSwitchComponent, SkTableComponent, SkTabsComponent, SkTagComponent, SkTerminalComponent, SkTextLinkComponent, SkTextareaComponent, SkTieredMenuComponent, SkTimelineComponent, SkToastComponent, SkToggleButtonComponent, SkToolbarComponent, SkTooltipComponent, SkTreeComponent, SkTreeSelectComponent, SkTreeTableComponent, SkandiaPreset, provideSkandiaUI };
export type { SkAccordionPanel, SkActiveFilter, SkAlertVariant, SkAvatarSize, SkAvatarType, SkBadgeSize, SkBadgeType, SkBadgeVariant, SkBreadcrumbItem, SkButtonProduct, SkButtonSize, SkButtonVariant, SkCarouselItem, SkChipSize, SkChipVariant, SkFilterGroup, SkListItem, SkListboxListStyle, SkListboxOption, SkLoginPayload, SkOverlayBadgeSeverity, SkOverlayBadgeSize, SkRadioGroupLayout, SkRadioGroupOption, SkRowAction, SkScrollPanelSize, SkStep, SkTableBadgeVariant, SkTableColumn, SkTextLinkSize, SkandiaThemeTokens };
//# sourceMappingURL=skandia-ui.d.ts.map
